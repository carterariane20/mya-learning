# Buổi 5 — Animals. It's a cat.

Buổi thứ năm: bé nhận ra 4 con vật (cat, dog, duck, bird), bắt chước tiếng kêu của chúng (meow, woof, quack, tweet), chạy tới đúng con khi nghe tiếng kêu, và nói "It's a cat." khi được hỏi "What's this?".
File này gom mọi thứ của buổi 5 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/05-animals/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 5) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–4, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 30% lượt của Mya |
| Từ mới | cat, dog, duck, bird, meow, woof, quack, tweet, What's this?, It's a cat., Do you like cats? |
| Sản phẩm cuối buổi | Bé chạy tới đúng con vật khi nghe tiếng kêu và gọi tên được ít nhất 2 con |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nghe và chỉ (hoặc chạy tới) đúng 4 con: cat, dog, duck, bird.
- Bắt chước tiếng kêu: meow, woof, quack, tweet.
- Nói "cat" (mức 1) hoặc "It's a cat." (mức 2) khi được hỏi "What's this?".

Không kỳ vọng: nói đủ 4 con, nói trọn "It's a ___." cho cả 4 con, nói "a" cho rõ. Bé chỉ nói "cat" hoặc "a cat" là **đạt**, không sửa.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Cat! | Mèo | nói | cat, cát, ket, két |
| Dog! | Chó | nói | dog, dóc, đoóc, doc |
| Duck! | Vịt | nói | duck, dắc, đắc, dắt |
| Bird! | Chim | nói | bird, bớt, bơ, bớd |
| Meow! | Meo meo | nói | meow, meo, miu, mi ao |
| Woof! | Gâu gâu | nói | woof, gâu, guv, wuf |
| Quack! | Cạc cạc | nói | quack, quác, cạc, cwack |
| Tweet! | Chíp chíp | nói | tweet, tuýt, tuýp, twit |
| What's this? | Đây là con gì? | nghe | what's this, what this, oát đít |
| It's a cat. | Đây là con mèo. | nói theo mẫu | it's a cat, is a cat, a cat, cat, ít a cát |
| Do you like cats? | Con thích mèo không? | nghe | (chỉ cần nghe hiểu) |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** jump like, swim like, crawl like, this, a, do you, color (và các từ của buổi 1–4: red, green, one…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 4 con vật đồ chơi hoặc ảnh in (mèo, chó, vịt, chim), 1 cái hộp kín to vừa con mèo, 1 cái khăn để trùm, đồ vật màu đỏ và màu xanh lá (ôn màu buổi 4), loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Old MacDonald Had a Farm" ở chặng 6 khi vận động; "Brown Bear, Brown Bear, What Do You See?" (đọc, không hát) nếu bé còn hứng. Bố/mẹ mở trên loa, app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (emoji, mỗi thẻ một vật chính):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, Bye-bye! | 1, 8 |
| 🟥 | Red! | 2 |
| 🟩 | Green! | 2 |
| 📦 | Shh…, Meow! | 3 |
| 🐱 | Cat!, Meow!, What's this?, It's a cat., Yes! | 3, 4, 5, 6, 7 |
| 🐶 | Dog!, Woof, woof! | 3, 4, 5 |
| 🦆 | Duck!, Quack, quack! | 3, 4, 5, 6, 7 |
| `bird.svg` (SVG phẳng) | Bird!, Tweet, tweet! | 3, 4, 6 |
| 👂 | Listen! | 4 |
| 🧣 | Bird! (con chim trùm khăn) | 5 |
| 🤸 | Stand up! | 6 |

Con vật đồ chơi thật trong tay bố/mẹ là chính; thẻ trên màn chỉ nhắc lại con đang nói.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Cất con mèo vào hộp kín, để 3 con còn lại sau lưng. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 🟥 rồi 🟩

| | |
|---|---|
| Mục đích | Ôn màu của buổi 4: đỏ, xanh lá (không dạy mới) |
| Mya | Hỏi What color is it? với món đồ bố/mẹ giơ |
| Bố/mẹ | Giơ món đồ đỏ rồi món đồ xanh lá. Còn thời gian thì cho bé đi săn màu 30 giây quanh phòng |
| Ra khi | Bé đã trả lời 2 màu hoặc hết 5 phút |

> **Mya:** *(bố/mẹ lấy sẵn một món đồ màu đỏ và một món đồ màu xanh lá)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình ôn lại màu sắc nhé.
> **Mya:** *(trước câu này bố/mẹ giơ món đồ màu đỏ)* [cheerful] Look! [pause] [ask] What color is it? [WAIT]
> *(bé: "Red!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** *(vẫy, `wave`)* [praise] RED! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ giơ món đồ màu xanh lá)* [ask] What color is it? [WAIT]
> *(bé: "Gờ-rin!" · sai/im: Mya đọc mẫu «Green!»)*
> **Mya:** *(vẫy, `wave`)* [excited] GREEN! [pause] Wo-ow! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 📦 rồi các con vật

| | |
|---|---|
| Mục đích | Gây tò mò bằng hộp kín có tiếng "meow", rồi gặp lần lượt 4 con vật |
| Mya | Thì thầm, bắt chước tiếng kêu, mời bé kêu theo |
| Bố/mẹ | Đưa hộp kín cho bé thấy **trước** khi Mya nói; mở hộp khi Mya nói "A CAT!"; lần lượt giơ chó, vịt, chim |
| Ra khi | Đã giới thiệu đủ 4 con |

> **Mya:** *(bố/mẹ đặt hộp kín trước mặt bé, trong hộp có con mèo đồ chơi)* [vi] Ôn màu xong rồi, con giỏi lắm! [pause 1s] Giờ có hộp bí mật nè.
> **Mya:** *(bố/mẹ lắc nhẹ hộp)* [whisper] Shh… [pause] Listen… [pause 1s] [gasp] Meow!
> **Mya:** *(bố/mẹ mở hộp, giơ con mèo)* [excited] Look! [pause] A CAT!
> **Mya:** [cheerful] Cat! [pause] Meow! [pause] Your turn! [WAIT]
> *(bé: "Meo!" · sai/im: Mya đọc mẫu «Meow!»)*
> **Mya:** *(vẫy, `wave`)* [praise] MEOW! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ con chó)* [excited] A DOG! [pause] Woof, woof!
> **Mya:** *(bố/mẹ giơ con vịt)* [excited] A DUCK! [pause] Quack, quack!
> **Mya:** *(bố/mẹ giơ con chim)* [excited] A BIRD! [pause] Tweet, tweet!
> **Mya:** *(bố/mẹ giơ lại con chó)* [ask] Woof! [pause] Dog… or bird? [WAIT]
> *(bé: "Dóc!" · sai/im: Mya đọc mẫu «Dog!»)*
> **Mya:** *(vẫy, `wave`)* [praise] DOG! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 👂 rồi con vật đang kêu

| | |
|---|---|
| Mục đích | Hiểu tên con vật qua tiếng kêu: nghe rồi chạy tới đúng con |
| Mya | Kêu tiếng của một con, khen ngay khi bé chạy tới đúng |
| Bố/mẹ | Đặt 4 con vật ở 4 góc phòng trước khi bắt đầu; chạy cùng bé ở 2 lượt đầu |
| Ra khi | Bé chạy tới đúng ≥ 3 con |

> **Mya:** *(bố/mẹ đặt 4 con vật ở 4 góc phòng)* [vi] Mình biết bốn bạn rồi! [pause 1s] Giờ nghe tiếng kêu rồi chạy tới bạn đó nhé.
> **Mya:** [excited] Woof, woof! [WAIT]
> *(bé: "👣"; bé chạy tới con chó · sai/im: Mya đọc mẫu «Woof, woof!»)*
> **Mya:** [praise] Ye-es! Dog! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Quack, quack! [WAIT]
> *(bé: "👣"; bé đi lạch bạch tới con vịt · sai/im: Mya đọc mẫu «Quack, quack!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! Duck! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [excited] Tweet, tweet! [WAIT]
> *(bé: "👣"; bé dang tay chạy tới con chim · sai/im: Mya đọc mẫu «Tweet, tweet!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Bird! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Meow! [WAIT]
> *(bé: "👣"; bé bò tới con mèo · sai/im: Mya đọc mẫu «Meow!»)*
> **Mya:** [praise] Cat! [pause] Good job! *(chỉ khi bé đúng)*

Bé chạy tới sai con → "[cheerful] Almost! [pause] Try again!" và bố/mẹ chỉ nhẹ về phía con đúng.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 🐱 🐶 🦆 🧣

| | |
|---|---|
| Mục đích | Bé trả lời What's this?, nói "It's a cat." và trả lời Do you like cats? |
| Mya | Vòng 1: mèo (có cả câu). Vòng 2: chó, vịt. Vòng 3: chim trùm khăn. Cuối: hỏi bé thích mèo không |
| Bố/mẹ | Giơ đúng con vật **trước** khi Mya hỏi; trùm khăn lên con chim ở vòng 3; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 4 con hoặc hết 11 phút |

> **Mya:** [vi] Chạy giỏi quá! [pause 1s] Giờ mình chơi trò hỏi đáp nhé.
> **Mya:** *(trước câu này bố/mẹ giơ con mèo)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Cát!" · sai/im: Mya đọc mẫu «Cat!»)*
> **Mya:** [praise] CAT! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] It's a CAT. [WAIT]
> *(bé: "Ít a cát." · sai/im: Mya đọc mẫu «It's a cat.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's a cat! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con chó)* [ask] What's this? [WAIT]
> *(bé: "Dóc!" · sai/im: Mya đọc mẫu «Dog!»)*
> **Mya:** [praise] DOG! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con vịt)* [ask] What's this? [WAIT]
> *(bé: "Dắc!" · sai/im: Mya đọc mẫu «Duck!»)*
> **Mya:** [giggle] DUCK! [pause] Quack, quack! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ trùm khăn lên con chim)* [whisper] Shh… [pause] Tweet, tweet… [pause] [ask] What's this? [WAIT]
> *(bé: "Bớt!" · sai/im: Mya đọc mẫu «Bird!»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said BIRD! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ lại con mèo; bé nói No cũng được, cứ gật đầu)* [ask] Do you like cats? [WAIT]
> *(bé: "Yes!" · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** *(vẫy, `wave`)* [excited] I like cats! [pause] Meow! *(chỉ khi bé đúng)*

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Cat!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào con vật khi Mya đọc mẫu. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay vào con vật nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🤸 rồi `bird.svg` 🦆 🐱

| | |
|---|---|
| Mục đích | Xả năng lượng, lặp tên con vật trong lúc chơi |
| Mya | Ra lệnh "Jump like a bird!", "Swim like a duck!", "Crawl like a cat!" |
| Bố/mẹ | Mở bài Old MacDonald; làm cùng bé, nhảy như chim, lạch bạch như vịt, bò như mèo |
| Ra khi | Hết giờ |

> **Mya:** [vi] Hỏi đáp xong rồi, giỏi quá! [pause 1s] Giờ mình đứng dậy vận động nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ nhảy cùng bé, dang tay như cánh)* [excited] Jump like a BIRD! [pause] Tweet, tweet! [WAIT]
> *(bé: "Bớt!" · sai/im: Mya đọc mẫu «Bird!»)*
> **Mya:** [giggle] Tweet, tweet! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bé đi lạch bạch, hai tay quạt như bơi)* [cheerful] Swim like a DUCK! [pause] Quack, quack! [WAIT]
> *(bé: "Dắc!" · sai/im: Mya đọc mẫu «Duck!»)*
> **Mya:** [giggle] Quack, quack! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bé bò bằng bốn chân như mèo)* [excited] Crawl like a CAT! [pause] Meow! [WAIT]
> *(bé: "Cát!" · sai/im: Mya đọc mẫu «Cat!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Meow! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 🐱 rồi 🦆

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya gọi sai tên con vật |
| Mya | Cầm con mèo nhưng nói "dog"; giơ con vịt hỏi "bird?" |
| Bố/mẹ | Đưa đồ cho Mya cầm (giơ trước màn); nhắc nhỏ: "Mya nói sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** [vi] Vận động xong rồi, con giỏi lắm! [pause 1s] Giờ con làm cô giáo, dạy Mya nhé.
> **Mya:** *(Mya cầm con mèo nhưng cố tình nói dog)* [cheerful] Look! [pause] DOG! [WAIT]
> *(bé: "No! Cat!" · sai/im: Mya đọc mẫu «Cat!»)*
> **Mya:** [gasp] Oh no! [pause] It's a CAT! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(giơ con vịt)* [puzzled] And this… [pause] [ask] bird? [WAIT]
> *(bé: "No! Duck!" · sai/im: Mya đọc mẫu «Duck!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] DUCK! Duck! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, chào từng con vật kèm tiếng kêu, nói "bye-bye" |
| Mya | Vẫy chào từng con vật, khen cụ thể, chào bé |
| Bố/mẹ | Giơ lần lượt 4 con vật, dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ giơ lần lượt 4 con vật)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào các bạn nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, cat! Meow! [pause] Bye-bye, dog! Woof!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, duck! Quack! [pause] Bye-bye, bird! Tweet!
> **Mya:** [vi] Hôm nay con nói được tên bốn bạn động vật. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🐾, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói tên con vật bằng tiếng Việt ("con mèo") | Công nhận rồi bắc cầu: "Con mèo! Cat! Meow!" Không bắt nói lại ngay. |
| Bé chỉ nói "cat" hoặc "a cat" thay vì "It's a cat." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Bé chỉ kêu "meow", "woof" chứ chưa nói tên | Tính là đạt. "[cheerful] Yes! Cat! Meow!" rồi mời bé nói "cat" một lần. |
| Bé sợ con vật đồ chơi hoặc tiếng kêu thì thầm | Giảm giọng, để bố/mẹ ôm con vật cùng bé. Không ép chạm. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung khi nghe tiếng kêu | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé kể con khác ("con voi", "con bò") | Theo bé 1 lượt ("Wow!"), rồi quay lại 4 con của bài. Không dạy thêm con vật. |
| Bé trả lời "No" khi hỏi Do you like cats? | Chấp nhận. Bố/mẹ gật đầu, Mya nói "I like cats!" rồi đi tiếp. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé chạy tới hoặc chỉ đúng 3/4 con khi nghe tên hoặc tiếng kêu.
2. Bé bắt chước được 2 tiếng kêu.
3. Bé nói "cat" / "dog" (hoặc "It's a ___.") khi được hỏi "What's this?".

**Số đo của buổi 5** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 5 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 7 |
| Từ đích bé dùng | ≥ 2 con vật |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 30%, vượt 40% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Chạy tới đúng con vật | | | | |
| Gọi tên con vật | | | | |
| Bắt chước tiếng kêu | | | | |
| It's a ___ | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Đi dạo, thấy con vật thật hay trong sách thì chỉ và nói tên tiếng Anh ("Look! A dog!"), bé nói được thì tốt, không nói cũng không sao.
- Xem 1 video bài hát Old MacDonald, bé chơi bên cạnh, không bắt nghe.
- Chơi trò hộp bí mật: giấu một con vật vào hộp, lắc và bắt chước tiếng kêu, bé đoán.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 6 — Body. Touch your nose.) ôn bài này bằng trò bắt chước con vật.

---

## 9. Cho app (thư mục `Resources/Lessons/05-animals/`)

Thư mục bài gồm `lesson.json` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, riêng con chim là `images/bird.svg` vì emoji 🐦 vẽ không giống chim), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 7.
