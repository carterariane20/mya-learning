# Buổi 3 — Numbers 1–5. I'm four.

Buổi thứ ba: bé đếm 1–5 cùng Mya, giơ đúng số ngón tay khi nghe số, và trả lời "How old are you?" bằng tuổi của mình.
File này gom mọi thứ của buổi 3 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/03-numbers/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 3) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 4 tuổi, đã học buổi 1–2, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 30% lượt của Mya (bắt đầu giảm giải thích) |
| Từ mới | one, two, three, four, five, How many?, How old are you?, I'm four. |
| Sản phẩm cuối buổi | Bé đếm 1–5 và nói tuổi |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Đếm 1–5 cùng Mya (nói theo, không cần đúng hết).
- Giơ đúng số ngón tay khi nghe số (ít nhất 1–3).
- Trả lời "How old are you?" bằng "I'm four." hoặc chỉ "four" (bé 5 tuổi: "five").

Không kỳ vọng: tự đếm không cần Mya, chỉ đúng từng ngón khi đếm, phát âm "three".

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| One! | Một | nói | one, oan, wan, quan |
| Two! | Hai | nói | two, tu, tù, to |
| Three! | Ba | nói | three, tri, sờ ri, free, tree |
| Four! | Bốn | nói | four, pho, fo, phô |
| Five! | Năm | nói | five, phai, fai, phai vơ |
| How many? | Có mấy cái? | nghe | (chỉ cần nghe hiểu) |
| How old are you? | Con mấy tuổi? | nghe (bé hỏi lại Mya ở vòng 3 là thưởng thêm) | how old are you, how old, hao âu a du |
| I'm four. | Con {age} tuổi. | nói | "I'm four", "am four", "four", "pho", giơ đúng số ngón tay (tuổi lấy từ hồ sơ: bé 5 tuổi thì là "five") |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** blocks, balls, fingers, jump / jumps, clap, hmm, six (Mya đếm sai ở chặng 7) (và các từ của buổi 1–2).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 5 khối đồ chơi, 5 quả bóng giấy, hộp giấy, ngón tay, sticker số, loa.
**Bài hát:** "Five Little Ducks" và "One, Two, Three, Four, Five" (nursery rhyme) ở chặng 6, nếu bé thích hát. Bố/mẹ mở trên loa, app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình:**

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, I'm happy., Bye-bye! | 1, 8 |
| `qmark` → sẽ là `faceSad` *(chưa vẽ)* | sad, Yes! | 2 |
| `qmark` → sẽ là `faceSleepy` *(chưa vẽ)* | sleepy, No! | 2 |
| `qmark` → sẽ là `blocks` *(chưa vẽ)* | 1 2 3 4 5, Two!, Four!, Three! | 3, 5, 7 |
| `qmark` → sẽ là `fingers` *(chưa vẽ)* | Three!, One!, Five!, Two! | 4, 5, 6, 8 |
| `ball` | How many?, Three! | 5 |

Chặng 5 dùng thẻ `ball` có sẵn cho câu "How many?" (bố/mẹ đặt bóng giấy thật trước mặt bé).
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn buổi 2 |
| Mya | Chào, khoe mình vui, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] I'm HAPPY!
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you? [WAIT]
> *(bé: "I'm happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [praise] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `qmark` (sẽ là `faceSad`)

| | |
|---|---|
| Mục đích | Ôn 4 mặt cảm xúc của buổi 2 |
| Mya | Đoán mặt bé đang làm (có lần cố tình đoán sai) |
| Bố/mẹ | Làm mẫu 1 mặt trước, rồi để bé làm |
| Ra khi | Đoán xong ≥ 2 mặt |

> **Mya:** [vi] Con làm mặt, Mya đoán nhé! [pause] [cheerful] Ready? [WAIT]
> *(bé làm mặt buồn)*
> **Mya:** [puzzled] Hmm… [pause] [ask] SAD? [WAIT]
> *(bé: "Yes!"; gật đầu cũng tính · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [excited] Ye-es! Sad! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bé làm mặt buồn ngủ, Mya cố tình đoán sai)* [puzzled] Hmm… [pause] [ask] HAPPY? [WAIT]
> *(bé: "No! Sleepy!" · sai/im: Mya đọc mẫu «No!»)*
> **Mya:** [giggle] Oh! SLEEPY! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ `qmark` (sẽ là `blocks`)

| | |
|---|---|
| Mục đích | Gây tò mò bằng chồng khối bị đổ |
| Mya | Đếm khối, làm rơi, nhờ bé nhặt và đếm tiếp |
| Bố/mẹ | Đặt 5 khối trước mặt bé; làm khối "rơi" khi Mya nói Oh no |
| Ra khi | Đã đếm đủ 5 khối |

> **Mya:** *(Mya chỉ từng khối)* [cheerful] Look! Blocks! [pause] [slow] One… two… three…
> **Mya:** [gasp] Oh no! [pause] [vi] Rơi hết rồi! Con nhặt giúp Mya nhé!
> *(bố/mẹ làm đổ chồng khối)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Thank you! [pause] [slow] One… [WAIT]
> *(bé: "Two!" · sai/im: Mya đọc mẫu «Two!»)*
> **Mya:** [praise] Ye-es! Two! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [slow] Three… [WAIT]
> *(bé: "Pho!" · sai/im: Mya đọc mẫu «Four!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Four! [pause] FIVE! [pause] Wo-ow! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `qmark` (sẽ là `fingers`)

| | |
|---|---|
| Mục đích | Hiểu số qua ngón tay và số lần nhảy, chưa cần nói |
| Mya | Hô số; bé giơ ngón hoặc nhảy đúng số lần; khen ngay |
| Bố/mẹ | Giơ ngón và nhảy cùng bé ở 2 số đầu |
| Ra khi | Bé làm đúng ≥ 3 lần |

> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] THREE! [pause] [vi] Giơ ba ngón tay nào! [WAIT]
> *(bé: "🖐"; bé giơ 3 ngón · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** [praise] Three! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] ONE! [pause] Jump! [WAIT]
> *(bé: "👣"; bé nhảy 1 cái · sai/im: Mya đọc mẫu «One!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! One jump! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] FIVE! [pause] Five fingers! [WAIT]
> *(bé: "🖐" · sai/im: Mya đọc mẫu «Five!»)*
> **Mya:** [praise] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [excited] TWO! [pause] Jump, jump! [WAIT]
> *(bé: "👣"; bé nhảy 2 cái · sai/im: Mya đọc mẫu «Two!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Two jumps! [pause] High five! *(chỉ khi bé đúng)*

Đổi thứ tự các số. Bé giơ sai ngón → "[cheerful] Almost! [pause] Try again!" và Mya đếm chậm từng ngón.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `qmark` (sẽ là `blocks`)

| | |
|---|---|
| Mục đích | Bé đếm cùng Mya, trả lời How many?, nói tuổi |
| Mya | Vòng 1: đếm tiếp. Vòng 2: How many? với bóng. Vòng 3: How old are you? |
| Bố/mẹ | Đặt 3 quả bóng giấy ở vòng 2; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

**Vòng 1 — Đếm cùng Mya**

> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con đếm với Mya nhé. [pause] [slow] One… two… [WAIT]
> *(bé: "Free!" · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** [praise] Three! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [slow] Four… [WAIT]
> *(bé: "Five!" · sai/im: Mya đọc mẫu «Five!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Five! Wo-ow! [pause] High five! *(chỉ khi bé đúng)*

**Vòng 2 — How many?**

> **Mya:** *(trước câu này bố/mẹ đặt 3 quả bóng giấy trước mặt bé)* [cheerful] Look! Balls! [pause] [ask] How many? [WAIT]
> *(Mya chờ bé 4,5 giây · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** *(Mya chỉ từng quả)* [slow] One… two… [pause] [ask] How many? [WAIT]
> *(bé: "Three!" · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** [praise] THREE! [pause] You said three! Well do-one! *(chỉ khi bé đúng)*

**Vòng 3 — How old are you?**

> **Mya:** *(Mya giơ 4 ngón)* [cheerful] I'm FOUR! [pause] [ask] How old are you? [WAIT]
> *(Mya chờ bé 4,5 giây · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** [vi] Con mấy tuổi nhỉ? [pause] [slow] How old are you? [pause] I'm… FOUR [WAIT]
> *(bé: "Am four!" · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** *(vẫy, `wave`)* [gasp] [praise] Wo-ow! You're FOUR! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [vi] Con hỏi Mya đi: [pause] [slow] "How old are you?" [WAIT]
> *(bé: "How old you?" · sai/im: Mya đọc mẫu «How old are you?»)*
> **Mya:** *(vẫy, `wave`)* [excited] I'm FOUR! [giggle] [pause] Thank you! *(chỉ khi bé đúng)*

**Nếu bé im — thang gợi ý, đi đúng thứ tự, không nhảy bậc:**

| Bậc | Mya làm gì | Lời mẫu ở buổi 3 | Chờ |
|---|---|---|---|
| 1 | Lặp chậm hơn + động tác | "[slow] How… old… are… you?" *(chỉ vào bé)* [WAIT] | 4,5 giây |
| 2 | Cho 2 lựa chọn | "[ask] Three… or four?" *(giơ 3 rồi 4 ngón)* [WAIT] | 4,5 giây |
| 3 | Tiếng Việt 1 câu + mẫu | "[vi] Con bốn tuổi, nói 'four' nhé. [pause] [slow] Four." [WAIT] | 4,5 giây |
| 4 | Chấp nhận không lời | "[cheerful] Show Mya! [pause] [vi] Con giơ ngón tay đi!" [WAIT] | 3 giây |
| 5 | Tự trả lời rồi chuyển | "[praise] You're four! [pause] [cheerful] Yay!" | — |

Lời mẫu bậc 2–5 ghi theo bé 4 tuổi; app thay bằng tuổi trong hồ sơ. Bé nói chưa đúng: "[cheerful] Almost! [pause] Try again!" rồi app đọc câu mẫu. Im 12 giây → câu có/không ("[ask] Four? [pause] Yes?" [WAIT]). Im 20 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, giơ ngón tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ `qmark` (sẽ là `fingers`)

| | |
|---|---|
| Mục đích | Xả năng lượng, đếm to khi nhảy và vỗ tay |
| Mya | Hô số lần nhảy / vỗ tay, đếm to |
| Bố/mẹ | Đứng lên nhảy, vỗ tay cùng bé; mở "Five Little Ducks" nếu bé thích |
| Ra khi | Hết giờ |

> **Mya:** *(vẫy, `wave`)* [cheerful] Stand up! [pause] Jump THREE! [pause] [sing-song] One… two… three!
> *(cả nhà nhảy 3 cái)*
> **Mya:** [excited] Clap FIVE! [pause] [sing-song] One, two, three, four, five!
> *(cả nhà vỗ tay 5 cái)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] Clap TWO! [WAIT]
> *(bé: "One, two!"; bé vỗ tay và đếm · sai/im: Mya đọc mẫu «One, two!»)*
> **Mya:** [praise] One, two! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Jump… [pause] [ask] how many? [WAIT]
> *(bố/mẹ giơ 4 ngón cho bé xem)*
> *(bé: "Four!"; bé nhảy 4 cái · sai/im: Mya đọc mẫu «Four!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Four jumps! [pause] Wo-ow! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `qmark` (sẽ là `blocks`)

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya đếm sai |
| Mya | Đếm "one, two, four"; rồi "four, six" |
| Bố/mẹ | Nhắc nhỏ: "Mya đếm sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(Mya cố tình bỏ số 3)* [cheerful] One… [pause] two… [pause] FOUR! [WAIT]
> *(bé: "No! Three!" · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** [gasp] Oh no! [pause] One, two, THREE! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** [puzzled] Three… four… [pause] SIX? [WAIT]
> *(bé: "Five!" · sai/im: Mya đọc mẫu «Five!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] FIVE! Five! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Đếm 1–5 lần cuối, nói "bye-bye" |
| Mya | Đếm cùng bé, khen cụ thể, chào |
| Bố/mẹ | Dán sticker số cho bé, vẫy tay |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** [sing-song] One, two, three, four, FIVE!
> *(giơ từng ngón khi đếm)*
> **Mya:** [vi] Hôm nay con đếm đến năm. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bố/mẹ dán sticker số)*
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🖐️, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé đếm bằng tiếng Việt ("một, hai, ba") | Công nhận rồi bắc cầu: "Một, hai, ba! One, two, three!" Không bắt đếm lại ngay. |
| Bé đếm "one, two, three" nhưng chỉ sai ngón | Bình thường, **không sửa**. Mya chỉ làm mẫu lại chậm, chỉ từng ngón. |
| Bé nói "free" thay cho "three" | Khen như đúng, Mya nói lại đúng 1 lần "Three!" rồi đi tiếp. |
| Bé chỉ giơ ngón tay khi hỏi tuổi | Tính là đúng. "[praise] You're four! Good job!" |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé ném khối, chơi phá | Chơi cùng 1 lượt ("Oh no! Blocks!"), rồi "[whisper] Shh… [pause] Look!". Không mắng. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé giơ đúng 1–3 ngón khi nghe số.
2. Bé đếm theo được ít nhất 3 số.
3. Bé nói tuổi ("four" hoặc "I'm four") khi được hỏi.

**Số đo của buổi 3** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 3 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 5 |
| Từ đích bé dùng | ≥ 3 số |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 30%, vượt 40% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Giơ ngón theo số | | | | |
| Đếm 1–5 | | | | |
| I'm four | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Đếm cầu thang, đếm thìa, đếm bước chân bằng tiếng Anh, mỗi ngày 1 lần.
- Sau buổi: hỏi lại đúng 1 câu "How old are you?", bé giơ ngón tay là được.
- Ngày giữa hai buổi: mở "Five Little Ducks" khi bé chơi, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 4 — Colors. It's red.) ôn bài này bằng cách đếm 1–5 với khối màu.

---

## 9. Cho app (thư mục `Resources/Lessons/03-numbers/`)

Thư mục bài gồm `lesson.json` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji hoặc file trong `images/`), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 5.
- Tuổi bé là biến: câu có `{age}` ("I'm {age}.") app điền bằng chữ tiếng Anh theo tuổi trong hồ sơ (4 → four, 5 → five) và tạo tiếng trên máy. Mya luôn 4 tuổi ("I'm four!") vì Mya là bạn cùng tuổi.
