# Buổi 4 — Colors. It's red.

Buổi thứ tư: bé nhận ra 4 màu (red, blue, yellow, green), chạy chạm đúng đồ vật khi nghe tên màu, và nói "It's red." khi được hỏi.
File này gom mọi thứ của buổi 4 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/04-colors/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 4) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi, đã học buổi 1–3, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 30% lượt của Mya (câu nối chuyển chặng, hướng dẫn, phụ đề chỗ cần) |
| Từ mới | red, blue, yellow, green, What color is it?, It's red., I like blue. |
| Sản phẩm cuối buổi | Bé chỉ đúng màu và nói 2 màu |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nhận ra 4 màu khi nghe: red, blue, yellow, green.
- Chạy chạm hoặc chỉ đúng đồ vật khi nghe tên màu.
- Nói "It's blue." (hoặc chỉ "blue") khi được hỏi "What color is it?".

Không kỳ vọng: nói đủ 4 màu, phân biệt blue / green ngay buổi đầu (tiếng Việt cùng gọi là "xanh").

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Red! | Đỏ | nói | red, ret, rét, đỏ |
| Blue! | Xanh dương | nói | blue, blu, bờ lu, bu |
| Yellow! | Vàng | nói | yellow, yeo lô, dê lô, yelo |
| Green! | Xanh lá | nói | green, grin, gờ rin, rin |
| What color is it? | Cái này màu gì? | nghe (bé hỏi lại Mya ở vòng 3 là thưởng thêm) | what color is it, what color, oát ca lơ |
| It's blue. | Nó màu xanh dương. | nói theo mẫu | it's blue, is blue, blue, ít blu |
| It's yellow. | Nó màu vàng. | nói theo mẫu | it's yellow, is yellow, yellow, ít yeo lô |
| I like blue. | Con thích màu xanh. | nghe | (chỉ cần nghe hiểu) |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** touch, jump to, find, this, blocks, hmm (và các từ của buổi 1–3).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** đồ vật quanh nhà đủ 4 màu (áo, cốc, bút, đồ chơi), 4 tờ giấy màu đỏ / xanh dương / vàng / xanh lá, 5 khối màu, 1 cái rổ, loa.
**Bài hát:** "I See Something Blue" (Super Simple Songs) hoặc một bài "Color Song" ở chặng 6 khi đi săn màu. Bố/mẹ mở trên loa, app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình:**

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (có sẵn) | Hello!, I'm happy., Bye-bye! | 1, 8 |
| `blocks-3` (hình 3 khối, lấy từ bài 3) | Three! | 2 (đếm tới 3) |
| `blocks-5` (hình 5 khối, lấy từ bài 3) | Five! | 2 (đếm tới 5) |
| 🟥 | Red!, Touch red!, Find red! | 3, 4, 6, 7 |
| 🟦 | Blue!, Jump to blue!, It's blue., Find blue! | 3, 4, 5, 6 |
| 🟨 | Yellow!, Touch yellow!, It's yellow. | 3, 4, 5 |
| 🟩 | Green!, Touch green!, What color is it?, Find green! | 3, 4, 5, 6, 7 |

Tờ giấy màu thật trong tay bố/mẹ là chính; thẻ trên màn chỉ nhắc lại màu đang nói.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name? [WAIT]
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you? [WAIT]
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `blocks-3` rồi `blocks-5`

| | |
|---|---|
| Mục đích | Ôn đếm 1–5 của buổi 3 |
| Mya | Đếm khối màu cùng bé, để bé nói số tiếp theo |
| Bố/mẹ | Xếp 5 khối màu thành hàng trước mặt bé |
| Ra khi | Đã đếm đủ 5 |

> **Mya:** *(nghiêng đầu, `listen`)* [vi] Mình đếm khối nhé! [pause] [slow] One… two… [WAIT]
> *(bé: "Three!" · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** [praise] Three! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [slow] Four… [WAIT]
> *(bé: "Five!" · sai/im: Mya đọc mẫu «Five!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Five! [pause] Wo-ow! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 🟥

| | |
|---|---|
| Mục đích | Gây tò mò bằng 4 tờ giấy màu giấu sau lưng |
| Mya | Thì thầm, lần lượt gọi tên từng màu khi lộ ra |
| Bố/mẹ | Giấu 4 tờ giấy sau lưng, lộ từng tờ khi Mya nói |
| Ra khi | Đã lộ đủ 4 màu |

> **Mya (câu nối):** [vi] Đếm xong rồi, con giỏi lắm! [pause 1s] Giờ mình xem màu bí mật nhé.
>
> **Mya:** [whisper] Shh… [pause] Look… [pause 1s] [excited] RED!
> *(bố/mẹ lộ tờ giấy đỏ)*
> **Mya:** [gasp] [excited] BLUE!
> *(lộ tờ xanh dương)*
> **Mya:** [cheerful] YEL-low!
> *(lộ tờ vàng)*
> **Mya:** [cheerful] GREEN!
> *(lộ tờ xanh lá)*
> **Mya:** *(giơ tờ đỏ)* [ask] Red… or green? [WAIT]
> *(bé: "Ret!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** *(vẫy, `wave`)* [praise] RED! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 🟥

| | |
|---|---|
| Mục đích | Hiểu tên màu qua hành động: chạy chạm đồ vật đúng màu |
| Mya | Ra lệnh; khen ngay khi bé chạm đúng |
| Bố/mẹ | Đặt sẵn đồ 4 màu quanh phòng; chạy cùng bé ở 2 lệnh đầu |
| Ra khi | Bé chạm đúng ≥ 3 màu |

> **Mya (câu nối):** [vi] Mình nhìn thấy đủ màu rồi! [pause 1s] Giờ con chạy chạm màu nhé.
>
> **Mya:** [cheerful] Touch RED! [pause] [vi] Con chạm màu đỏ nào! [WAIT]
> *(bé: "👉"; bé chạm cái cốc đỏ · sai/im: Mya đọc mẫu «Touch RED!»)*
> **Mya:** [praise] Ye-es! Red! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Jump to BLUE! [WAIT]
> *(bé: "👣"; bé nhảy tới tờ xanh dương · sai/im: Mya đọc mẫu «Jump to BLUE!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! Blue! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Touch YEL-low! [WAIT]
> *(bé: "👉"; bé chạm cây bút vàng · sai/im: Mya đọc mẫu «Touch YELLOW!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Yellow! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Touch GREEN! [WAIT]
> *(bé hay lẫn xanh lá / xanh dương: bố/mẹ để đồ xanh lá cạnh chậu cây)*
> *(bé: "👉"; bé chạm chậu cây · sai/im: Mya đọc mẫu «Touch GREEN!»)*
> **Mya:** [praise] Green! [pause] Good job! *(chỉ khi bé đúng)*

Bé chạm sai màu → "[cheerful] Almost! [pause] Try again!" và bố/mẹ chỉ nhẹ về phía đồ đúng màu. Blue / green lẫn nhau là lỗi của tiếng Việt, không phải bé kém: gắn blue với trời / biển, green với lá / cây.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 🟦

| | |
|---|---|
| Mục đích | Bé trả lời What color is it?, nói "It's ___.", hỏi lại Mya |
| Mya | Vòng 1: tờ xanh dương. Vòng 2: tờ vàng. Vòng 3: bé hỏi Mya |
| Bố/mẹ | Giơ đúng tờ giấy khi Mya hỏi; thì thầm mẫu khi bé bí 2 lần liền; vòng 3 đưa bé đồ màu xanh lá |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

**Vòng 1 — What color is it? (xanh dương)**

> **Mya (câu nối):** [vi] Con chạm giỏi quá! [pause 1s] Giờ con nói chuyện với Mya nhé.
>
> **Mya:** *(trước câu này bố/mẹ giơ tờ xanh dương)* [cheerful] Look! [pause] [ask] What color is it? [WAIT]
> *(Mya chờ bé 4,5 giây · sai/im: Mya đọc mẫu «It's blue.»)*
> **Mya:** [ask] Red… or blue? [WAIT]
> *(bé: "Blu!" · sai/im: Mya đọc mẫu «Blue!»)*
> **Mya:** [praise] BLUE! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] It's BLUE. [WAIT]
> *(bé: "Ít blu." · sai/im: Mya đọc mẫu «It's blue.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's blue! [pause] High five! *(chỉ khi bé đúng)*

**Vòng 2 — What color is it? (vàng)**

> **Mya:** *(trước câu này bố/mẹ giơ tờ vàng)* [ask] What color is it? [WAIT]
> *(bé: "Yeo-lô!" · sai/im: Mya đọc mẫu «It's yellow.»)*
> **Mya:** [praise] Yel-low! [pause] Well do-one! *(chỉ khi bé đúng)*

**Vòng 3 — Bé hỏi lại Mya**

> **Mya:** *(nghiêng đầu, `listen`; trước câu này bố/mẹ đưa bé một đồ màu xanh lá để giơ lên)* [cheerful] Your turn! [pause] [vi] Con hỏi Mya: [pause] [slow] "What color is it?" [WAIT]
> *(bé: "What color?" · sai/im: Mya đọc mẫu «What color is it?»)*
> **Mya:** [puzzled] Hmm… [pause] [excited] It's GREEN! [pause] I like green! *(chỉ khi bé đúng)*

**Khi bé im hoặc nói sai — app chạy 3 bậc, đúng thứ tự, không nhảy bậc, bằng câu mẫu của lượt và câu có sẵn:**

| Bậc | Bé im | Bé nói sai |
|---|---|---|
| 1 | Mya đọc câu mẫu (vd «It's blue.») | "Mya nghe chưa rõ…" + câu mẫu |
| 2 | "Con nói theo Mya nhé!" + câu mẫu | "Almost! Try again!" + câu mẫu |
| 3 | Câu mẫu + "Con sẽ luyện thêm câu này với mẹ nhé!", rồi đi tiếp | như bên trái |

Mỗi bậc chờ bé 4,5 giây. Một câu đã qua đủ 3 bậc thì 2 phút sau mới gợi ý lại. Bố/mẹ thì thầm mẫu khi bé bí 2 lần liền.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay vào đồ vật nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🟥

| | |
|---|---|
| Mục đích | Xả năng lượng, đi săn màu quanh phòng |
| Mya | Hô màu cần tìm, khen khi bé bỏ đồ vào rổ |
| Bố/mẹ | Mở bài hát màu; cầm rổ đi cùng bé |
| Ra khi | Hết giờ |

> **Mya (câu nối):** [vi] Con nói hay quá! [pause 1s] Giờ mình đi săn màu nhé.
>
> **Mya:** *(vẫy, `wave`; trước câu này bố/mẹ mở bài hát màu, cầm rổ)* [cheerful] Stand up! [pause] Find RED! [pause] Let's go! [WAIT]
> *(bé: "Red!"; bé bỏ đồ đỏ vào rổ · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** [praise] Red! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Find BLUE! [WAIT]
> *(bé: "Blue!" · sai/im: Mya đọc mẫu «Blue!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Blue! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Find GREEN! [WAIT]
> *(bé: "Gờ-rin!" · sai/im: Mya đọc mẫu «Green!»)*
> **Mya:** [praise] Green! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 🟥

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya gọi sai màu |
| Mya | Cầm đồ đỏ nói "blue"; giơ tờ xanh lá hỏi "yellow?" |
| Bố/mẹ | Đưa đồ cho Mya cầm (giơ trước màn); nhắc nhỏ: "Mya nói sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya (câu nối):** [vi] Săn màu xong rồi, giỏi quá! [pause 1s] Giờ con làm cô giáo của Mya nhé.
>
> **Mya:** *(Mya cầm bút đỏ nhưng cố tình nói blue)* [cheerful] Look! [pause] BLUE! [WAIT]
> *(bé: "No! Red!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** [gasp] Oh no! [pause] It's RED! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(giơ tờ xanh lá)* [puzzled] And this… [pause] [ask] yellow? [WAIT]
> *(bé: "No! Green!" · sai/im: Mya đọc mẫu «Green!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] GREEN! Green! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, chào từng màu, nói "bye-bye" |
| Mya | Vẫy chào từng tờ giấy màu, khen cụ thể, chào bé |
| Bố/mẹ | Giơ lần lượt 4 tờ giấy, dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya (câu nối):** [vi] Mình học xong rồi, con giỏi lắm! [pause 1s] Giờ mình chào nhau nhé.
>
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, red! [pause] Bye-bye, blue!
> *(vẫy từng tờ giấy màu)*
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, yel-low! [pause] Bye-bye, green!
> **Mya:** [vi] Hôm nay con nói được màu xanh, màu vàng. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bố/mẹ dán sticker)*
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🎨, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói màu bằng tiếng Việt ("màu đỏ") | Công nhận rồi bắc cầu: "Màu đỏ! Red! It's red!" Không bắt nói lại ngay. |
| Bé lẫn blue / green | Không phải lỗi của bé. "[cheerful] Almost! [pause] Green… like a tree!" chỉ vào cây; không sửa quá 1 lần mỗi vòng. |
| Bé chỉ nói "blue" thay vì "It's blue." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung khi săn màu | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Look! [pause] Red!". Không mắng. |
| Bé kể đồ màu khác ("cái này màu tím") | Theo bé 1 lượt ("Wow!"), rồi quay lại 4 màu của bài. Không dạy thêm màu. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé chạm đúng 3/4 màu khi nghe.
2. Bé nói được 2 màu.
3. Bé nói "It's ___." (hoặc tên màu) khi được hỏi "What color is it?".

**Số đo của buổi 4** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 4 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 6 |
| Từ đích bé dùng | ≥ 2 màu |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 30%, vượt 40% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Chạm đúng màu | | | | |
| Gọi tên màu | | | | |
| It's ___ | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Lúc mặc quần áo hỏi "What color?" — bé chỉ hoặc nói là được.
- Đi dạo: chỉ trời ("blue!"), lá ("green!"), không bắt bé nói lại.
- Ngày giữa hai buổi: mở bài hát màu khi bé chơi, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 5 — Animals. It's a cat.) ôn bài này bằng màu của con vật.

---

## 9. Cho app (thư mục `Resources/Lessons/04-colors/`)

Thư mục bài gồm `lesson.json` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji hoặc file trong `images/`), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 6.

