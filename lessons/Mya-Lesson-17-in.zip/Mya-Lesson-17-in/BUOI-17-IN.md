# Buổi 17 — In, on, under.

Buổi thứ mười bảy: bé tìm quả bóng trốn trong hộp, đặt bóng vào trong, lên trên, xuống dưới hộp theo lời Mya, trả lời "Where's the ball?" bằng "In the box." / "On the box." / "Under the box.", nói cả câu "The ball is in the box.", và sửa khi Mya nói nhầm chỗ quả bóng.
File này gom mọi thứ của buổi 17 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/17-in/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 17) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–16, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 24% lượt của Mya |
| Từ mới | 3 từ: in, on, under; cụm "in the box" học như cụm, không giải thích |
| Sản phẩm cuối buổi | Bé làm đúng 3/4 lệnh đặt bóng, nói "In the box." (hoặc chỉ "In!") ít nhất 1 lần, tìm đúng đồ đã giấu |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nghe "Put it in!", "Put it on the box!", "Put it under the box!" thì đặt bóng đúng chỗ.
- Trả lời "Where's the ball?" bằng "In the box." / "On the box." / "Under the box." khi nhìn quả bóng và cái hộp.
- Nói cả câu "The ball is in the box." một lần (nói theo mẫu cũng được).
- Tự hỏi Mya "Where's the ball?".
- Vẫn đếm "How many?" với khối tới 8 và nói "It's a ball." (ôn buổi 16 và 11).
- Sửa Mya khi Mya nói bóng "in" mà bóng đang ở trên hộp.

Không kỳ vọng: phân biệt chắc chắn cả ba từ ngay trong buổi này, nói "the" cho đúng. Bé nói "on" cho mọi vị trí là bình thường: ba từ này cần 2–3 tuần mới chắc, sẽ được lặp lại ở các buổi sau. Bé chỉ nói "In!" hay "Under!" là **đạt**; Mya chỉ mời bé nói cả câu "The ball is in the box." một lần.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| In the box. | Ở trong hộp. | nói | in the box, in, in box, the box, it's in the box, no in the box, no in, in đờ bóc, in bóc, no |
| On the box. | Ở trên hộp. | nói | on the box, on, on box, it's on the box, no on the box, no on, on đờ bóc, on bóc, no |
| Under the box. | Ở dưới hộp. | nói | under the box, under, under box, it's under the box, no under the box, no under, ăn đơ đờ bóc, ăn đơ, ăn đờ, no |
| The ball is in the box. | Bóng ở trong hộp. | nói | the ball is in the box, ball is in the box, ball in the box, the ball in the box, in the box, đờ bon ít in đờ bóc, bon in đờ bóc |
| Where's the ball? | Bóng đâu? | nghe + nói (bé hỏi Mya) | where's the ball, where is the ball, where ball, where's ball, que đờ bon, que bon |
| On my head. | Trên đầu con (bộ phận cơ thể, buổi 6 và 12) | nói | on my head, my head, on head, on your head, head, on, on mai hét, mai hét |
| Put it in! / Put it on the box! / Put it under the box! | Bỏ vào trong / Đặt lên trên hộp / Giấu dưới hộp | nghe + làm | put it in / put it on the box / put it under the box |
| Put the ball in the box! / Put teddy on your head! | Cất bóng vào hộp / Đặt gấu lên đầu | nghe + làm | put the ball in the box / put teddy on your head |
| Where's the teddy? | Gấu đâu? (ôn buổi 11) | nghe + làm | where's the teddy |
| Six! / Eight! / Ten! | Sáu / Tám / Mười (ôn buổi 16) | nói | six, six blocks, xích / eight, eight blocks, ết, ây / ten, nine ten, ten fingers, tèn |
| It's a ball. | Đây là quả bóng (ôn buổi 11) | nói | it's a ball, it is a ball, a ball, ball, ít ơ bon, bon |
| Bye-bye, ball! | Tạm biệt bóng! | nói | bye-bye ball, bye bye ball, bye-bye, bai bai bon |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** put, it, the, is, box, ball, teddy, peekaboo, now, my, your, head (và các từ của buổi 1–16: one … ten, blocks, fingers, how many, what's this, it's a, where's, said, clap, shh, hmm…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 1 cái hộp có nắp, đủ to để bỏ vừa quả bóng (hộp giày là vừa); 1 quả bóng (của buổi 11); 8 khối gạch đồ chơi (buổi 16); 1 con gấu bông; 1 cái khăn; 1 cái ghế; loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** chant theo điệu "Where is Thumbkin?" (lời ở giáo trình buổi 17), hát ở chặng 6. Bố/mẹ bấm Space tạm dừng app, cùng bé đi vòng quanh và hát; app không phát bài hát.
**Thẻ tranh trên màn hình** (emoji, thẻ `wave` và `ball` của app, 3 hình SVG chép từ buổi 16, 4 hình SVG mới; thẻ đếm tên `<loại>-N` có đúng N vật để máy so với số Mya nói):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| `fingers-10` (hai bàn tay xòe, của buổi 16) | Ten! | 1 |
| `blocks-6`, `blocks-8` (của buổi 16) | Six!, Eight! | 2 |
| `ball` (quả bóng đỏ, thẻ của app) | It's a ball., Look!, Where's the ball? | 2, 3, 6 |
| 📦 (hộp đóng, bóng đang trốn) | Where's the ball? | 3, 5 |
| `ball-in-box.svg` (hộp mở, bóng nằm trong) | In the box., Put it in!, The ball is in the box., Bye-bye, ball! | 3, 4, 5, 7, 8 |
| `ball-on-box.svg` (hộp đóng, bóng nằm trên nắp) | Put it on the box!, On the box. | 4, 5, 7 |
| `ball-under-box.svg` (hộp úp kênh một mép, bóng lộ ra bên dưới) | Under the box. | 4, 5, 7 |
| 🎵 | Stand up! (lúc hát) | 6 |
| 🧸 | Where's the teddy? | 6 |
| `teddy-on-head.svg` (gấu ngồi trên đầu một bé vẽ hoạt hình) | On your head!, On my head. | 6 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại quả bóng đang ở đâu so với cái hộp.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Để hộp, bóng, 8 khối, gấu bông, khăn cạnh mình, ngoài tầm tay bé; kê một cái ghế gần đó. Dọn một khoảng trống cho bé đi lại lúc tìm đồ. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` `fingers-10`

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you?, và đếm nhanh 1–10 cùng Mya bằng ngón tay |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi đếm one … nine để bé nói "Ten!" |
| Bố/mẹ | Vẫy tay cùng bé; xòe hai bàn tay, gập từng ngón **đúng lúc** Mya đếm |
| Ra khi | Bé đã chào hoặc trả lời, và nói (hoặc nói theo) "Ten!" |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ xòe hai bàn tay, gập từng ngón đúng lúc Mya đếm)* [vi] Mình đếm tới mười nhé! [pause] [slow] One, two, three, four, five, six, seven, eight, nine… [WAIT]
> *(bé: "Ten!" · sai/im: Mya đọc mẫu «Ten!»)*
> **Mya:** [excited] TEN! [pause] Ten fingers! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `blocks-6` `blocks-8` `ball`

| | |
|---|---|
| Mục đích | Ôn hai thứ cũ: đếm khối (buổi 16) và "It's a ball." (buổi 11), không dạy mới |
| Mya | Hỏi How many? với 6 khối rồi 8 khối, rồi What's this? với quả bóng |
| Bố/mẹ | Xếp khối thành hàng, thêm khối **trước** câu hỏi; cất khối, giơ quả bóng **trước** câu What's this? |
| Ra khi | Bé đã trả lời 3 câu, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ xếp sẵn 6 khối thành một hàng trước mặt bé; để 2 khối nữa và quả bóng cạnh mình)* [vi] Đếm tới mười rồi, giỏi quá! [pause 1s] Giờ mình ôn đếm khối và đồ chơi nhé.
> **Mya:** *(bố/mẹ chỉ vào từng khối cho bé đếm)* [cheerful] Look! Blocks! [pause] [ask] How many? [WAIT]
> *(bé: "Xích!" · sai/im: Mya đọc mẫu «Six!»)*
> **Mya:** [praise] SIX! [pause] Six blocks! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ thêm 2 khối vào hàng, từng khối một)* [excited] One more… [pause] and one more! [pause] [ask] How many? [WAIT]
> *(bé: "Ết!" · sai/im: Mya đọc mẫu «Eight!»)*
> **Mya:** [excited] EIGHT! [pause] Eight blocks! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ cất khối, giơ quả bóng)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Ít ơ bon." · sai/im: Mya đọc mẫu «It's a ball.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's a ball! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ `ball` 📦 `ball-in-box.svg`

| | |
|---|---|
| Mục đích | Gây tò mò: quả bóng biến mất trong hộp, Mya mở hộp "Peekaboo! In the box!" |
| Mya | Thì thầm hỏi Where's the ball?, chờ bé chỉ, mở hộp, mời bé nói "In the box." |
| Bố/mẹ | Bỏ bóng vào hộp **ngay trước mắt bé**, đậy nắp; mở nắp đúng lúc "Peekaboo!" |
| Ra khi | Bé nói (hoặc nói theo) "In the box." |

> **Mya:** *(bố/mẹ đặt cái hộp có nắp trước mặt bé, tay cầm quả bóng)* [vi] Ôn xong rồi, con giỏi lắm! [pause 1s] Giờ xem bóng của Mya trốn ở đâu nhé.
> **Mya:** *(bố/mẹ giơ quả bóng lên cho bé xem)* [cheerful] Look! [pause] The BALL!
> **Mya:** *(trước câu này bố/mẹ bỏ bóng vào hộp ngay trước mắt bé, đậy nắp; khẽ hỏi bé: bóng đâu rồi, con chỉ đi)* [whisper] Shh… [pause] Where's the BALL? [WAIT]
> *(bé: "👉"; bé chỉ vào hộp · sai/im: Mya đọc mẫu «Where's the BALL?»)*
> **Mya:** *(bố/mẹ mở nắp hộp đúng lúc Mya nói Peekaboo!)* [gasp] Peekaboo! [pause] IN the box!
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] IN the box. [WAIT]
> *(bé: "In đờ bóc." · sai/im: Mya đọc mẫu «In the box.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said in the box! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `ball-in-box.svg` `ball-on-box.svg` `ball-under-box.svg`

| | |
|---|---|
| Mục đích | Hiểu in / on / under bằng tay: bé tự đặt bóng vào trong, lên trên, xuống dưới hộp; chưa cần nói |
| Mya | "Put it in!", "Put it on the box!", "Put it under the box!" |
| Bố/mẹ | Đưa bóng cho bé trước mỗi lệnh; đậy nắp trước lệnh "on"; úp hộp và nhấc một mép trước lệnh "under" |
| Ra khi | Bé làm ≥ 2 trong 3 việc |

> **Mya:** *(bố/mẹ lấy bóng ra đưa cho bé, để hộp mở nắp trước mặt bé)* [vi] Bóng trốn trong hộp rồi! [pause 1s] Giờ Mya nói, con đặt bóng theo nhé.
> **Mya:** *(bố/mẹ chỉ vào lòng hộp)* [cheerful] Put it IN! [pause] [vi] Con bỏ bóng vào hộp nào! [WAIT]
> *(bé: "👉"; bé bỏ bóng vào hộp · sai/im: Mya đọc mẫu «Put it IN!»)*
> **Mya:** [excited] Yes! [pause] IN the box! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ lấy bóng ra đưa bé, đậy nắp hộp)* [cheerful] Now, put it ON the box! [WAIT]
> *(bé: "👉"; bé đặt bóng lên nắp hộp · sai/im: Mya đọc mẫu «Put it ON the box!»)*
> **Mya:** [praise] Yes! ON the box! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ lấy bóng ra đưa bé, úp hộp xuống và nhấc một mép lên)* [whisper] Now… [pause] put it UNDER the box! [pause] [vi] Con giấu bóng dưới hộp ấy. [WAIT]
> *(bé: "👉"; bé nhét bóng xuống dưới hộp, bố/mẹ hạ hộp xuống · sai/im: Mya đọc mẫu «Under the box.»)*
> **Mya:** [giggle] UNDER the box! [pause] Wo-ow! *(chỉ khi bé đúng)*

Bé đặt bóng sai chỗ → không sao, bố/mẹ cầm tay bé đặt lại cùng, Mya vẫn khen. Bé chỉ thích bỏ vào trong → làm "in" thêm một lần rồi mới sang "on".

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `ball-in-box.svg` `ball-on-box.svg` `ball-under-box.svg` 📦

| | |
|---|---|
| Mục đích | Bé giấu bóng, trả lời "Where's the ball?" bằng "In / On / Under the box.", nói cả câu "The ball is in the box." một lần, rồi tự hỏi Mya |
| Mya | Vòng 1: trong hộp (cụm, rồi cả câu). Vòng 2: trên hộp. Vòng 3: dưới hộp. Cuối: bé hỏi Mya "Where's the ball?" |
| Bố/mẹ | Cùng bé giấu bóng **trước** mỗi câu hỏi; chỉ vào bóng khi bé bí; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng và lượt bé hỏi, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ cùng bé bỏ bóng vào hộp, để mở nắp; thì thầm mẫu khi bé bí 2 lần liền)* [vi] Con đặt bóng giỏi quá! [pause 1s] Giờ con giấu bóng, Mya hỏi bóng ở đâu nhé.
> **Mya:** *(bố/mẹ chỉ vào hộp)* [ask] Where's the BALL? [WAIT]
> *(bé: "In đờ bóc!" · sai/im: Mya đọc mẫu «In the box.»)*
> **Mya:** [praise] IN the box! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] The ball is IN the box. [WAIT]
> *(bé: "Đờ bon ít in đờ bóc." · sai/im: Mya đọc mẫu «The ball is in the box.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said the ball is in the box! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ cùng bé lấy bóng ra, đậy nắp, đặt bóng lên nắp hộp)* [cheerful] Now… [pause] [ask] Where's the ball? [WAIT]
> *(bé: "On đờ bóc." · sai/im: Mya đọc mẫu «On the box.»)*
> **Mya:** [excited] ON the box! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bé giấu bóng dưới hộp úp, bố/mẹ giúp nhấc mép hộp)* [whisper] Shh… [pause] [ask] Where's the ball? [WAIT]
> *(bé: "Ăn-đơ đờ bóc." · sai/im: Mya đọc mẫu «Under the box.»)*
> **Mya:** [praise] You said under the box! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ giấu bóng vào hộp, đậy nắp; thì thầm mẫu cho bé hỏi)* [vi] Con hỏi Mya đi: [pause] [slow] Where's the BALL? [WAIT]
> *(bé: "Que đờ bon?" · sai/im: Mya đọc mẫu «Where's the BALL?»)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở nắp hộp đúng lúc Mya nói In the box!)* [giggle] Hmm… [pause] IN the box! [pause] Thank you! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** bé nói "In!" hay "In the box!" là đúng; Mya khen rồi nói mẫu "The ball is in the box." và mời bé nói cả câu một lần. Bé nói "Ball in the box." cũng tính đúng. Không bắt bé nói lại cho đủ "the".

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «In the box.») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào quả bóng khi Mya đọc mẫu. Bé nói "on" cho mọi vị trí → không sửa bằng lời; bố/mẹ chỉ vào bóng, nói nhỏ "in… in the box" rồi đi tiếp. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự giấu bóng ở chỗ khác (dưới ghế, trên ghế) rồi hỏi Mya, và bỏ chặng 7. **Bé ngơ:** chỉ làm vòng 1 và vòng 2 (in và on).

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 🧸 `ball` `teddy-on-head.svg`

| | |
|---|---|
| Mục đích | Xả năng lượng: hát chant, đi tìm gấu (dưới khăn) và bóng (trên ghế), rồi đặt gấu lên đầu |
| Mya | Stand up!, Where's the teddy?, Where's the ball?, Put teddy on your head!, Where's teddy? |
| Bố/mẹ | Giấu đồ lúc bé nhắm mắt; bấm Space tạm dừng app lúc hát; đi cùng bé, gợi ý nhỏ chỗ giấu; đặt gấu lên đầu mình làm mẫu |
| Ra khi | Hết giờ hoặc bé đã tìm đủ đồ và nói (hoặc nói theo) "On my head." |

> **Mya:** *(bố/mẹ bảo bé nhắm mắt, giấu gấu bông dưới khăn và quả bóng trên ghế)* [vi] Con hỏi giỏi quá! [pause 1s] Giờ mình đứng dậy hát, rồi đi tìm đồ nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, cùng bé đi vòng quanh và hát chant theo điệu "Where is Thumbkin?"; xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ đi cùng bé, gợi ý nhỏ: gấu ở dưới khăn)* [whisper] Shh… [pause] [ask] Where's the TEDDY? [pause] [vi] Con tìm bạn gấu nào! [WAIT]
> *(bé: "👉"; bé tìm thấy gấu dưới khăn · sai/im: Mya đọc mẫu «Where's the TEDDY?»)*
> **Mya:** [gasp] Peekaboo, teddy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đi cùng bé, gợi ý nhỏ: bóng ở trên ghế)* [excited] Now the BALL! [pause] [ask] Where's the ball? [WAIT]
> *(bé: "👉"; bé tìm thấy bóng trên ghế · sai/im: Mya đọc mẫu «Where's the BALL?»)*
> **Mya:** [excited] Wo-ow! [pause] The BALL! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa gấu cho bé, đặt thử lên đầu mình làm mẫu)* [giggle] Now… [pause] put teddy ON your head! [WAIT]
> *(bé: "👉"; bé đặt gấu lên đầu · sai/im: Mya đọc mẫu «ON your head!»)*
> **Mya:** [giggle] Wo-ow! [pause] Teddy is ON your head! *(chỉ khi bé đúng)*
> **Mya:** *(bé vẫn giữ gấu trên đầu; bố/mẹ chỉ lên đầu bé)* [ask] Where's teddy? [WAIT]
> *(bé: "On mai hét!" · sai/im: Mya đọc mẫu «On my head.»)*
> **Mya:** *(vẫy, `wave`)* [praise] ON your head! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `ball-on-box.svg` `ball-under-box.svg` `ball-in-box.svg`

| | |
|---|---|
| Mục đích | Bé sửa Mya ba lần: bóng trên hộp mà Mya nói "in", bóng dưới hộp mà Mya nói "on", bóng trong hộp mà Mya nói "under" |
| Mya | Nói nhầm chỗ quả bóng rồi chờ bé sửa |
| Bố/mẹ | Đặt bóng đúng chỗ **trước** mỗi câu; lắc đầu, chỉ vào bóng, nhắc: "Mya nói nhầm rồi, con sửa Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ đặt bóng lên nắp hộp; nhắc nhỏ: Mya nói nhầm thì con sửa Mya nhé)* [vi] Tìm đồ giỏi quá! [pause 1s] Giờ Mya nói, Mya nói nhầm thì con sửa nhé.
> **Mya:** *(Mya cố tình nói nhầm; bố/mẹ lắc đầu, chỉ vào quả bóng trên nắp hộp)* [cheerful] Look! [pause] The ball is IN the box! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! On đờ bóc!" · sai/im: Mya đọc mẫu «On the box.»)*
> **Mya:** [gasp] Oh! [pause] ON the box! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giấu bóng dưới hộp úp, để lộ một chút; Mya cố tình nói nhầm)* [puzzled] Hmm… [pause] The ball is ON the box! [WAIT]
> *(bé: "No! Ăn-đơ!" · sai/im: Mya đọc mẫu «Under the box.»)*
> **Mya:** [giggle] UNDER the box! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ bỏ bóng vào hộp, để mở nắp; Mya cố tình nói nhầm)* [cheerful] Look! [pause] The ball is UNDER the box! [WAIT]
> *(bé: "No! In đờ bóc!" · sai/im: Mya đọc mẫu «In the box.»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh! [pause] IN the box! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé chỉ nói "No!" cũng tính là đã sửa. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `ball-in-box.svg` `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: cất bóng đúng chỗ, chào bóng, nói "bye-bye" |
| Mya | "Put the ball in the box!", "Bye-bye, ball!", khen cụ thể, chào bé |
| Bố/mẹ | Đưa bóng cho bé cất; vẫy tay cùng bé; dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ lấy bóng ra đưa cho bé, để hộp mở nắp)* [vi] Con sửa Mya giỏi quá! [pause 1s] Sắp hết giờ rồi, mình cất bóng vào hộp nhé.
> **Mya:** [cheerful] Put the ball IN the box! [WAIT]
> *(bé: "👉"; bé bỏ bóng vào hộp, đậy nắp · sai/im: Mya đọc mẫu «Put it IN!»)*
> **Mya:** [praise] IN the box! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, ball! [pause] Your turn! [WAIT]
> *(bé: "Bai-bai, bon!" · sai/im: Mya đọc mẫu «Bye-bye, ball!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [vi] Hôm nay con nói được trong, trên, dưới. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 📦, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói "on" cho mọi vị trí | Bình thường, 3 từ này cần 2–3 tuần. Không sửa bằng lời; bố/mẹ chỉ vào bóng, nói nhỏ từ đúng một lần rồi đi tiếp. |
| Bé chỉ nói "In!" | Tính là đúng. Mya nói lại cả câu "The ball is in the box." 1 lần rồi đi tiếp. |
| Bé nói bằng tiếng Việt ("trong hộp") | Công nhận rồi bắc cầu: "Trong hộp! In the box!" Không bắt nói lại ngay. |
| Nhà không có hộp có nắp | Dùng cái rổ hay cái chậu nhỏ úp được; Mya vẫn nói "box" như lời của bài, bố/mẹ chỉ vào thẻ trên màn hình. |
| Bé giữ khư khư quả bóng, không chịu bỏ vào | Chơi cùng 1 lượt ("Ball! Wow!"), rồi bố/mẹ làm mẫu, bé xem. Không giằng lấy. |
| Bé mở hộp trước khi Mya hỏi | Không sao: Mya vẫn hỏi, bé chỉ vào là được. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc tìm đồ | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé không chịu đặt gấu lên đầu | Bố/mẹ đặt gấu lên đầu mình, Mya hỏi bé "Where's teddy?"; bé chỉ vào là được. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé làm đúng 3/4 lệnh đặt bóng (in / on / under, cất bóng vào hộp).
2. Bé nói "In the box." (hoặc chỉ "In!") ít nhất 1 lần.
3. Bé tìm đúng đồ đã giấu ở chặng 6, hoặc sửa được Mya ở chặng 7.

**Số đo của buổi 17** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 17 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 12 |
| Lượt bé nói in / on / under | ≥ 4 |
| Câu ≥ 3 từ bé nói ("In the box.", "The ball is in the box.") | ≥ 2 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 24%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| in / on / under | | | | |
| Where's the ball? → In the box. | | | | |
| The ball is in the box. | | | | |
| Sửa Mya | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Giấu một món đồ chơi ở 3 chỗ (trong hộp, trên ghế, dưới gối); bé đi tìm, bố/mẹ hỏi "Where's the ball?", bé chỉ hoặc nói "In the box!".
- Lúc dọn đồ chơi: "Put it in the box!"; bé làm theo là đạt, không bắt nói.
- Đặt gấu lên đầu bé: "Where's teddy? On your head!"
- Hát chant "Where is the ball?" theo điệu "Where is Thumbkin?" lúc chơi, không bắt bé hát theo.
- Bố/mẹ không sửa phát âm, không sửa khi bé nói "on" cho mọi chỗ, không nói "con nói đi" quá 2 lần.

Buổi sau là Buổi 18 — Zoo animals (lion, elephant, monkey, tiger).

---

## 9. Cho app (thư mục `Resources/Lessons/17-in/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt Mya cố tình nói nhầm chỗ ở chặng 7 (teach_mya-2, teach_mya-4, teach_mya-6) có `"mistake": true`.
- Lượt "The ball is in the box." nhận cả khi bé chỉ nói "in the box" (biến thể ở `target_chunks`); lượt sửa Mya ở chặng 7 nhận cả "No!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, Well done!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Con hỏi Mya đi:", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./Bye-bye! và See you next time!
- Câu lấy nguyên văn từ bài cũ dùng lại file tiếng, không thu lại: buổi 16 (recall-2 = talk-2, recall-4 = talk-6; câu mẫu Six!/Eight!/Ten!), buổi 11 (recall-6 = talk-2, recall-7 = talk-5, move-3 = listen_do-10; câu mẫu It's a ball./Where's the TEDDY?), buổi 12 (talk-2 = recall-2).
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; `wave`, `ball` là thẻ của app; `images/blocks-6`, `blocks-8`, `fingers-10` chép từ buổi 16; `ball-in-box.svg`, `ball-on-box.svg`, `ball-under-box.svg`, `teddy-on-head.svg` vẽ riêng), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 19.
