# Buổi 2 — How are you? I'm happy.

Buổi thứ hai: bé nhận ra 4 mặt cảm xúc (happy, sad, angry, sleepy), trả lời "How are you?" và nói "Yes" / "No".
File này gom mọi thứ của buổi 2 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/02-happy/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 2) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 4 tuổi, đã học buổi 1, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 40% lượt của Mya (hướng dẫn, trấn an, cứu hộ) |
| Từ mới | How are you?, I'm happy., happy / sad / angry / sleepy, Yes / No |
| Sản phẩm cuối buổi | Bé làm mặt và nói 1 cảm xúc |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nghe "How are you?" thì trả lời bằng mặt hoặc giọng, rồi bằng "happy".
- Nói "I'm happy." (hoặc chỉ "happy") và "Yes" / "No" (gật / lắc cũng tính).
- Làm đúng mặt khi nghe happy, sad, angry, sleepy.

Không kỳ vọng: nói cả 4 từ cảm xúc, phát âm đúng "happy" (bé nói "háp-bi" là bình thường).

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| How are you? | Con thấy thế nào? | nghe (bé hỏi lại Mya ở vòng 3 là thưởng thêm) | how are you, hao a du, how you |
| I'm happy. | Con vui. | nói | i'm happy, am happy, happy, háp pi, con vui |
| happy | vui | nói | happy, háp pi, hap py, happi |
| sad | buồn | nói | sad, sát, set, sed |
| angry | tức | nghe + làm mặt | angry, en gờ ri, angri |
| sleepy | buồn ngủ | nói | sleepy, sờ li pi, slipi, sleep |
| Yes! | Có / Đúng | nói | yes, dét, ye, yeah; gật đầu cũng tính |
| No! | Không | nói | no, nô, nâu; lắc đầu cũng tính |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** today, now, or, said, grrr, jump, shh, see you next time (và các từ của buổi 1: what's your name, you're).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** gương, 4 thẻ mặt vẽ tay (vui, buồn, tức, buồn ngủ), gấu bông, chăn nhỏ, sticker mặt cười, loa.
**Bài hát:** "If You're Happy" (Super Simple Songs) ở chặng 6. Bố/mẹ mở trên loa, app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình:**

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, I'm Bông!, Bye-bye! | 1, 8 |
| `ball` | Hello, I'm ___!, Hello, I'm Bông! | 2 |
| `qmark` → sẽ là `faceSad` *(chưa vẽ)* | sad, How are you? | 3, 4, 7 |
| `qmark` → sẽ là `faceHappy` *(chưa vẽ)* | happy, How are you?, I'm happy., Yes! | 3, 4, 5, 6 |
| `qmark` → sẽ là `faceAngry` *(chưa vẽ)* | angry | 3, 4 |
| `qmark` → sẽ là `faceSleepy` *(chưa vẽ)* | sleepy | 3, 4, 6, 7 |

Mya cũng tự đổi mặt (vui / buồn / buồn ngủ) theo câu nói, nên khi chưa có thẻ mặt thì bé vẫn nhìn mặt Mya được.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn buổi 1 |
| Mya | Chào, hỏi tên, khoe mình đang vui |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc nói tên |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name? [WAIT]
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(Mya cười thật tươi)* [excited] I'm HAPPY today! [giggle]

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `ball`

| | |
|---|---|
| Mục đích | Ôn "Hello, I'm ___" nhanh hơn buổi 1 |
| Mya | Đếm lượt, làm mẫu, hô nhanh |
| Bố/mẹ | Chuyền bóng, nói "Hello, I'm Mommy!" thật nhanh |
| Ra khi | Bóng đi đủ 2 vòng |

> **Mya:** [vi] Chuyền bóng nhanh nào! Ai cầm bóng thì chào!
> **Mya:** *(vẫy, `wave`)* [cheerful] My turn! [pause] Hello, I'm MYA!
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Bông, your turn! [pause] [slow] Hello, I'm… [WAIT]
> *(bé: "Hello, am Bông!" · sai/im: Mya đọc mẫu «Hello, I'm Bông!»)*
> **Mya:** [praise] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Again! [pause] Mommy, your turn!
> *(bố/mẹ: "Hello, I'm Mommy!" rồi chuyền bóng lại cho bé)*
> **Mya:** *(nghiêng đầu, `listen`)* [excited] Bông, your turn! [pause] Hello… [WAIT]
> *(bé: "Hello, I'm Bông!" · sai/im: Mya đọc mẫu «Hello, I'm Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ `qmark` (sẽ là `faceSad`)

| | |
|---|---|
| Mục đích | Gây tò mò bằng một Mya đang buồn; giới thiệu 4 mặt |
| Mya | Mếu, nhờ bé hỏi thăm, rồi cười; lần lượt làm 4 mặt |
| Bố/mẹ | Ngồi im xem, chỉ vào mặt Mya |
| Ra khi | Đã thấy đủ 4 mặt |

> **Mya:** *(Mya mếu, cúi đầu)* [soft] Oh no… [pause] I'm SAD.
> **Mya:** [soft] [vi] Mya buồn quá. Con hỏi Mya: [pause] [slow] How are you? [WAIT]
> *(bé: "Hao a du?" · sai/im: Mya đọc mẫu «How are you?»)*
> **Mya:** *(vẫy, `wave`)* [gasp] [excited] Thank you! [pause] Now I'm HAPPY! *(chỉ khi bé đúng)*
> **Mya:** [vi] Mya có bốn cái mặt nè! [pause] [cheerful] Look! [pause] HAPPY!
> **Mya:** *(Mya mếu)* [soft] SAD…
> **Mya:** *(Mya nhăn mặt)* [excited] ANGRY! [pause] Grrr!
> **Mya:** *(Mya ngáp, nhắm mắt)* [soft] Slee-py… [pause] Shh…

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `qmark` (sẽ là `faceHappy`)

| | |
|---|---|
| Mục đích | Hiểu 4 từ qua mặt mình trong gương, chưa cần nói |
| Mya | Nói từ, bé làm mặt; khen ngay |
| Bố/mẹ | Cầm gương cho bé; làm mặt cùng bé ở 2 từ đầu |
| Ra khi | Bé làm đúng ≥ 3 mặt |

> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] HAPPY! [pause] [vi] Con làm mặt vui trong gương nào! [WAIT]
> *(bé: "😊" · sai/im: Mya đọc mẫu «Happy!»)*
> **Mya:** [praise] Ye-es! Happy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [soft] SAD… [pause] [vi] Mặt buồn nào! [WAIT]
> *(bé: "😢" · sai/im: Mya đọc mẫu «Sad.»)*
> **Mya:** [praise] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [soft] Slee-py… [WAIT]
> *(bé: "😴" · sai/im: Mya đọc mẫu «Sleepy.»)*
> **Mya:** [giggle] [cheerful] Sleepy! Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] ANGRY! Grrr! [WAIT]
> *(bé: "😠" · sai/im: Mya đọc mẫu «Angry!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! Angry! [pause] High five! *(chỉ khi bé đúng)*

Đổi thứ tự 4 từ cho bé phải nghe chứ không đoán. Bé làm sai mặt → "[cheerful] Almost! [pause] Try again!" và Mya làm mẫu mặt đó.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `qmark` (sẽ là `faceHappy`)

| | |
|---|---|
| Mục đích | Bé trả lời "How are you?", nói Yes / No, hỏi lại Mya |
| Mya | Vòng 1: How are you? Vòng 2: Are you happy? Yes/No. Vòng 3: bé hỏi Mya |
| Bố/mẹ | Chỉ thì thầm mẫu khi bé bí 2 lần liền; không nói "con nói đi" quá 2 lần |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

**Vòng 1 — How are you?**

> **Mya:** *(vẫy, `wave`)* [cheerful] Hello! [pause] [ask] How are you? [WAIT]
> *(Mya chờ bé 4,5 giây · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** [vi] Con vui hay buồn? [pause] [ask] Happy… or sad? [WAIT]
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «Happy!»)*
> **Mya:** [praise] Ye-es! I'm HAPPY! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] "I'm happy." [WAIT]
> *(bé: "Am háp-bi!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! You said HAPPY! [pause] High five! *(chỉ khi bé đúng)*

**Vòng 2 — Are you happy? Yes / No**

> **Mya:** *(Mya gật đầu khi nói happy)* [vi] Con gật hoặc lắc đầu nhé! [pause] [cheerful] Are you HAPPY? [WAIT]
> *(bé: "Yes!"; gật đầu cũng tính · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [praise] Ye-es! You're happy! *(chỉ khi bé đúng)*
> **Mya:** [soft] Are you SAD? [WAIT]
> *(bé: "No!"; lắc đầu cũng tính · sai/im: Mya đọc mẫu «No!»)*
> **Mya:** [giggle] [cheerful] No! Happy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [puzzled] Are you… SLEEPY? [WAIT]
> *(bé: "Nô!" · sai/im: Mya đọc mẫu «No!»)*
> **Mya:** [excited] No! [pause] Well do-one! *(chỉ khi bé đúng)*

**Vòng 3 — Bé hỏi lại Mya**

> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [vi] Con hỏi Mya đi: [pause] [slow] "How are you?" [WAIT]
> *(bé: "How you?" · sai/im: Mya đọc mẫu «How are you?»)*
> **Mya:** *(vẫy, `wave`)* [excited] I'm HAPPY! [pause] Thank you! [giggle] *(chỉ khi bé đúng)*

**Nếu bé im — thang gợi ý, đi đúng thứ tự, không nhảy bậc:**

| Bậc | Mya làm gì | Lời mẫu ở buổi 2 | Chờ |
|---|---|---|---|
| 1 | Lặp chậm hơn + động tác | "[slow] How… are… you?" *(chỉ vào bé)* [WAIT] | 4,5 giây |
| 2 | Cho 2 lựa chọn | "[ask] Happy… or sad?" *(cười rồi mếu)* [WAIT] | 4,5 giây |
| 3 | Tiếng Việt 1 câu + mẫu | "[vi] Con vui thì nói 'happy' nhé. [pause] [slow] Happy." [WAIT] | 4,5 giây |
| 4 | Chấp nhận không lời | "[cheerful] Show Mya! [pause] [vi] Con làm mặt vui đi!" [WAIT] | 3 giây |
| 5 | Tự trả lời rồi chuyển | "[praise] You're ha-ppy! [pause] [cheerful] Yay!" | — |

Bé nói chưa đúng (không phải im): "[cheerful] Almost! [pause] Try again!" rồi app đọc câu mẫu. Im 12 giây → câu có/không ("[ask] Happy? [pause] Yes?" [WAIT]). Im 20 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, làm mặt nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ `qmark` (sẽ là `faceHappy`)

| | |
|---|---|
| Mục đích | Xả năng lượng, lặp happy / sleepy |
| Mya | Dẫn trò nhảy khi "happy", gục khi "sleepy" |
| Bố/mẹ | Mở "If You're Happy"; đứng lên nhảy, gục xuống cùng bé |
| Ra khi | Hết giờ |

> **Mya:** [vi] Bố mẹ mở bài hát nhé! Mình đứng lên nào! [pause] [cheerful] Stand up!
> *(bố/mẹ mở "If You're Happy")*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] Jump! [pause] Jump!
> *(cả nhà nhảy)*
> **Mya:** [soft] Slee-py… [pause] Shh…
> *(cả nhà gục xuống, nhắm mắt)*
> **Mya:** *(vẫy, `wave`)* [gasp] [excited] HAPPY! [pause] Jump! [WAIT]
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «Happy!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Wo-ow! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [slow] And now… [pause] [soft] slee-py… [WAIT]
> *(bé: "Sờ-li-pi…" · sai/im: Mya đọc mẫu «Sleepy.»)*
> **Mya:** [giggle] [cheerful] Good job! [pause] Again! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `qmark` (sẽ là `faceSad`)

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya nói một đằng, mặt một nẻo |
| Mya | Nói "happy" nhưng mặt buồn; nói "angry" nhưng mặt buồn ngủ |
| Bố/mẹ | Nhắc nhỏ: "Mặt Mya đâu có vui, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(Mya cố tình nói happy nhưng làm mặt buồn)* [vi] Mya nói đúng không nhỉ? [pause] [cheerful] I'm HAPPY! [pause] Yes? [WAIT]
> *(bé: "No! Sad!" · sai/im: Mya đọc mẫu «Sad.»)*
> **Mya:** [gasp] Oh no! [pause] I'm SAD! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(Mya nói angry nhưng mặt buồn ngủ)* [excited] I'm ANGRY! Grrr! [WAIT]
> *(bé: "Sleepy!" · sai/im: Mya đọc mẫu «Sleepy.»)*
> **Mya:** [giggle] Ye-es! I'm SLEE-py! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, nói "bye-bye" |
| Mya | Khen cụ thể, chào, khoe mình vui |
| Bố/mẹ | Dán sticker mặt cười cho bé, vẫy tay |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** [vi] Hôm nay con làm mặt vui, mặt buồn. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, Bông! [pause] I'm HAPPY! [WAIT]
> *(bố/mẹ dán sticker mặt cười)*
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 😊, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé trả lời bằng tiếng Việt ("Con vui") | Công nhận rồi bắc cầu: "À, con vui! Happy! I'm happy!" Không bắt nói lại ngay. |
| Bé nói "háp-bi", "am happy" | **Kệ.** Khen như đúng. Mya chỉ nói lại đúng 1 lần "Happy!" rồi đi tiếp. |
| Bé chỉ gật / lắc khi hỏi Yes/No | Tính là đúng. "[praise] Yes! Good job!" |
| Bé bảo mình buồn thật | Dừng trò: "[soft] [vi] Con buồn à? Mya ôm con nè." Không ép làm mặt vui. Bố/mẹ bấm "Bé đang buồn" nếu cần. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé sợ mặt "angry" | Bỏ "angry", chỉ chơi 3 mặt còn lại. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé làm đúng mặt khi nghe từ (≥ 3 mặt).
2. Bé trả lời Yes / No (nói hoặc gật / lắc).
3. Bé nói "happy" ít nhất 1 lần.

**Số đo của buổi 2** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 2 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 4 |
| Từ đích bé dùng | ≥ 2 trong happy / sad / sleepy / yes / no |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 40%, vượt 50% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Làm mặt theo từ | | | | |
| Yes / No | | | | |
| I'm happy | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Mỗi sáng hỏi "How are you?" — bé gật / lắc hoặc làm mặt là được.
- Tối đọc 1 cuốn sách tranh có mặt cảm xúc, chỉ vào mặt và nói "happy", "sad".
- Ngày giữa hai buổi: mở "If You're Happy" khi bé chơi, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 3 — Numbers 1–5. I'm four.) mở đầu bằng "Hello! I'm Mya. I'm happy! How are you?" để ôn bài này.

---

## 9. Cho app (thư mục `Resources/Lessons/02-happy/`)

Thư mục bài gồm `lesson.json` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ chưa vẽ tạm dùng `qmark`, kèm `card_todo` là tên thẻ sẽ vẽ; vẽ xong vào mockup thì thay `card` bằng `card_todo`.
- `target_utterances`: 4.

