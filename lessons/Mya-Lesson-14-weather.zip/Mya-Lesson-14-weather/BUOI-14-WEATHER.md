# Buổi 14 — Weather. It's sunny.

Buổi thứ mười bốn: bé nhận ra 4 kiểu thời tiết (sunny, rainy, windy, cold), nói "It's sunny." khi nghe "How's the weather?", nói "I'm cold." và nối trời lạnh với cái mũ.
File này gom mọi thứ của buổi 14 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/14-weather/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 14) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–13, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 23% lượt của Mya |
| Từ mới | 4 từ: sunny, rainy, windy, cold; không có cấu trúc mới (dùng lại "It's ___", nghe thêm "How's the weather?") |
| Sản phẩm cuối buổi | Bé chọn đúng 3/4 kiểu thời tiết khi nghe, nói "It's rainy." (hoặc sunny, windy) ít nhất 1 lần, nhắc được Mya khi Mya quên |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nghe "It's rainy!" (sunny, windy, cold) thì làm đúng động tác: nheo mắt, che đầu, lắc lư, ôm mình run.
- Nghe "How's the weather?" thì trả lời "It's sunny." (rainy, windy).
- Nói "I'm cold." khi run vì lạnh, và đội mũ khi Mya nói "Cold? Put on your hat!".
- Nhắc Mya khi Mya quên tên thời tiết, và sửa khi Mya nói "sunny" lúc đang mưa.

Không kỳ vọng: phân biệt "It's cold" với "I'm cold", nói "How's the weather?", phát âm rõ đuôi "-y". Bé chỉ nói "rainy" là **đạt**; Mya chỉ mời bé nói cả câu một lần. "Sunny" và "rainy" dễ lẫn vì cùng đuôi: phân biệt bằng động tác (nheo mắt là nắng, che đầu là mưa), không giải thích.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| It's sunny. | Trời nắng. | nói | it's sunny, its sunny, it sunny, sunny, ít xa ni, xa ni, sa ni |
| It's rainy. | Trời mưa. | nói | it's rainy, its rainy, it rainy, rainy, ít rê ni, rê ni, rain |
| It's windy. | Trời có gió. | nói | it's windy, its windy, it windy, windy, ít uyn đi, uyn đi, win đi |
| I'm cold. | Con lạnh. | nói | i'm cold, im cold, i cold, cold, it's cold, am côn, ai côn, côn |
| Sunny! | Nắng (bé nhắc Mya) | nói | sunny, it's sunny, xa ni, sa ni |
| Rainy! | Mưa (bé trả lời hoặc sửa Mya) | nói | rainy, it's rainy, no rainy, no! rainy, rê ni, rain, no |
| Windy! | Gió (bé nhắc Mya) | nói | windy, it's windy, uyn đi, win đi |
| Cold! | Lạnh (bé nhắc Mya) | nói | cold, it's cold, i'm cold, côn, côl, brrr |
| How's the weather? | Thời tiết thế nào? | nghe | how's the weather |
| Bye-bye, rain! | Tạm biệt mưa! | nói | bye-bye rain, bye bye rain, bye rain, bye-bye, bai bai rên, bai bai |
| I have a teddy. / I have a hat. / I have a ball. | Con có gấu bông / mũ / quả bóng (ôn buổi 13) | nói | i have a teddy, i have teddy, a teddy, teddy, ai hép ơ té đi, té đi / i have a hat, i have hat, a hat, hat, ai hép ơ hát, hát, hét / i have a ball, i have ball, a ball, ball, ai hép ơ bon, bon |
| Jump! / Put on your hat! | Nhảy / Đội mũ vào (ôn buổi 9, 12) | nghe + làm | jump / put on your hat |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** weather, how's, sun, rain, pshhh, whoosh, brrr, pitter-patter (và các từ của buổi 1–13: have, what, do, teddy, hat, ball, jump, put on, look, now, again, happy, how are you, the, said, thank you…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** gấu bông của bé (buổi 11–13); túi vải kín với cái mũ (buổi 12) và quả bóng (buổi 11) bên trong; cửa sổ nhìn ra ngoài; bình xịt nước nhỏ (loại xịt cây, đổ ít nước); quạt giấy; áo khoác của bé; một nắm giấy xé nhỏ làm "mưa giấy" (hoặc ô giấy); loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Rain Rain Go Away" hoặc "How's the Weather?" (Super Simple Songs), mở ở chặng 6. Bố/mẹ bấm Space tạm dừng app, mở bài hát trên máy khác và nhảy cùng bé; app không phát bài hát.
**Thẻ tranh trên màn hình** (emoji, 2 thẻ có sẵn của app và 1 hình SVG, mỗi thẻ một vật chính):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| 🧸 | I have a teddy. | 1 |
| 👝 (túi thần kỳ) | Look! | 2 |
| 👒 | I have a hat., Put on your hat! | 2, 5 |
| `ball` (thẻ của app, bóng đỏ) | I have a ball. | 2 |
| `jump.svg` (bé đang nhảy, của buổi 9) | Jump! | 2 |
| 🪟 | Look! | 3 |
| ☀️ | It's sunny!, It's sunny., Sunny!, Bye-bye, sun! | 3, 6, 7, 8 |
| 🌧️ | It's rainy!, Rainy!, It's rainy., Jump!, Bye-bye, rain! | 4, 5, 6, 7, 8 |
| `windy.svg` (gió xanh thổi lá) | It's windy!, Windy!, It's windy., Whoosh! | 4, 5, 6, 7 |
| 🥶 | It's cold!, Cold!, Brrr!, I'm cold. | 4, 5, 6, 7 |
| 🎵 | Stand up! (lúc mở bài hát) | 6 |

Đồ thật và trời thật là chính; thẻ trên màn chỉ nhắc lại kiểu thời tiết đang nói. Trời lúc học không nắng thì bố/mẹ chỉ vào thẻ mặt trời trên màn hình. Hình SVG chép từ buổi 9, không vẽ mới.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen gần cửa sổ. Bỏ mũ và bóng vào túi; để bình xịt, quạt giấy, áo khoác, mưa giấy cạnh mình, ngoài tầm tay bé. Trải khăn nếu sợ ướt sàn. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` 🧸

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you? và câu "I have a ___" của buổi 13 với đồ của bé |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi hỏi What do you have? |
| Bố/mẹ | Vẫy tay cùng bé; đưa gấu bông của bé vào tay bé **trước** câu hỏi What do you have? |
| Ra khi | Bé đã chào hoặc trả lời, và nói (hoặc nói theo) "I have a teddy." |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa gấu bông của bé vào tay bé)* [cheerful] Look! [pause] [ask] What do you have? [WAIT]
> *(bé: "Ai hép ơ té-đi." · sai/im: Mya đọc mẫu «I have a teddy.»)*
> **Mya:** [praise] You have a TEDDY! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 👝 👒 `ball` `jump.svg`

| | |
|---|---|
| Mục đích | Ôn 2 thứ cũ: túi thần kỳ 60 giây với "I have a ___" (buổi 13, đồ của buổi 11–12) và hành động jump (buổi 9), không dạy mới |
| Mya | Mời bé thò tay vào túi, hỏi What do you have? hai lần, rồi bảo bé nhảy |
| Bố/mẹ | Đặt túi trước mặt bé; mỗi lần cho bé lấy **một** món ra **trước** khi Mya hỏi; đứng dậy nhảy làm mẫu |
| Ra khi | Bé đã lấy ra mũ và bóng, nhảy được 1 lần, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ bỏ cái mũ và quả bóng vào túi vải kín, đặt trước mặt bé)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình chơi túi thần kỳ nhé.
> **Mya:** *(trước câu này bé thò tay vào túi, lấy cái mũ ra)* [gasp] Oh! [pause] [ask] What do you have? [WAIT]
> *(bé: "Ai hép ơ hát." · sai/im: Mya đọc mẫu «I have a hat.»)*
> **Mya:** [excited] A HAT! [pause] You have a hat! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bé thò tay vào túi, lấy quả bóng ra)* [cheerful] Again! [pause] [ask] What do you have? [WAIT]
> *(bé: "Ai hép ơ bon." · sai/im: Mya đọc mẫu «I have a ball.»)*
> **Mya:** [praise] You have a BALL! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đứng dậy, nhảy làm mẫu)* [excited] Now JUMP! [pause] Jump, jump! [WAIT]
> *(bé: "👉"; bé nhảy tại chỗ · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** [giggle] Jump, jump! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 🪟 ☀️

| | |
|---|---|
| Mục đích | Gây tò mò bằng cửa sổ: Mya "nhìn" ra ngoài và nói "It's sunny!" |
| Mya | Thì thầm, nhìn ra cửa sổ, reo lên khi thấy mặt trời, rồi mời bé nói "It's sunny." |
| Bố/mẹ | Dắt bé tới cửa sổ (hoặc kéo rèm); nheo mắt, lấy tay che trán làm mẫu; trời không nắng thì chỉ vào mặt trời trên màn hình |
| Ra khi | Bé nói (hoặc nói theo) "It's sunny." |

> **Mya:** *(bố/mẹ dắt bé tới cửa sổ hoặc kéo rèm ra; trời không nắng thì chỉ vào mặt trời trên màn hình)* [vi] Túi thần kỳ xong rồi! [pause 1s] Giờ mình nhìn ra cửa sổ nhé.
> **Mya:** [whisper] Shh… [pause] Look! [pause] [vi] Mya nhìn ra cửa sổ nè.
> **Mya:** *(bố/mẹ chỉ ra ngoài cửa sổ, nheo mắt vì chói)* [gasp] Oh! [pause] The SUN! [pause] It's SUNNY!
> **Mya:** *(bố/mẹ lấy tay che trán, nheo mắt làm mẫu cho bé)* [giggle] Sunny, sunny! [pause] I'm happy!
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] It's SUNNY. [WAIT]
> *(bé: "Ít xa-ni." · sai/im: Mya đọc mẫu «It's sunny.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said it's sunny! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 🌧️ `windy.svg` 🥶

| | |
|---|---|
| Mục đích | Hiểu rainy, windy, cold bằng đồ thật và động tác, chưa cần nói |
| Mya | Làm "mưa" (xịt nước), "gió" (quạt), "lạnh" (áo khoác), mỗi kiểu một động tác cho bé làm theo |
| Bố/mẹ | Xịt nước, quạt, khoác áo **đúng lúc** Mya nói; làm động tác mẫu; không xịt vào mặt bé |
| Ra khi | Bé làm đúng ≥ 2 động tác |

> **Mya:** *(bố/mẹ để sẵn bình xịt nước, quạt giấy, áo khoác cạnh mình; mỗi lượt làm đúng lúc Mya nói)* [vi] Trời nắng đẹp quá! [pause 1s] Giờ Mya làm mưa, làm gió nhé.
> **Mya:** *(đúng lúc Mya nói Pshhh, bố/mẹ xịt nhẹ nước lên không trung trước mặt bé, không xịt vào mặt)* [excited] Pshhh! [pause] It's RAINY! [pause] Pitter-patter!
> **Mya:** [cheerful] Rainy! [pause] [vi] Con che đầu đi! [WAIT]
> *(bé: "👉"; bé lấy hai tay che đầu · sai/im: Mya đọc mẫu «Rainy!»)*
> **Mya:** [giggle] Rainy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(đúng lúc Mya nói Whoosh, bố/mẹ quạt giấy mạnh về phía bé)* [excited] Whoosh! [pause] It's WINDY!
> **Mya:** [cheerful] Windy! [pause] [vi] Con lắc lư như cái cây nào! [WAIT]
> *(bé: "👉"; bé đứng lắc lư hai tay như cây trước gió · sai/im: Mya đọc mẫu «Windy!»)*
> **Mya:** [giggle] Windy, windy! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ khoác áo khoác lên vai bé, ôm mình run run làm mẫu)* [soft] Brrr! [pause] It's COLD!
> **Mya:** [cheerful] Cold! [pause] [vi] Con ôm mình, run run nào! [WAIT]
> *(bé: "👉"; bé ôm mình run run · sai/im: Mya đọc mẫu «Cold!»)*
> **Mya:** [giggle] Brrr! [pause] Cold! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé làm nhầm động tác → bố/mẹ làm đúng động tác mẫu 2 lần, Mya không nói sai. Bé sợ tiếng xịt hoặc gió → bố/mẹ xịt, quạt xa hơn, hoặc chỉ làm động tác.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 🌧️ `windy.svg` 🥶 👒

| | |
|---|---|
| Mục đích | Bé trả lời "How's the weather?" bằng "It's rainy."/"It's windy."; bé làm, Mya đoán; nối lạnh với mũ |
| Mya | Vòng 1: mưa (một từ, rồi mời nói cả câu). Vòng 2: gió. Vòng 3: bé run, Mya đoán, hỏi How are you?, rồi bảo đội mũ |
| Bố/mẹ | Xịt nước, quạt **đúng lúc** Mya nói Pshhh, Whoosh; thì thầm cho bé run run ở vòng 3; đưa mũ **trước** lệnh đội mũ; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ cầm sẵn bình xịt nước, quạt giấy, cái mũ; thì thầm mẫu khi bé bí 2 lần liền)* [vi] Con làm mưa gió giỏi quá! [pause 1s] Giờ Mya hỏi, con trả lời nhé.
> **Mya:** *(đúng lúc Mya nói Pshhh, bố/mẹ xịt nhẹ nước lên không trung)* [cheerful] Pshhh! [pause] [ask] How's the weather? [WAIT]
> *(bé: "Rê-ni!" · sai/im: Mya đọc mẫu «Rainy!»)*
> **Mya:** [excited] Wo-ow! [pause] Rainy! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] It's RAINY. [WAIT]
> *(bé: "Ít rê-ni." · sai/im: Mya đọc mẫu «It's rainy.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said it's rainy! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(đúng lúc Mya nói Whoosh, bố/mẹ quạt giấy về phía bé)* [cheerful] Whoosh! [pause] [ask] How's the weather? [WAIT]
> *(bé: "Ít uyn-đi." · sai/im: Mya đọc mẫu «It's windy.»)*
> **Mya:** [praise] It's WINDY! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ thì thầm cho bé: ôm mình run run như trời lạnh)* [vi] Giờ con làm, Mya đoán nhé! [pause] Con run run đi. [WAIT]
> *(bé: "👉"; bé ôm mình run run · sai/im: Mya đọc mẫu «Brrr!»)*
> **Mya:** *(nghiêng đầu, `listen`)* [puzzled] Hmm… [pause] Brrr… [pause] [ask] How are you? [WAIT]
> *(bé: "Am côn." · sai/im: Mya đọc mẫu «I'm cold.»)*
> **Mya:** [gasp] Oh! [pause] You said I'm cold! [pause] Brrr! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa cái mũ cho bé)* [cheerful] Cold? [pause] Put on your HAT! [WAIT]
> *(bé: "👉"; bé đội mũ, bố/mẹ giúp nếu khó · sai/im: Mya đọc mẫu «Put on your HAT!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Hat on! [pause] Well do-one! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** lượt đầu bé nói "Rainy!" là đúng; Mya khen rồi nói mẫu "It's rainy." và mời bé nói cả câu một lần. Ở lượt gió và lượt lạnh, bé nói "windy", "it windy", "cold" hay "it's cold" đều tính đúng.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «It's rainy.») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ xịt nước hoặc quạt lại khi Mya đọc mẫu. Ở vòng 3, bé không chịu run thì bố/mẹ run làm mẫu, Mya vẫn hỏi tiếp. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự cầm bình xịt hoặc quạt, bố/mẹ hỏi "How's the weather?", và bỏ chặng 7. **Bé ngơ:** cắt mỗi vòng còn 1 câu, làm động tác nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 🌧️ `windy.svg` 🥶 ☀️

| | |
|---|---|
| Mục đích | Xả năng lượng: nhảy dưới "mưa" giấy, xoay theo gió, ôm mình vì lạnh, rồi nói "It's sunny." |
| Mya | Ra lệnh Stand up!, gọi từng kiểu thời tiết cho bé làm động tác, cuối cùng hỏi How's the weather? |
| Bố/mẹ | Bấm Space tạm dừng app lúc mở bài hát; tung mưa giấy, quạt, ôm mình **đúng lúc** Mya nói; chỉ ra cửa sổ hoặc thẻ mặt trời ở câu cuối |
| Ra khi | Hết giờ hoặc bé đã làm đủ 3 động tác |

> **Mya:** *(bố/mẹ chuẩn bị mưa giấy, quạt giấy, dọn chỗ trống cho bé nhảy)* [vi] Con đội mũ đẹp quá! [pause 1s] Giờ mình đứng dậy, nhảy với mưa gió nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, mở bài "Rain Rain Go Away" hoặc "How's the Weather?" và nhảy cùng bé; xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ tung mưa giấy lên trên đầu bé)* [excited] It's RAINY! [pause] Jump, jump! [WAIT]
> *(bé: "👉"; bé nhảy dưới mưa giấy · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** [giggle] Rainy! [pause] Jump! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ quạt giấy mạnh; bé xoay vòng như gió)* [cheerful] It's WINDY! [pause] Whoosh, whoosh! [WAIT]
> *(bé: "👉"; bé xoay vòng · sai/im: Mya đọc mẫu «Whoosh!»)*
> **Mya:** [excited] Whoosh! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ ôm mình run run làm mẫu)* [soft] Brrr! [pause] It's COLD! [WAIT]
> *(bé: "👉"; bé ôm mình run run · sai/im: Mya đọc mẫu «Brrr!»)*
> **Mya:** [giggle] Brrr! [pause] Cold! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ ra cửa sổ hoặc chỉ vào mặt trời trên màn hình)* [cheerful] Look! [pause] [ask] How's the weather? [WAIT]
> *(bé: "Ít xa-ni." · sai/im: Mya đọc mẫu «It's sunny.»)*
> **Mya:** [excited] SUNNY! [pause] I'm happy! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `windy.svg` 🥶 ☀️ 🌧️

| | |
|---|---|
| Mục đích | Bé nhắc từ ba lần (Mya quên "It's…?") và sửa Mya một lần (Mya nói "sunny" lúc đang mưa); buổi 11–15 chủ yếu dùng quên |
| Mya | Bắt đầu "It's…" rồi ngập ngừng chờ bé nhắc; cuối cùng xịt nước mà nói "sunny" |
| Bố/mẹ | Quạt, run, chỉ thẻ mặt trời, xịt nước đúng lượt; nhắc nhỏ: "Mya quên rồi, con nhắc Mya đi" |
| Ra khi | Bé nhắc hoặc sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya quên hay nói nhầm thì con nhắc Mya nhé)* [vi] Con nhảy giỏi quá! [pause 1s] Giờ Mya nói thời tiết, Mya quên thì con nhắc nhé.
> **Mya:** *(bố/mẹ quạt giấy; Mya cố tình quên tên)* [puzzled] Whoosh… [pause] It's… [pause] [ask] It's…? [WAIT]
> *(bé: "Uyn-đi!" · sai/im: Mya đọc mẫu «Windy!»)*
> **Mya:** [excited] WINDY! [pause] It's windy! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ ôm mình run run)* [puzzled] Brrr… [pause] It's… [pause] [ask] It's…? [WAIT]
> *(bé: "Côn!" · sai/im: Mya đọc mẫu «Cold!»)*
> **Mya:** [giggle] COLD! [pause] It's cold! [pause] Brrr! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ vào mặt trời trên màn hình)* [puzzled] Hmm… [pause] The sun! [pause] [ask] It's…? [WAIT]
> *(bé: "Xa-ni!" · sai/im: Mya đọc mẫu «Sunny!»)*
> **Mya:** [excited] SUNNY! [pause] It's sunny! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ xịt nhẹ nước lên không trung; Mya cố tình nói nhầm thành nắng; bố/mẹ lắc đầu, nhắc nhỏ bé nói: No! Rainy!)* [cheerful] Pitter-patter! [pause] It's… SUNNY! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! Rê-ni!" · sai/im: Mya đọc mẫu «Rainy!»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh! [pause] It's RAINY! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé chỉ nói "No!" ở lượt mưa cũng tính là đã sửa. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ 🌧️ ☀️ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: chào mưa, chào nắng, nói "bye-bye" |
| Mya | Chào mưa và mời bé chào theo, chào nắng, khen cụ thể, chào bé |
| Bố/mẹ | Cất bình xịt, quạt; vẫy tay cùng bé; dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ cất bình xịt, quạt giấy; vẫy tay cùng bé)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào mưa, chào nắng nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, rain! [pause] Your turn! [WAIT]
> *(bé: "Bai-bai, rên!" · sai/im: Mya đọc mẫu «Bye-bye, rain!»)*
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, sun!
> **Mya:** [vi] Hôm nay con nói được trời nắng, mưa, gió, lạnh. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🌦️, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé lẫn "sunny" và "rainy" | Không sửa bằng lời. Bố/mẹ làm động tác (nheo mắt là nắng, che đầu là mưa), Mya đọc mẫu đúng từ rồi đi tiếp. |
| Bé chỉ nói một từ ("rainy") | Tính là đúng. Mya nói lại cả câu "It's rainy." 1 lần rồi đi tiếp. |
| Bé nói thời tiết bằng tiếng Việt ("mưa") | Công nhận rồi bắc cầu: "Mưa! Rainy!" Không bắt nói lại ngay. |
| Trời lúc học mưa hoặc tối | Bố/mẹ chỉ vào thẻ mặt trời trên màn hình ở chặng 3 và 6; Mya vẫn nói đúng lời của bài. |
| Bé sợ tiếng xịt nước hoặc quạt | Bố/mẹ xịt, quạt xa hơn hoặc chỉ làm động tác; không ép bé lại gần. |
| Bé đòi tự xịt nước | Cho bé xịt 1 lần lên không trung, bố/mẹ cầm cùng; rồi cất bình đi. |
| Bé ướt áo hoặc sàn ướt | Lau nhanh, Mya: "Rainy!" rồi đi tiếp. Không mắng. |
| Nhà không có bình xịt hoặc quạt giấy | Dùng tay vẩy nước, thổi phù hoặc vẫy khăn làm gió; Mya vẫn nói đúng lời của bài. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc nhảy mưa giấy | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé kể chuyện trời mưa ở nhà | Theo bé 1 lượt ("Wow! Rainy!"), rồi quay lại bài. Không dạy thêm. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé làm đúng động tác cho 3/4 kiểu thời tiết khi nghe.
2. Bé nói "It's rainy." (hoặc sunny, windy) ít nhất 1 lần (chỉ nói một từ vẫn tính).
3. Bé nhắc hoặc sửa được Mya ở chặng 7.

**Số đo của buổi 14** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 14 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 11 |
| Câu "It's ___" bé nói | ≥ 1 |
| Câu ≥ 2 từ bé nói ("It's sunny.", "I'm cold.") | ≥ 2 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 23%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| sunny / rainy / windy / cold | | | | |
| It's ___. khi nghe How's the weather? | | | | |
| I'm cold. | | | | |
| Nhắc hoặc sửa Mya | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Mỗi sáng bố/mẹ cùng bé nhìn cửa sổ, hỏi "How's the weather?", bé đáp 1 từ ("Sunny!").
- Trời mưa thì nói "It's rainy! Pitter-patter!" và che đầu cùng bé; trời gió thì "Whoosh! Windy!".
- Bé kêu lạnh thì bố/mẹ nói "Brrr! Cold? Put on your hat!" khi đội mũ cho bé.
- Mở "Rain Rain Go Away" hoặc "How's the Weather?" lúc chơi, không bắt bé hát theo.
- Bố/mẹ không sửa phát âm, không sửa "it sunny", không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 15 — Big and small.) mở đầu bằng câu "How's the weather?" bên cửa sổ.

---

## 9. Cho app (thư mục `Resources/Lessons/14-weather/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt bé có `word` là "It's ___." nhận cả khi bé chỉ nói tên thời tiết (biến thể ở `target_chunks`); lượt "Rainy!" ở chặng 7 nhận cả "No!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./Bye-bye! và See you next time!
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; bóng và `wave` là thẻ của app; `images/jump.svg` chép từ buổi 9; `images/windy.svg` vẽ riêng), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 16.
