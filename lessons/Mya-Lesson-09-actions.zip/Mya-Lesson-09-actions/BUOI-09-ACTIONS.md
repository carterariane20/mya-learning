# Buổi 9 — Actions. I can jump.

Buổi thứ chín: bé làm đúng jump, run, dance, stop (kèm sit down, stand up), hô "Jump!", "Run!", "Dance!" để ra lệnh cho Mya, và nói "I can jump.".
File này gom mọi thứ của buổi 9 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/09-actions/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 9) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–8, bố hoặc mẹ ở nhà cùng bé |
| Tiếng Việt | khoảng 20% lượt của Mya |
| Từ mới | jump, run, dance, stop, I can jump., Jump! / Stop!, Let's dance! |
| Sản phẩm cuối buổi | Bé làm đúng 3 trong 4 hành động, hô được 1 lệnh cho Mya và nói "jump" |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Làm đúng 4 hành động jump, run, dance, stop khi nghe Mya hô (kèm sit down, stand up đã quen từ các buổi trước).
- Hô "Jump!", "Run!", "Dance!" để ra lệnh cho Mya.
- Nói "I can jump." theo mẫu.

Không kỳ vọng: bé tự hô "Stop!" (ở buổi này "Stop!" chỉ để nghe và làm: Mya hô, bé đứng tượng), phân biệt jump và dance bằng lời, nói rõ "I can". Bé chỉ cười mà chưa hô là bình thường: bố/mẹ hô cùng bé 2–3 lần rồi để bé tự hô.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Jump! | Nhảy | nói + làm | jump, jumps, jum, jăm, giăm, chăm |
| Run! | Chạy | nói + làm | run, runs, ran, răn, rân, ron |
| Dance! | Nhảy múa | nói + làm | dance, dancing, đen, đan, đen xơ, dan |
| Stop! | Dừng | nghe + làm | stop, xtop, tóp, sờ tóp |
| I can jump. | Con nhảy được. | nói theo mẫu | i can jump, can jump, i can jum, ai ken jăm, ai ken giăm, ai can jump |
| Let's dance! | Mình nhảy nào! | nghe | let's dance, lets dance, lét đen |
| Stand up! / Sit down! | Đứng lên! / Ngồi xuống! | nghe + làm | stand up, sit down |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** can, mmm, sleepy, shh, and (và các từ của buổi 1–8: what's your name, how are you, happy, you said, do you like, banana, bananas, milk, apple, yummy, see you next time…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

**Vì sao bé không nói "Stop!":** app nghe thấy "stop" (hay "thôi", "dừng lại") ở lượt bé thì hiểu là bé muốn nghỉ và dừng buổi học. Vì vậy trong bài này chỉ Mya hô "Stop!", bé đứng tượng; app không bật mic ở các lượt đó.

---

## 3. Chuẩn bị

**Đồ vật:** loa, chỗ trống trong phòng đủ để bé chạy tại chỗ và nhảy (dẹp bàn ghế, đồ dễ vỡ), sàn không trơn. Cho chặng 2: 1 quả chuối, 1 hộp sữa, 1 quả táo của buổi 8 bày làm tiệm. Bóng và khăn bịt mắt trong giáo trình không cần cho kịch bản này; bé thích thì chơi thêm sau buổi.
**Bài hát:** "Freeze Dance" (hoặc một bài nhạc sôi động bất kỳ) ở chặng 6; "Walking Walking" nếu bé còn hứng sau buổi. Bố/mẹ mở trên loa và bấm Space tạm dừng app lúc nhạc chạy; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (mỗi thẻ một vật chính, tranh SVG phẳng trong `images/`):

| Thẻ | Hình | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|---|
| `wave` | bàn tay vẫy (thẻ có sẵn của app) | Hello!, Bye-bye! | 1, 8 |
| `banana.svg` | nải 2 quả chuối | Yes!, Banana, please! | 1, 2 |
| `shop.svg` | tiệm tạp hoá có mái sọc | Let's go! | 2 |
| `milk.svg` | hộp sữa | Milk, please! | 2 |
| `apple.svg` | quả táo đỏ | Apple, please! | 2 |
| `battery-low.svg` | cục pin gần cạn, mặt buồn (Mya hết pin) | Jump! | 3 |
| `jump.svg` | kangaroo đang nhảy | Jump!, I can jump. | 3, 4, 5, 6, 8 |
| `run.svg` | bé đang chạy | Run! | 3, 4, 5, 6, 7 |
| `dance.svg` | bé giơ tay nhảy múa | Dance! | 3, 4, 5, 7 |
| `stop.svg` | bé đứng im, giơ bàn tay chặn | Stop! | 3, 4, 6 |
| `stand-up.svg` | bé đứng thẳng | Stand up! | 4 |
| `sit-down.svg` | bé ngồi trên ghế | Sit down! | 4, 6 |
| `megaphone.svg` | cái loa cầm tay (đổi vai: con hô) | Jump! | 5 |
| `music.svg` | nốt nhạc | Let's dance! | 6 |

Thẻ chỉ có tranh vẽ, không có ảnh thật. Bài này không mang tên hay ảnh thật của bé.
**Bố/mẹ trước buổi:** cho bé đi vệ sinh, mặc đồ thoải mái, đi chân trần hoặc giày mềm. Bài này nhiều vận động: để sẵn nước cho bé uống ở chặng 6. Không học khi bé buồn ngủ, vừa ăn no hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app không bật mic, chờ 3 giây rồi đi tiếp (câu khen sau đó vẫn phát).

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` rồi `banana.svg`

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you? và Do you like…? của buổi 8 |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi hỏi Do you like bananas? |
| Bố/mẹ | Vẫy tay cùng bé; giơ quả chuối lên **trước** câu Do you like bananas? |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ quả chuối lên; bé nói No cũng được, cứ gật đầu)* [cheerful] Bananas! [pause] [ask] Do you like bananas? [WAIT]
> *(bé: "Yes!" · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [excited] Yes! [pause] Yummy! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `shop.svg` `banana.svg` `milk.svg` `apple.svg`

| | |
|---|---|
| Mục đích | Ôn đồ ăn của buổi 8 bằng tiệm tạp hoá 30 giây: bé mua bằng "___, please!" (không dạy mới) |
| Mya | Mời bé mua chuối, sữa, táo; trao "Here you are!" |
| Bố/mẹ | Bày chuối, sữa, táo lên bàn làm tiệm, đứng sau tiệm trao đồ thay Mya |
| Ra khi | Bé mua được ≥ 2 món hoặc hết 5 phút |

> **Mya:** *(bố/mẹ bày chuối, sữa, táo lên bàn làm tiệm)* [vi] Ngon quá! [pause 1s] Giờ mình chơi bán hàng nhanh nhé: Mya bán, con mua.
> **Mya:** *(bé chạy tới tiệm; bố/mẹ bán thay Mya)* [cheerful] Yummy bananas! [pause] [vi] Con mua thì nói: [pause] [slow] Banana, please! [WAIT]
> *(bé: "Ba-na-na, pli!" · sai/im: Mya đọc mẫu «Banana, please!»)*
> **Mya:** *(vẫy, `wave`)* [cheerful] Here you are! [pause] Banana! *(chỉ khi bé đúng)*
> **Mya:** *(bé nhảy một vòng quanh phòng rồi quay lại tiệm; bé nói xong bố/mẹ đưa hộp sữa)* [excited] Jump, jump! [pause] Come here! [pause] Milk? [WAIT]
> *(bé: "Miu, pli!" · sai/im: Mya đọc mẫu «Milk, please!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Here you are! [pause] Milk! *(chỉ khi bé đúng)*
> **Mya:** *(bé nhảy một vòng nữa rồi quay lại tiệm; bé nói xong bố/mẹ đưa quả táo)* [cheerful] Jump, jump! [pause] Apple? [WAIT]
> *(bé: "Ép pồ, pli!" · sai/im: Mya đọc mẫu «Apple, please!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Here you are! [pause] Apple! Yummy! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ `battery-low.svg` `jump.svg` `run.svg` `dance.svg` `stop.svg`

| | |
|---|---|
| Mục đích | Gây tò mò: Mya "hết pin", chỉ nằm; bé hô "Jump!" để Mya tỉnh, rồi gặp run, dance, stop |
| Mya | Ngủ gật, chờ bé hô Jump!, tỉnh dậy, làm mẫu Run, Dance, Stop và mời bé nói theo |
| Bố/mẹ | Hô Jump! cùng bé ở lần đầu; làm mẫu chạy tại chỗ, nhảy múa, đứng tượng **trước** khi Mya mời bé |
| Ra khi | Bé đã hô Jump! và xem đủ 4 hành động |

> **Mya:** *(bố/mẹ cất đồ ăn, ngồi sát bé, chỉ vào Mya đang buồn ngủ trên màn hình)* [vi] Đi chợ xong rồi, con giỏi lắm! [pause 1s] Ơ… Mya hết pin, buồn ngủ quá. Con hô thật to cho Mya tỉnh nhé.
> **Mya:** *(lần đầu bố/mẹ hô cùng bé, rồi để bé tự hô)* [slow] Mmm… sleepy… [pause] [vi] Con hô: [pause] [excited] Jump! [WAIT]
> *(bé: "Jăm!"; bé hô thật to · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(vẫy, `wave`)* *(Mya tỉnh dậy; bố/mẹ nhảy một cái cùng Mya)* [excited] Jump! Jump! [pause] I can JUMP!
> **Mya:** *(bố/mẹ chạy tại chỗ cho bé xem)* [gasp] Look! [pause] Run, run, run!
> **Mya:** [cheerful] Run! [pause] Your turn! [WAIT]
> *(bé: "Răn!" · sai/im: Mya đọc mẫu «Run!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said RUN! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ lắc lư nhảy múa cho bé xem)* [sing-song] Let's dance! [pause] Dance, dance!
> **Mya:** [cheerful] Dance! [pause] Your turn! [WAIT]
> *(bé: "Đen!" · sai/im: Mya đọc mẫu «Dance!»)*
> **Mya:** *(vẫy, `wave`)* [excited] DANCE! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đứng im như tượng, giơ bàn tay ra trước; bé đứng im theo)* [whisper] Shh… [pause] STOP! [WAIT]
> *(bé: "👉"; bé đứng im như tượng · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [giggle] Stop! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `stand-up.svg` `jump.svg` `run.svg` `stop.svg` `dance.svg` `sit-down.svg`

| | |
|---|---|
| Mục đích | Hiểu jump, run, stop, dance, stand up, sit down bằng hành động, chưa cần nói |
| Mya | Hô từng lệnh, chờ bé làm rồi khen |
| Bố/mẹ | Làm cùng bé; bé làm sai thì cả hai đứng im đếm một, hai, ba (phạt vui) rồi chơi tiếp |
| Ra khi | Bé làm đúng ≥ 3 lệnh |

> **Mya:** *(bố/mẹ dọn chỗ trống, đứng cùng bé; bé làm sai thì cả hai đứng im đếm một, hai, ba rồi chơi tiếp)* [vi] Con biết hết rồi! [pause 1s] Giờ Mya hô, con làm theo nhé. Sai thì đứng im ba giây!
> **Mya:** [cheerful] Stand up!
> *(bé: "👉"; bé đứng lên · app chờ 3 giây rồi đi tiếp)*
> **Mya:** [excited] JUMP! [WAIT]
> *(bé: "👉"; bé nhảy tại chỗ · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [praise] You can JUMP! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] RUN! [WAIT]
> *(bé: "👉"; bé chạy tại chỗ · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [giggle] Run, run! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [excited] STOP! [WAIT]
> *(bé: "👉"; bé đứng im như tượng · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [whisper] Shh… [pause] Nice! *(chỉ khi bé đúng)*
> **Mya:** [sing-song] DANCE! [WAIT]
> *(bé: "👉"; bé lắc lư nhảy múa · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [excited] Dance, dance! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Sit down! [WAIT]
> *(bé: "👉"; bé ngồi xuống · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [praise] Sit down! [pause] Thank you! *(chỉ khi bé đúng)*

Bé làm sai → đứng im ba giây cho vui, không chê. Lượt 👉 app không chấm: bố/mẹ là người xem bé làm đúng hay chưa.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `megaphone.svg` `jump.svg` `run.svg` `dance.svg` `jump.svg`

| | |
|---|---|
| Mục đích | Đổi vai hoàn toàn: bé ra lệnh Jump!, Run!, Dance! cho Mya và nói "I can jump." |
| Mya | Vòng 1: bé hô Jump!, Mya nhảy, rồi bé nói cả câu I can jump. Vòng 2: bé hô Run!. Vòng 3: bé hô Dance!. Cuối: bé tự hô Jump! một lần nữa |
| Bố/mẹ | Hô cùng bé 2–3 lần đầu rồi để bé tự hô; chỉ vào thẻ **trước** khi Mya mời; nhảy một cái làm mẫu ở câu I can jump |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

> **Mya:** *(bố/mẹ ngồi cạnh bé, sẵn sàng hô cùng bé ở lần đầu)* [vi] Con làm theo giỏi quá! [pause 1s] Giờ đổi vai nhé: con hô, Mya làm theo.
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ hô cùng bé 2–3 lần rồi để bé tự hô)* [cheerful] Your turn! [pause] [vi] Con hô: [pause] [excited] Jump! [WAIT]
> *(bé: "Jăm!" · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Jump! Jump! [pause] I can jump! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ nhảy một cái làm mẫu)* [vi] Con nói cả câu nhé: [pause] [slow] I can JUMP. [WAIT]
> *(bé: "Ai ken jăm."; bé nhảy một cái · sai/im: Mya đọc mẫu «I can jump.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said I can jump! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ vào thẻ người đang chạy)* [cheerful] Ready? [pause] [vi] Con hô cho Mya chạy nhé! [WAIT]
> *(bé: "Răn!" · sai/im: Mya đọc mẫu «Run!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Run, run, run! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào thẻ nhảy múa)* [cheerful] One more! [pause] Your turn! [WAIT]
> *(bé: "Đen!" · sai/im: Mya đọc mẫu «Dance!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Let's dance! Dance, dance! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ để bé tự hô, không hô cùng)* [cheerful] Again! [pause] Your turn! [WAIT]
> *(bé: "Jăm!" · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** *(vẫy, `wave`)* [excited] JUMP! [pause] I can jump! [pause] Well do-one! *(chỉ khi bé đúng)*

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Jump!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào thẻ khi Mya đọc mẫu. Bé chỉ làm động tác mà không hô là đã hiểu: bố/mẹ hô cùng bé một lần, đi tiếp. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ `music.svg` `stop.svg` `run.svg` `stop.svg` `jump.svg` `sit-down.svg`

| | |
|---|---|
| Mục đích | Xả năng lượng bằng Freeze Dance: nhạc tắt → Mya hô "Stop!" → cả nhà đứng tượng; bé hô Jump! cho cả nhà |
| Mya | Stand up! Let's dance!, hô Stop! mỗi khi nhạc tắt, mời bé hô Jump!, rồi Sit down! |
| Bố/mẹ | Bấm Space tạm dừng app, mở nhạc cho cả nhà nhảy; tắt nhạc rồi bấm Space để Mya hô Stop!; đứng tượng cùng bé |
| Ra khi | Hết giờ |

> **Mya:** *(bố/mẹ mở sẵn bài Freeze Dance hoặc một bài nhạc sôi động trên loa)* [vi] Đổi vai vui quá! [pause 1s] Giờ mình chơi đứng hình: nhạc tắt là đứng im như tượng nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, mở nhạc cho cả nhà nhảy múa; muốn dừng thì tắt nhạc rồi bấm Space để Mya hô Stop)* [sing-song] Stand up! [pause] Let's dance!
> **Mya:** *(nhạc vừa tắt; bố/mẹ và bé đứng im như tượng)* [excited] STOP! [WAIT]
> *(bé: "👉"; bé đứng tượng · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! [pause] Nice! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ bấm Space tạm dừng app, mở nhạc lại cho bé chạy tại chỗ; tắt nhạc rồi bấm Space học tiếp)* [excited] Run, run, run!
> **Mya:** *(nhạc vừa tắt; cả nhà đứng tượng)* [gasp] Oh! [pause] STOP! [WAIT]
> *(bé: "👉"; bé đứng tượng · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* [praise] Stop! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ đứng chờ, nghe bé hô mới nhảy)* [cheerful] Your turn! [pause] [vi] Con hô cho cả nhà nhảy cao nào! [WAIT]
> *(bé: "Jăm!" · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Jump, jump! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ tắt nhạc, ngồi xuống cùng bé, cho bé uống nước)* [cheerful] Sit down! [pause] [vi] Mình nghỉ chút nào!

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `run.svg` rồi `dance.svg`

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya làm sai hành động |
| Mya | Nghe "run" mà lại nhảy; nghe "dance" mà lại ngồi xuống |
| Bố/mẹ | Chỉ vào thẻ; nhắc nhỏ: "Mya làm sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya làm sai thì con nhắc Mya nhé)* [vi] Trò đứng hình xong rồi, con giỏi lắm! [pause 1s] Giờ con làm cô giáo, xem Mya làm đúng không nhé.
> **Mya:** *(thẻ hiện người chạy; Mya nghe run mà cố tình nhảy)* [cheerful] Run? [pause] Ok! [pause] Jump! Jump! [WAIT]
> *(bé: "No! Răn!" · sai/im: Mya đọc mẫu «Run!»)*
> **Mya:** [gasp] Oh no! [pause] RUN! Run, run! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(thẻ hiện nhảy múa; Mya nghe dance mà cố tình ngồi xuống)* [puzzled] Dance… [pause] [ask] Sit down? [WAIT]
> *(bé: "No! Đen!" · sai/im: Mya đọc mẫu «Dance!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] DANCE! Dance! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `jump.svg` rồi `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: nhảy một cái, "I can jump!", "bye-bye" |
| Mya | Cùng nhảy một cái, khen cụ thể, chào bé |
| Bố/mẹ | Đứng lên nhảy cùng bé, vẫy tay, dán sticker |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ đứng lên cùng bé)* [vi] Sắp hết giờ rồi! [pause 1s] Mình nhảy một cái thật cao rồi chào nhau nhé.
> **Mya:** *(vẫy, `wave`)* *(cả nhà nhảy một cái)* [excited] Let's go! [pause] JUMP! [pause] I can jump!
> **Mya:** [vi] Hôm nay con hô được jump, run, dance và nói I can jump. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker, cả nhà ôm bé)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🦘, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé chỉ cười, không hô lệnh | Bình thường. Bố/mẹ hô cùng bé 2–3 lần rồi để bé tự hô. |
| Bé nói bằng tiếng Việt ("nhảy", "chạy") | Công nhận rồi bắc cầu: "Nhảy! Jump!" Không bắt nói lại ngay. |
| Bé hô "Stop!" hoặc "thôi", "dừng lại" ở lượt nói | App hiểu là bé muốn nghỉ: dừng ngay, hiện màn "Mình nghỉ nhé". Bố/mẹ hỏi bé muốn chơi tiếp không, rồi bấm học tiếp. |
| Bé nhầm jump với dance | Không sửa bằng lời. Bố/mẹ làm lại đúng động tác, Mya đi tiếp. |
| Bé chạy lung tung, hò hét | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé ngã hoặc va vào đồ | Dừng hẳn, bố/mẹ ôm bé. "[soft] [vi] Mya ở đây. [pause] Con uống nước nhé." |
| Bé mệt, thở nhiều | Cho bé ngồi, uống nước; bỏ bớt lượt chạy, giữ lượt nói. |
| Bé chỉ làm động tác, chưa nói | Tính là hiểu. "[cheerful] Yes! Jump!" rồi mời bé hô "jump" một lần. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé không nói được "I can jump." | Bình thường, đây là câu nói theo mẫu. Bé nói "jump" là đủ. |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé làm đúng 3 trong 4 hành động (jump, run, dance, stop).
2. Bé hô được 1 lệnh cho Mya.
3. Bé nói "jump".

**Số đo của buổi 9** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 9 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 11 |
| Từ đích bé dùng | ≥ 2 trong jump, run, dance |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 20%, vượt 30% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Làm jump, run, dance, stop | | | | |
| Hô lệnh Jump! / Run! / Dance! | | | | |
| I can jump. | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Chơi Simon says 2 phút mỗi tối với bố/mẹ, chỉ 4 từ: jump, run, dance, stop.
- Đổi vai: bé hô, bố/mẹ làm. Bé hô "stop" thoải mái khi chơi ở nhà, không cần app.
- Xem 1 video bài hát Freeze Dance hoặc Walking Walking, bé nhảy theo nếu thích, không bắt.
- Bố/mẹ không ép bé lặp, không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 10) là buổi tổng kết: ôn tất cả bằng những trò bé thích nhất.

---

## 9. Cho app (thư mục `Resources/Lessons/09-actions/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên bé). Câu mẫu Jump!, Run!, Dance!, Stop!, Sit down! dùng lại tiếng của lượt Mya hô lệnh ở chặng 4 (`listen_do-3`, `-5`, `-9`, `-7`, `-11`) và chặng 6 (`move-3`).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app không bật mic, chờ 3 giây rồi đi tiếp. Mọi lượt "Stop!" của bé đều là lượt 👉.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Câu có trong thư viện chung dùng `lib` (chào, How are you?, Happy!, High five!, Wow!, Thank you!, Stand up!, Yes!, Bye-bye, See you next time!).
- Chặng 1 (hello-5, hello-6) và chặng 2 (recall-2 … recall-7) dùng nguyên lời của buổi 8 (talk-2, talk-3, move-3, move-4, move-7 … move-10), nên chép được tiếng từ `08-food/audio/`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (13 file SVG trong `images/` và key `wave` có sẵn của app), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 11.
