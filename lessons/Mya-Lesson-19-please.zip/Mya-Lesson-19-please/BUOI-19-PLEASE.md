# Buổi 19 — Can I have...? Please.

Buổi thứ mười chín: ôn thú sở thú bằng "I like ___", rồi Mya mở tiệm "Mya's shop!". Bé học từ thần kỳ "Please!", nghe Mya xin đồ rồi đưa đúng món, tự đi mua và nói "Can I have the ball?", nhận đồ thì nói "Thank you!", đổi vai làm người bán nói "Here you are!", và nhắc Mya khi Mya quên "please" hay quên "thank you".
File này gom mọi thứ của buổi 19 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/19-please/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 19) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–18, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 20% lượt của Mya |
| Từ mới | 2 từ: please, thank you; 1 cấu trúc mới: "Can I have ___?" (học như cụm) |
| Sản phẩm cuối buổi | Bé nói "Can I have the ___?" (thêm "please" càng tốt) ít nhất 1 lần, nói "Thank you!" khi nhận đồ mà không cần nhắc |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Xin đồ bằng "Can I have the ball?" (cả câu, nói theo mẫu cũng được; thêm "please" càng tốt) thay vì giật hay chỉ tay.
- Nói "Thank you!" khi được đưa đồ, ít nhất 1 lần không cần nhắc.
- Nói "Here you are!" khi đưa đồ cho Mya (lúc bé làm người bán).
- Nghe "Can I have the teddy, please?" thì đưa đúng món; nghe "Give me the car!" (thiếu please) thì biết Mya quên từ thần kỳ.
- Nhắc Mya "Please!" khi Mya quên, và "Thank you!" khi Mya nhận đồ mà quên cảm ơn.
- Vẫn gọi tên lion và nói "I like elephants." / "I like monkeys." / "I like tigers." (ôn buổi 18 và khung "I like" của buổi 4–5).

Không kỳ vọng: nói rõ "please" hay "have", nói đủ cả câu mọi lần. Bé nói "Ball, please!" hay "I want the ball" là **đạt**: Mya khen rồi nói mẫu lại "Can I have the ball?", không bắt bé nói lại. Câu bé luyện là "Can I have the ball?"; Mya vẫn nói mẫu có "please", bé nói thêm "please" càng tốt.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Can I have the ball? | Cho con quả bóng được không? | nói | can i have the ball, can i have the ball please, can i have ball, ball please, the ball please, i want the ball, i want ball, ken ai hép đờ bon, ken ai hép bon |
| Can I have the teddy? | Cho con gấu bông được không? | nói | can i have the teddy, can i have the teddy please, can i have teddy, teddy please, the teddy please, i want the teddy, i want teddy, ken ai hép đờ té đi, ken ai hép té đi |
| Can I have the banana? | Cho con quả chuối được không? | nói | can i have the banana, can i have the banana please, can i have banana, banana please, the banana please, i want the banana, i want banana, ken ai hép đờ bờ na na, ken ai hép ba na na |
| Please! | Làm ơn! (từ thần kỳ) | nói | please, please please, pli, pli dờ, plít, plis |
| Thank you! | Cảm ơn! | nói | thank you, thanks, thank you mya, thank, thanh kiu, thanh kìu, tanh kiu, thenk kiu |
| Here you are! | Của Mya đây! | nói | here you are, here you go, here, here it is, hia diu a, hia du a, hia |
| Mya's shop! | Tiệm của Mya! | nói | mya's shop, mya shop, maya's shop, maya shop, shop, a shop, mai dờ sóp, sóp |
| I like elephants. / I like monkeys. / I like tigers. | Con thích voi / khỉ / hổ (ôn buổi 18) | nói | i like elephants, i like elephant, like elephants, yes, i like, ai lai ê lơ phần / i like monkeys, i like monkey, like monkeys, yes, i like, ai lai măng ki / i like tigers, i like tiger, like tigers, yes, i like, ai lai tai gơ |
| Lion! | Sư tử (ôn buổi 18) | nói | lion, a lion, it's a lion, lai ơn, lai ần |
| Can I have the ball / teddy / car, please? | Cho Mya quả bóng / gấu / ô tô được không? | nghe + làm | can i have the ball please / can i have the teddy please / can i have the car please |
| Give me the car! / Give me the ball! | Đưa ô tô / bóng đây! (thiếu please) | nghe | give me the car / give me the ball |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** welcome, here you are, give me, can, have, shop, Mya's, elephants, tigers, mmm, yummy, banana, teddy, car, ball, one, two, three, peekaboo, now, oh (và các từ của buổi 1–18: what's this, look, do you like, monkeys, lion, roar, you said, clap, shh, hmm, wow…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** một "cửa hàng" nhỏ: cái bàn thấp và 6–8 món (bắt buộc có quả bóng, gấu bông, ô tô, quả chuối; thêm vài món đồ chơi hay đồ ăn khác cho đẹp); 1 tấm khăn để trùm tiệm; 1 cái giỏ; vài tờ tiền giấy giả; con sư tử, voi, khỉ, hổ đồ chơi (của buổi 18); vài sticker; loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Please and Thank You" (Super Simple Songs), mở ở chặng 6. Bố/mẹ bấm Space tạm dừng app, mở bài trên loa, cùng bé nhảy quanh tiệm; app không phát bài hát. Nghe lại ở nhà.
**Thẻ tranh trên màn hình** (emoji, thẻ `wave`, `ball`, `qmark` của app, 1 hình SVG chép từ buổi 9; bài này không vẽ hình mới):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| 🦁 | Lion! | 1 |
| 🐘 | I like elephants. | 2 |
| 🐒 | I like monkeys. | 2 |
| 🐯 | I like tigers. | 2 |
| `qmark` (thẻ của app, tiệm còn trùm khăn) | One, two, three! | 3 |
| `shop.svg` (tiệm mái sọc đỏ trắng, của buổi 9) | Mya's shop! | 3 |
| 🙏 | Please! | 3 |
| 🎁 (Mya tặng sticker) | Thank you! | 3, 8 |
| `ball` (quả bóng đỏ, thẻ của app) | Ball, please! (lượt bé: Can I have the ball?), Thank you!, Please! | 4, 5, 7 |
| 🧸 | Teddy, please! (lượt bé: Can I have the teddy?), Thank you!, Here you are!, Please! | 4, 5, 6, 7 |
| 🚗 | Give me the car!, Car, please!, Here you are! | 4, 6 |
| 🍌 | Banana, please! (lượt bé: Can I have the banana?), Thank you!, Here you are! | 5, 6 |
| 🎵 | Stand up! (lúc hát) | 6 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại món đang mua bán. Thẻ 🍌 là một quả chuối, khớp "the banana" (hình `banana.svg` của buổi 9 có hai quả nên không dùng).
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Bày tiệm sẵn rồi trùm khăn kín, để 4 con thú, giỏ, tiền giấy và sticker cạnh mình, ngoài tầm tay bé. Bố/mẹ là "tay" của Mya: Mya xin đồ thì bố/mẹ chìa tay nhận, Mya đưa đồ thì bố/mẹ đưa cho bé. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` 🦁

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you?, và ôn nhanh thú sở thú của buổi 18 (30 giây) |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi hỏi What's this? khi bố/mẹ giơ con sư tử |
| Bố/mẹ | Vẫy tay cùng bé; giơ con sư tử **trước** câu What's this? |
| Ra khi | Bé đã chào hoặc trả lời, và nói (hoặc nói theo) "Lion!" |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con sư tử)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Lai-ơn!" · sai/im: Mya đọc mẫu «Lion!»)*
> **Mya:** [excited] LION! [pause] Roar! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 🐘 🐒 🐯

| | |
|---|---|
| Mục đích | Ôn hai thứ cũ: tên thú sở thú (buổi 18) và khung "I like ___" (buổi 4–5, 18), không dạy mới |
| Mya | Giơ từng con thú, hỏi Do you like elephants? / monkeys? / tigers? |
| Bố/mẹ | Giơ từng con thú **trước** câu hỏi; thì thầm "I like…" khi bé bí |
| Ra khi | Bé đã trả lời 3 câu, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ để voi, khỉ, hổ sau lưng, giơ từng con trước câu hỏi)* [vi] Sư tử đây rồi, con nhớ giỏi lắm! [pause 1s] Giờ mình nói con thích bạn thú nào nhé.
> **Mya:** *(bố/mẹ giơ con voi)* [cheerful] An ELEPHANT! [pause] [ask] Do you like elephants? [WAIT]
> *(bé: "Ai lai ê-lơ-phần." · sai/im: Mya đọc mẫu «I like elephants.»)*
> **Mya:** [praise] You said I like elephants! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ cất voi, giơ con khỉ)* [giggle] Ooh-ooh-ah-ah! [pause] [ask] Do you like monkeys? [WAIT]
> *(bé: "Ai lai măng-ki." · sai/im: Mya đọc mẫu «I like monkeys.»)*
> **Mya:** [excited] You said I like monkeys! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ cất khỉ, giơ con hổ)* [whisper] Shh… [pause] A TIGER! [pause] [ask] Do you like tigers? [WAIT]
> *(bé: "Ai lai tai-gơ." · sai/im: Mya đọc mẫu «I like tigers.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said I like tigers! [pause] High five! *(chỉ khi bé đúng)*

Bé chỉ nói "Yes!" hay "I like!" → tính đúng; Mya vẫn khen bằng cả câu. Bé nói "No!" → cũng được, bố/mẹ gật đầu rồi sang con thú kế.

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ `qmark` `shop.svg` 🙏 🎁

| | |
|---|---|
| Mục đích | Gây tò mò: kéo khăn mở "Mya's shop!", giới thiệu từ thần kỳ "Please!" và câu "Thank you!" |
| Mya | Đếm one, two, three, "Peekaboo! Welcome to Mya's shop!", mời bé nói "Mya's shop!", "Please!", rồi đưa sticker "Here you are!" và mời nói "Thank you!" |
| Bố/mẹ | Trùm khăn lên tiệm **trước** chặng; kéo khăn đúng lúc "Peekaboo!"; chắp tay lúc "Please!"; đưa sticker cho bé thay Mya |
| Ra khi | Bé nói (hoặc nói theo) "Please!" và "Thank you!" |

> **Mya:** *(trước chặng bố/mẹ bày tiệm: bàn thấp, 6–8 món như bóng, gấu, ô tô, chuối…, rồi trùm khăn kín; để giỏ và tiền giấy cạnh bàn)* [vi] Con thích nhiều bạn thú quá! [pause 1s] Giờ Mya có một bất ngờ, con nhìn nhé.
> **Mya:** *(bố/mẹ đặt tay lên khăn, đếm cùng Mya)* [whisper] Shh… [pause] One… [pause] two… [pause] THREE!
> **Mya:** *(bố/mẹ kéo khăn ra đúng lúc Mya nói Peekaboo!)* [gasp] Peekaboo! [pause] Welcome to Mya's SHOP!
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] Mya's shop! [WAIT]
> *(bé: "Mai-dờ sóp!" · sai/im: Mya đọc mẫu «Mya's shop!»)*
> **Mya:** [praise] You said Mya's shop! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chắp tay, nói nhỏ "please" cùng bé)* [vi] Ở tiệm Mya có một từ thần kỳ: [pause] [slow] Please! [WAIT]
> *(bé: "Pli-dờ!" · sai/im: Mya đọc mẫu «Please!»)*
> **Mya:** [excited] You said please! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa bé một sticker (hoặc món quà nhỏ) thay Mya)* [cheerful] Here you are! [pause] [vi] Con nói: [pause] [slow] Thank you! [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [praise] You said thank you! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `ball` 🧸 🚗

| | |
|---|---|
| Mục đích | Nghe sự khác nhau giữa xin lịch sự và đòi: "Can I have the ball, please?" thì đưa; "Give me the car!" thì chờ Mya nói "please"; chưa cần nói |
| Mya | "Can I have the ball, please?", "Can I have the teddy, please?", "Give me the car!" (cố tình thiếu please), rồi "Can I have the car, PLEASE?" |
| Bố/mẹ | Để bóng, gấu, ô tô trước mặt bé **trước** chặng; chìa tay ra làm tay của Mya; lúc "Give me the car!" ôm ô tô, lắc đầu cùng bé |
| Ra khi | Bé đưa đúng ≥ 2 món |

> **Mya:** *(bố/mẹ để bóng, gấu, ô tô trước mặt bé; bố/mẹ chìa tay ra làm tay của Mya)* [vi] Tiệm mở cửa rồi! [pause 1s] Giờ Mya xin đồ, con nghe kỹ rồi đưa cho Mya nhé.
> **Mya:** *(bố/mẹ chìa tay thay Mya)* [cheerful] Can I have the ball, please? [WAIT]
> *(bé: "👉"; bé đưa quả bóng cho bố/mẹ · sai/im: Mya đọc mẫu «Ball!»)*
> **Mya:** [praise] Thank you! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đặt quả bóng lại lên bàn)* [cheerful] Now… [pause] can I have the teddy, please? [WAIT]
> *(bé: "👉"; bé đưa gấu bông cho bố/mẹ · sai/im: Mya đọc mẫu «Teddy!»)*
> **Mya:** [giggle] Thank you! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(Mya cố tình quên "please"; bố/mẹ ôm ô tô, lắc đầu cùng bé)* [puzzled] Hmm… [pause] Give me the car! [WAIT]
> *(bé: "👉"; bé lắc đầu, giữ ô tô · sai/im: Mya đọc mẫu «Please!»)*
> **Mya:** *(bố/mẹ gật đầu, chỉ bé đưa ô tô)* [giggle] Oh! [pause] Can I have the car, PLEASE? [WAIT]
> *(bé: "👉"; bé đưa ô tô cho bố/mẹ · sai/im: Mya đọc mẫu «Car!»)*
> **Mya:** [praise] Thank you! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé đưa luôn ô tô khi nghe "Give me the car!" → không sao, bố/mẹ nhận rồi nói nhỏ "Mya quên please rồi!", Mya vẫn khen. Bé tự nói "Please!" ở lượt này → càng tốt, bố/mẹ vỗ tay.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `ball` 🧸 🍌

| | |
|---|---|
| Mục đích | Bé đi mua đồ, nói "Can I have the ___?" ba lần (lần đầu theo mẫu, hai lần sau tự xin), và nói "Thank you!" khi nhận đồ |
| Mya | Vòng 1: bóng (đọc mẫu cả câu). Vòng 2: gấu (bé tự xin). Vòng 3: chuối (bé tự xin). Mỗi vòng đưa đồ "Here you are!" rồi chờ bé nói "Thank you!" |
| Bố/mẹ | Ngồi sau bàn bán thay Mya; giơ từng món **trước** câu của Mya; đưa đồ cho bé lúc "Here you are!"; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ ngồi sau bàn bán thay Mya, đưa bé cái giỏ và vài tờ tiền giấy; giơ từng món trước câu của Mya; thì thầm mẫu khi bé bí 2 lần liền)* [vi] Con nghe giỏi quá! [pause 1s] Giờ con đi mua đồ ở tiệm Mya nhé.
> **Mya:** *(bố/mẹ giơ quả bóng)* [cheerful] Look! A ball! [pause] [vi] Con xin thế này: [pause] [slow] Can I have the ball, please? [WAIT]
> *(bé: "Ken ai hép đờ bon?" · sai/im: Mya đọc mẫu «Can I have the ball?»)*
> **Mya:** [praise] You said can I have the ball! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa quả bóng cho bé, bé bỏ vào giỏ)* [cheerful] Ball! [pause] Here you are! [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said thank you! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ con gấu)* [cheerful] Now… the TEDDY! [pause] [vi] Con tự xin nhé! [WAIT]
> *(bé: "Ken ai hép đờ té-đi?" · sai/im: Mya đọc mẫu «Can I have the teddy?»)*
> **Mya:** [excited] Wo-ow! [pause] You said can I have the teddy! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa con gấu cho bé; không nhắc, chờ bé tự nói)* [cheerful] Teddy! [pause] Here you are! [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [giggle] You said thank you! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ quả chuối, chỉ vào bé)* [cheerful] Mmm… [pause] a yummy BANANA! [WAIT]
> *(bé: "Ken ai hép đờ bờ-na-na?" · sai/im: Mya đọc mẫu «Can I have the banana?»)*
> **Mya:** [praise] Yes! [pause] Can I have the banana, please! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa quả chuối cho bé; không nhắc, chờ bé tự nói)* [cheerful] Banana! [pause] Here you are! [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said thank you! [pause] Yummy banana! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** bé nói "Ball, please!", "Can I have ball?" hay "I want the ball" đều tính đúng. Mya khen, và câu mẫu luôn là cả câu "Can I have the ball?". Bé thêm "please" càng tốt. Không bắt bé nói lại cho đủ chữ. Bố/mẹ chỉ đưa đồ sau khi bé đã nói (hoặc đã nghe mẫu), không giữ đồ lâu làm bé tủi.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Can I have the ball?») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ giơ món đồ khi Mya đọc mẫu. Bé nói "I want…" → chấp nhận, bố/mẹ nói nhỏ "Can I have…" một lần rồi đưa đồ. Bé giật đồ → bố/mẹ giữ nhẹ, chắp tay nhắc "Please?", không mắng. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự chọn món trên bàn và xin, bố/mẹ bán thay Mya, và bỏ chặng 7. **Bé ngơ:** chỉ làm vòng 1 và vòng 2 (bóng và gấu).

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 🧸 🍌 🚗

| | |
|---|---|
| Mục đích | Xả năng lượng và đổi vai: bé làm người bán, chạy tới giỏ lấy đồ Mya xin, đưa và nói "Here you are!" |
| Mya | Stand up!, rồi xin gấu, chuối, ô tô bằng "Can I have the ___, please?" |
| Bố/mẹ | Bấm Space tạm dừng app lúc hát; để gấu, chuối, ô tô vào giỏ ở góc phòng **trước** chặng; chìa tay nhận đồ thay Mya; thì thầm "Here you are!" khi bé bí |
| Ra khi | Hết giờ hoặc bé đã đưa đủ 3 món |

> **Mya:** *(bố/mẹ để gấu, chuối, ô tô vào giỏ đặt ở góc phòng; bé đứng sau bàn tiệm)* [vi] Con mua hàng giỏi quá! [pause 1s] Giờ mình đổi vai: con bán hàng, Mya đi mua nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, mở bài "Please and Thank You" (Super Simple Songs), cùng bé nhảy quanh tiệm; hết bài bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bé chạy tới giỏ lấy gấu, đưa cho bố/mẹ (tay của Mya); bố/mẹ thì thầm "Here you are!" nếu bé bí)* [cheerful] Hello, shop! [pause] [ask] Can I have the teddy, please? [WAIT]
> *(bé: "Hia diu a!" · sai/im: Mya đọc mẫu «Here you are!»)*
> **Mya:** [praise] Thank you! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bé chạy tới giỏ lấy quả chuối, đưa cho bố/mẹ)* [cheerful] Mmm… [pause] can I have the banana, please? [WAIT]
> *(bé: "Hia diu a!" · sai/im: Mya đọc mẫu «Here you are!»)*
> **Mya:** [giggle] Thank you! [pause] Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(bé chạy tới giỏ lấy ô tô, đưa cho bố/mẹ)* [cheerful] Now… [pause] can I have the car, please? [WAIT]
> *(bé: "Hia diu a!" · sai/im: Mya đọc mẫu «Here you are!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Thank you! [pause] Wo-ow! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `ball` 🧸

| | |
|---|---|
| Mục đích | Bé nhắc Mya hai lần quên "Please!" và một lần quên "Thank you!" |
| Mya | Đòi "Give me the ball!", nhận bóng mà không cảm ơn, xin gấu thiếu please; chờ bé nhắc |
| Bố/mẹ | Giơ đúng món **trước** mỗi câu; ôm món đồ, lắc đầu, chắp tay, nhắc: "Mya quên rồi, con nhắc Mya đi"; thì thầm "Please!" / "Thank you!" nếu bé bí |
| Ra khi | Bé nhắc đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ ngồi sau bàn, giơ quả bóng; nhắc nhỏ: Mya quên thì con nhắc Mya nhé)* [vi] Con bán hàng giỏi quá! [pause 1s] Giờ Mya đi mua, Mya quên từ thần kỳ thì con nhắc nhé.
> **Mya:** *(Mya cố tình quên "please"; bố/mẹ ôm quả bóng, lắc đầu, chắp tay)* [cheerful] Ball! [pause] Give me the ball! [WAIT]
> *(bé: "Pli-dờ!" · sai/im: Mya đọc mẫu «Please!»)*
> **Mya:** [gasp] Oh! [pause] PLEASE! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa quả bóng về phía Mya; Mya cố tình quên cảm ơn)* [puzzled] Hmm… [pause] [vi] Mya có bóng rồi… Mya quên nói gì nhỉ? [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [gasp] Oh! [pause] Thank you! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con gấu; Mya cố tình quên "please")* [cheerful] The TEDDY! [pause] [ask] Can I have the teddy? [WAIT]
> *(bé: "Pli-dờ!" · sai/im: Mya đọc mẫu «Please!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Please! [pause] Thank you! [pause] High five! *(chỉ khi bé đúng)*

Bé nói "No!" thay vì "Please!" → app đọc mẫu «Please!», bố/mẹ chắp tay. Bé đưa luôn đồ mà không nhắc → không sao, bố/mẹ nói nhỏ "Mya quên please rồi!" rồi đi tiếp. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ 🎁 `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: nhận sticker và tự nói "Thank you!", nói "bye-bye" |
| Mya | Đưa quà "Here you are!", chờ bé tự cảm ơn, khen cụ thể, chào bé |
| Bố/mẹ | Đưa sticker cho bé, **không nhắc** "thank you"; vẫy tay cùng bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ cầm sẵn sticker)* [vi] Con nhắc Mya giỏi quá! [pause 1s] Sắp hết giờ rồi, Mya có quà cho con nhé.
> **Mya:** *(bố/mẹ đưa bé sticker; không nhắc, chờ bé tự nói)* [cheerful] Here you are! [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [praise] You said thank you! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [vi] Hôm nay con xin đồ lịch sự bằng tiếng Anh. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ vẫy tay cùng bé)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🛍️, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói "I want…" | Bình thường (từ tiếng Anh bé tự biết). Chấp nhận, rồi bố/mẹ nói mẫu lại "Can I have…" một lần. |
| Bé chỉ nói "Ball, please!" | Tính là đúng. Câu mẫu vẫn là cả câu, không bắt nói lại. |
| Bé quên "please" | Vẫn tính đúng; bố/mẹ chắp tay nhắc nhẹ một lần, không giữ đồ để ép. |
| Bé nói "cảm ơn" bằng tiếng Việt | Công nhận rồi bắc cầu: "Cảm ơn! Thank you!" Không bắt nói lại ngay. |
| Bé giật đồ, không chịu đưa lại | Chơi cùng 1 lượt ("Wow, a car!"), rồi bố/mẹ đổi món khác. Không giằng lấy, không mắng. |
| Bé đòi giữ hết đồ trong giỏ | Cho giữ; đến chặng 6 bố/mẹ nhờ bé "bán" lại từng món. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc đổi vai | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé nói được cụm "Can I have ___" (có thể thiếu "please") ít nhất 1 lần.
2. Bé nói "Thank you!" khi nhận đồ mà không cần nhắc ít nhất 1 lần.
3. Bé nói "Please!" hoặc "Here you are!" ít nhất 1 lần.

**Số đo của buổi 19** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 19 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 14 |
| Lượt bé nói "Can I have…" | ≥ 2 |
| Câu ≥ 3 từ bé nói ("Can I have the ball?", "Here you are!", "I like tigers.") | ≥ 3 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 20%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Can I have the ___? | | | | |
| Thank you! | | | | |
| Here you are! | | | | |
| Nhắc Mya "Please!" | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Ở nhà, bố/mẹ đợi bé nói "please" trước khi đưa đồ, nhẹ nhàng, không ép; bé quên thì chắp tay nhắc một lần rồi vẫn đưa.
- Khi đưa đồ cho bé: "Here you are!"; bé nói "Thank you!" là khen.
- Chơi bán hàng 2–3 món: bố/mẹ mua, nói "Can I have the banana, please?"; bé đưa là đạt, nói "Here you are!" càng tốt.
- Nghe bài "Please and Thank You", không bắt bé hát theo.
- Bố/mẹ không sửa phát âm, không bắt bé nói lại cả câu, không nói "con nói đi" quá 2 lần.

Buổi sau là Buổi 20 — Show time 2: bé biểu diễn những gì đã học từ buổi 11 tới 19.

---

## 9. Cho app (thư mục `Resources/Lessons/19-please/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt Mya cố tình quên "please" hay "thank you" (listen_do-6, teach_mya-2, teach_mya-4, teach_mya-6) có `"mistake": true`.
- Lượt bé ở chặng 5 chấm theo "Can I have the ball?" / "…teddy?" / "…banana?" (ngắn cho vừa chữ dưới thẻ); nhận cả câu có "please", "Ball, please" và "I want the ball" (biến thể ở `target_chunks`). Lời Mya vẫn đọc mẫu có "please".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Thank you! Good job!", "Thank you! Well done!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./Bye-bye! và See you next time!
- Câu lấy nguyên văn từ bài cũ có thể dùng lại file tiếng, không thu lại: buổi 18 (hello-5 = talk-2, recall-5 = talk-11; câu mẫu Lion!, I like monkeys.), buổi 11 (câu mẫu Ball!, Teddy!, Car!).
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; `wave`, `ball`, `qmark` là thẻ của app; `images/shop.svg` chép từ buổi 9), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 21.
