# Buổi 15 — Big and small.

Buổi thứ mười lăm: bé phân biệt big / small / tall bằng đồ thật và bằng cả người, nói "A big ball." khi nghe "Big or small?", nói "Mya is tall." và nhắc Mya khi Mya quên hoặc gọi nhầm to thành nhỏ.
File này gom mọi thứ của buổi 15 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/15-big/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 15) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–14, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 23% lượt của Mya |
| Từ mới | 3 từ: big, small, tall; cấu trúc "a big ball" học như một cụm, không giải thích trật tự từ |
| Sản phẩm cuối buổi | Bé chọn đúng to/nhỏ 4/5 lần khi nghe, nói "big" hoặc "small" ít nhất 2 lần, nói "A big ball." (hoặc "A small ball.") ít nhất 1 lần |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nghe "Give me the big ball!" (small) thì đưa đúng quả bóng.
- Trả lời "Big or small?" bằng "Big!" hoặc "Small!", rồi nói cả cụm "A big ball." / "A small ball." một lần.
- Làm dáng to (dang tay), nhỏ (co người), cao (kiễng chân với tay) khi nghe big, small, tall; nói "Mya is tall."
- Nhắc Mya khi Mya quên "big"/"small", và sửa khi Mya gọi gấu to là "small".

Không kỳ vọng: giải thích vì sao "big" đứng trước "ball", so sánh hơn (bigger, smaller), phát âm rõ "small". Bé chỉ nói "big" là **đạt**; Mya chỉ mời bé nói cả cụm một lần cho mỗi quả bóng. Bé hay dùng "big" cho mọi thứ: bình thường, "small" cần nhiều lần hơn, nên bài cho bé nói "small" nhiều lượt hơn "big".

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Big! | To | nói | big, it's big, a big, bích, bít, bíc, bic, no big, no! big, no |
| Small! | Nhỏ | nói | small, it's small, a small, xì mon, x mon, xi mon, smon, mon, sờ mon |
| Tall! | Cao | nói | tall, it's tall, tôn, to, thon |
| A big ball. | Một quả bóng to. | nói | a big ball, big ball, it's a big ball, it's big, big, ơ bích bon, bích bon |
| A small ball. | Một quả bóng nhỏ. | nói | a small ball, small ball, it's a small ball, it's small, small, ơ xì mon bon, xì mon bon |
| A big teddy. | Một con gấu to. | nói | a big teddy, big teddy, i have a big teddy, i have a teddy, a teddy, teddy, big, ơ bích té đi, bích té đi |
| Mya is tall. | Mya cao. | nói | mya is tall, maya is tall, mya tall, tall, is tall, mai a ít tôn, mai a tôn |
| Give me the big ball. / Give me the small ball. | Đưa Mya quả bóng to / nhỏ. | nghe | give me the big ball / give me the small ball |
| Big or small? | To hay nhỏ? | nghe | big or small |
| Bye-bye, big ball! | Tạm biệt bóng to! | nói | bye-bye big ball, bye bye big ball, bye big ball, bye-bye ball, bye-bye, bai bai bích bon, bai bai |
| It's sunny. / Rainy! / It's windy. | Trời nắng / mưa / có gió (ôn buổi 14) | nói | it's sunny, sunny, ít xa ni / rainy, it's rainy, rê ni / it's windy, windy, ít uyn đi |
| Put on your hat! | Đội mũ vào (ôn buổi 12, 14) | nghe + làm | put on your hat |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** give, me, the, this, or, clap (và các từ của buổi 1–14: ball, teddy, have, what, do, how's the weather, sunny, rainy, windy, cold, pshhh, whoosh, brrr, put on your hat, look, again, happy, how are you, said, thank you…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 2 quả bóng cùng màu, một to một nhỏ (bóng nhỏ vừa lòng bàn tay bé); 2 con gấu bông, một to một nhỏ (gấu của bé từ buổi 11–14 làm con to hoặc con nhỏ); túi vải kín (buổi 13); cái mũ (buổi 12); bình xịt nước nhỏ và quạt giấy (buổi 14); cửa sổ nhìn ra ngoài; loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Open Shut Them" (Super Simple Songs), mở ở chặng 6. Bố/mẹ bấm Space tạm dừng app, mở bài hát trên máy khác và làm động tác cùng bé; app không phát bài hát.
**Thẻ tranh trên màn hình** (emoji, thẻ `wave` của app, 1 hình SVG chép từ buổi 14 và 4 hình SVG mới; mỗi hình SVG mới có vật đang nói tô màu, vật kia chỉ là viền xám để so):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| ☀️ | It's sunny. | 1 |
| 🌧️ | Rainy! | 2 |
| `windy.svg` (gió xanh thổi lá, của buổi 14) | It's windy. | 2 |
| 🥶 | It's cold! | 2 |
| 👒 | Put on your hat! | 2 |
| 👝 (túi thần kỳ) | Look! | 3 |
| `ball-big.svg` (bóng đỏ to, bóng nhỏ viền xám) | Big!, A big ball!, Give me the big ball!, A big ball., Bye-bye, big ball! | 3, 4, 5, 7, 8 |
| `ball-small.svg` (bóng đỏ nhỏ, bóng to viền xám) | Small!, A small ball!, Give me the small ball!, A small ball., Bye-bye, small ball! | 3, 4, 5, 7, 8 |
| `teddy-small.svg` (gấu nhỏ, gấu to viền xám) | Small! | 5 |
| `teddy-big.svg` (gấu to, gấu nhỏ viền xám) | A big teddy., Big! | 5, 7 |
| 🎵 | Stand up! (lúc mở bài hát) | 6 |
| 🦒 (Mya cao) | Mya is tall!, Tall!, Mya is tall. | 6 |
| 🤏 | Small! (bé ngồi thụp xuống) | 6 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại vật nào to, vật nào nhỏ. Bóng và gấu trên thẻ vẽ theo thẻ `ball` và `bear` của app.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen gần cửa sổ. Bỏ 2 quả bóng vào túi; để mũ, bình xịt, quạt giấy, 2 con gấu cạnh mình, ngoài tầm tay bé. Dọn một khoảng trống cho bé đứng dậy, ngồi thụp xuống. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` ☀️

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you? và ôn thời tiết của buổi 14 trong 30 giây |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi hỏi How's the weather? |
| Bố/mẹ | Vẫy tay cùng bé; dắt bé tới cửa sổ **trước** câu hỏi How's the weather?; trời không nắng thì chỉ vào mặt trời trên màn hình |
| Ra khi | Bé đã chào hoặc trả lời, và nói (hoặc nói theo) "It's sunny." |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ dắt bé tới cửa sổ; trời không nắng thì chỉ vào mặt trời trên màn hình)* [cheerful] Look! [pause] [ask] How's the weather? [WAIT]
> *(bé: "Ít xa-ni." · sai/im: Mya đọc mẫu «It's sunny.»)*
> **Mya:** [excited] SUNNY! [pause] I'm happy! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 🌧️ `windy.svg` 🥶 👒

| | |
|---|---|
| Mục đích | Ôn 2 thứ cũ: thời tiết (buổi 14) và quần áo "Put on your hat!" (buổi 12), không dạy mới |
| Mya | Làm mưa, làm gió rồi hỏi How's the weather? hai lần; trời lạnh thì bảo bé đội mũ |
| Bố/mẹ | Xịt nước, quạt, run run **đúng lúc** Mya nói; đưa mũ cho bé **trước** lệnh đội mũ |
| Ra khi | Bé đã trả lời 2 kiểu thời tiết và đội mũ, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ để sẵn bình xịt nước, quạt giấy, cái mũ cạnh mình, ngoài tầm tay bé)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình ôn mưa, gió và cái mũ nhé.
> **Mya:** *(đúng lúc Mya nói Pshhh, bố/mẹ xịt nhẹ nước lên không trung, không xịt vào mặt bé)* [cheerful] Pshhh! [pause] [ask] How's the weather? [WAIT]
> *(bé: "Rê-ni!" · sai/im: Mya đọc mẫu «Rainy!»)*
> **Mya:** [excited] Wo-ow! [pause] Rainy! *(chỉ khi bé đúng)*
> **Mya:** *(đúng lúc Mya nói Whoosh, bố/mẹ quạt giấy về phía bé)* [cheerful] Whoosh! [pause] [ask] How's the weather? [WAIT]
> *(bé: "Ít uyn-đi." · sai/im: Mya đọc mẫu «It's windy.»)*
> **Mya:** [praise] It's WINDY! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ ôm mình run run làm mẫu)* [soft] Brrr! [pause] It's COLD!
> **Mya:** *(trước câu này bố/mẹ đưa cái mũ cho bé)* [cheerful] Cold? [pause] Put on your HAT! [WAIT]
> *(bé: "👉"; bé đội mũ, bố/mẹ giúp nếu khó · sai/im: Mya đọc mẫu «Put on your HAT!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Hat on! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 👝 `ball-big.svg` `ball-small.svg`

| | |
|---|---|
| Mục đích | Gây tò mò bằng túi thần kỳ: hai quả bóng, "BIG!" nói to, "small…" nói nhỏ |
| Mya | Thì thầm, gọi bóng to bằng giọng to, bóng nhỏ bằng giọng nhỏ, rồi mời bé nói "Big!" |
| Bố/mẹ | Lấy bóng to ra trước, giơ cao, dang tay; rồi lấy bóng nhỏ ra trong lòng bàn tay, chụm ngón tay; nói to/nhỏ cùng Mya |
| Ra khi | Bé nói (hoặc nói theo) "Big!" |

> **Mya:** *(bố/mẹ bỏ quả bóng to và quả bóng nhỏ vào túi vải kín, đặt trước mặt bé; cất bình xịt, quạt)* [vi] Con đội mũ đẹp quá! [pause 1s] Giờ xem túi thần kỳ của Mya nhé.
> **Mya:** *(bố/mẹ thò tay vào túi; lấy từng quả bóng ra khi Mya gọi)* [whisper] Shh… [pause] Look! [pause] [vi] Mya thò tay vào túi nhé.
> **Mya:** *(bố/mẹ lấy quả bóng to ra, giơ cao; nói to cùng Mya)* [excited] Look! [pause] A ball! [pause] BIG!
> **Mya:** *(bố/mẹ dang hai tay thật rộng quanh quả bóng to)* [cheerful] Big, big! [pause] A BIG ball!
> **Mya:** *(bố/mẹ lấy quả bóng nhỏ ra, để trong lòng bàn tay; nói nhỏ cùng Mya)* [whisper] And… [pause] a ball… [pause] small…
> **Mya:** *(bố/mẹ chụm hai ngón tay làm dáng nhỏ xíu)* [giggle] Small, small! [pause] A SMALL ball!
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ giơ quả bóng to lên)* [cheerful] Your turn! [pause] [slow] BIG! [WAIT]
> *(bé: "Bích!" · sai/im: Mya đọc mẫu «Big!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said big! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `ball-big.svg` `ball-small.svg`

| | |
|---|---|
| Mục đích | Hiểu big, small bằng tay: đưa đúng quả bóng, làm dáng to, dáng nhỏ; chưa cần nói |
| Mya | "Give me the BIG ball!", "Give me the SMALL ball!", rồi gọi Big!, Small! cho bé làm dáng |
| Bố/mẹ | Đặt 2 quả bóng trước mặt bé, đón bóng thay Mya; dang tay, co người làm mẫu |
| Ra khi | Bé đưa đúng ≥ 1 quả bóng và làm đúng ≥ 1 dáng |

> **Mya:** *(bố/mẹ đặt quả bóng to và quả bóng nhỏ trước mặt bé; bé đưa bóng thì bố/mẹ đón thay Mya)* [vi] Bóng to, bóng nhỏ ra hết rồi! [pause 1s] Giờ con đưa bóng cho Mya nhé.
> **Mya:** [cheerful] Give me the BIG ball! [WAIT]
> *(bé: "👉"; bé đưa quả bóng to cho bố/mẹ · sai/im: Mya đọc mẫu «Give me the BIG ball!»)*
> **Mya:** [excited] Yes! [pause] Big! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đặt quả bóng to về chỗ cũ trước câu này)* [whisper] Shh… [pause] Give me the SMALL ball! [WAIT]
> *(bé: "👉"; bé đưa quả bóng nhỏ cho bố/mẹ · sai/im: Mya đọc mẫu «Give me the SMALL ball!»)*
> **Mya:** [giggle] The small ball! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ dang hai tay thật rộng làm mẫu)* [excited] BIG! [pause] [vi] Con dang tay thật to nào! [WAIT]
> *(bé: "👉"; bé dang hai tay thật rộng · sai/im: Mya đọc mẫu «Big!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Big, big! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ ngồi co người lại làm mẫu)* [whisper] Small… [pause] [vi] Con co người lại thật nhỏ nào! [WAIT]
> *(bé: "👉"; bé ngồi co người lại thật nhỏ · sai/im: Mya đọc mẫu «Small!»)*
> **Mya:** [giggle] Small, small! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé đưa nhầm quả bóng → bố/mẹ chỉ vào quả đúng, Mya không nói sai, chờ bé đưa lại. Bé đưa cả hai quả → nhận cả hai, rồi giơ đúng quả Mya gọi.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `ball-big.svg` `ball-small.svg` `teddy-small.svg` `teddy-big.svg`

| | |
|---|---|
| Mục đích | Bé trả lời "Big or small?" và nói cả cụm "A big ball." / "A small ball."; nối với "What do you have?" của buổi 13 |
| Mya | Vòng 1: bóng to (một từ, rồi cả cụm). Vòng 2: bóng nhỏ (một từ, rồi cả cụm). Vòng 3: gấu nhỏ, rồi gấu to trong tay bé |
| Bố/mẹ | Giơ đúng đồ **trước** mỗi câu hỏi; đưa gấu to vào tay bé trước câu What do you have?; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ cầm sẵn 2 quả bóng và 2 con gấu, một to một nhỏ; thì thầm mẫu khi bé bí 2 lần liền)* [vi] Con đưa bóng giỏi quá! [pause 1s] Giờ Mya hỏi to hay nhỏ, con trả lời nhé.
> **Mya:** *(trước câu này bố/mẹ giơ quả bóng to)* [cheerful] Look! [pause] [ask] Big or small? [WAIT]
> *(bé: "Bích!" · sai/im: Mya đọc mẫu «Big!»)*
> **Mya:** [excited] Wo-ow! [pause] It's BIG! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] A BIG ball. [WAIT]
> *(bé: "Ơ bích bon." · sai/im: Mya đọc mẫu «A big ball.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said a big ball! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ cất quả bóng to, giơ quả bóng nhỏ)* [cheerful] And this ball… [pause] [ask] Big or small? [WAIT]
> *(bé: "Xì-mon!" · sai/im: Mya đọc mẫu «Small!»)*
> **Mya:** [praise] SMALL! [pause] It's small! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Again! [pause] [slow] A SMALL ball. [WAIT]
> *(bé: "Ơ xì-mon bon." · sai/im: Mya đọc mẫu «A small ball.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said a small ball! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ cất bóng, giơ con gấu nhỏ)* [giggle] A teddy! [pause] [ask] Big or small? [WAIT]
> *(bé: "Xì-mon!" · sai/im: Mya đọc mẫu «Small!»)*
> **Mya:** [excited] Small! [pause] A small teddy! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa con gấu to vào tay bé)* [cheerful] Look! [pause] [ask] What do you have? [WAIT]
> *(bé: "Ơ bích té-đi." · sai/im: Mya đọc mẫu «A big teddy.»)*
> **Mya:** [praise] You have a BIG teddy! [pause] Clap, clap! *(chỉ khi bé đúng)*

**Nói cả cụm (chỉnh của giai đoạn 2):** bé nói "Big!" là đúng; Mya khen rồi nói mẫu "A big ball." và mời bé nói cả cụm một lần. Ở lượt gấu to, bé nói "big teddy", "teddy" hay "I have a teddy" đều tính đúng. Không giải thích vì sao "big" đứng trước "ball".

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «A big ball.») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ giơ lại đồ đang hỏi khi Mya đọc mẫu. Bé nói "big" cho vật nhỏ → không sửa bằng lời; bố/mẹ đặt 2 vật cạnh nhau, chỉ vào vật nhỏ, Mya đọc mẫu «Small!». Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự cầm 2 đồ trong nhà, bố/mẹ hỏi "Big or small?", và bỏ chặng 7. **Bé ngơ:** cắt mỗi vòng còn 1 câu, chỉ hỏi bóng.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 🦒 🤏

| | |
|---|---|
| Mục đích | Xả năng lượng: kiễng chân với tay thật cao như Mya, ngồi thụp xuống thật nhỏ, nói "Mya is tall." |
| Mya | Ra lệnh Stand up!, khoe Mya cao, cho bé với tay cao, mời bé nói "Mya is tall.", rồi cho bé ngồi thụp xuống nhỏ xíu |
| Bố/mẹ | Bấm Space tạm dừng app lúc mở bài hát; chỉ vào Mya trên màn hình; kiễng chân, ngồi thụp xuống làm mẫu **đúng lúc** Mya nói |
| Ra khi | Hết giờ hoặc bé đã làm đủ dáng cao và dáng nhỏ |

> **Mya:** *(bố/mẹ cất bóng và gấu, dọn chỗ trống cho bé đứng)* [vi] Con khoe gấu giỏi quá! [pause 1s] Giờ mình đứng dậy, làm cao, làm nhỏ nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, mở bài "Open Shut Them" và làm động tác cùng bé; xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ chỉ vào Mya trên màn hình, giơ tay thật cao)* [excited] Look! [pause] Mya is TALL! [pause] Tall, tall!
> **Mya:** *(bố/mẹ kiễng chân, với tay lên cao làm mẫu)* [cheerful] Tall! [pause] [vi] Con kiễng chân, với tay thật cao nào! [WAIT]
> *(bé: "👉"; bé kiễng chân, với tay lên cao · sai/im: Mya đọc mẫu «Tall!»)*
> **Mya:** [giggle] Tall, tall! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] Mya is TALL. [WAIT]
> *(bé: "Mai-a ít tôn." · sai/im: Mya đọc mẫu «Mya is tall.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said Mya is tall! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ ngồi thụp xuống làm mẫu)* [vi] Còn con thì nhỏ xíu! [pause] [whisper] Small… [pause] [vi] Con ngồi thụp xuống nào! [WAIT]
> *(bé: "👉"; bé ngồi thụp xuống · sai/im: Mya đọc mẫu «Small!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Small, small! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `ball-big.svg` `ball-small.svg` `teddy-big.svg`

| | |
|---|---|
| Mục đích | Bé nhắc từ hai lần (Mya quên "It's…?") và sửa Mya một lần (Mya gọi gấu to là "small"); buổi 11–15 chủ yếu dùng quên |
| Mya | Bắt đầu "A ball… It's…" rồi ngập ngừng chờ bé nhắc; cuối cùng giơ gấu to mà nói "small" |
| Bố/mẹ | Lấy lại 2 quả bóng và con gấu to (đã cất ở chặng 5); giơ bóng to, bóng nhỏ, gấu to đúng lượt; nhắc nhỏ: "Mya quên rồi, con nhắc Mya đi" |
| Ra khi | Bé nhắc hoặc sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya quên hay nói nhầm thì con nhắc Mya nhé)* [vi] Con làm cao, làm nhỏ giỏi quá! [pause 1s] Giờ Mya nói, Mya quên thì con nhắc nhé.
> **Mya:** *(bố/mẹ giơ quả bóng to; Mya cố tình quên)* [puzzled] Hmm… [pause] A ball… [pause] [ask] It's…? [WAIT]
> *(bé: "Bích!" · sai/im: Mya đọc mẫu «Big!»)*
> **Mya:** [excited] BIG! [pause] A big ball! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ quả bóng nhỏ)* [puzzled] And this ball… [pause] [ask] It's…? [WAIT]
> *(bé: "Xì-mon!" · sai/im: Mya đọc mẫu «Small!»)*
> **Mya:** [giggle] SMALL! [pause] A small ball! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ con gấu to; Mya cố tình gọi nhầm thành nhỏ; bố/mẹ lắc đầu, nhắc nhỏ bé nói: No! Big!)* [cheerful] Look! [pause] A… SMALL teddy! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! Bích!" · sai/im: Mya đọc mẫu «Big!»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh! [pause] A BIG teddy! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé chỉ nói "No!" ở lượt gấu to cũng tính là đã sửa. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `ball-big.svg` `ball-small.svg` `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: chào bóng to, bóng nhỏ, nói "bye-bye" |
| Mya | Chào bóng to và mời bé chào theo, chào bóng nhỏ, khen cụ thể, chào bé |
| Bố/mẹ | Giơ 2 quả bóng rồi cất vào túi; vẫy tay cùng bé; dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ giơ 2 quả bóng; vẫy tay cùng bé)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào bóng to, bóng nhỏ nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, big ball! [pause] Your turn! [WAIT]
> *(bé: "Bai-bai, bích bon!" · sai/im: Mya đọc mẫu «Bye-bye, big ball!»)*
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, small ball!
> **Mya:** [vi] Hôm nay con nói được to, nhỏ, cao. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 📏, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói "big" cho mọi thứ | Bình thường. Không sửa bằng lời; bố/mẹ đặt 2 vật cạnh nhau, chỉ vào vật nhỏ, Mya đọc mẫu «Small!» rồi đi tiếp. |
| Bé chỉ nói một từ ("big") | Tính là đúng. Mya nói lại cả cụm "A big ball." 1 lần rồi đi tiếp. |
| Bé nói bằng tiếng Việt ("to", "nhỏ") | Công nhận rồi bắc cầu: "To! Big!" Không bắt nói lại ngay. |
| Nhà không có 2 quả bóng khác cỡ | Dùng 2 đồ cùng loại khác cỡ (2 cái cốc, 2 cái hộp); Mya vẫn nói "ball" như lời của bài, bố/mẹ chỉ vào thẻ bóng trên màn hình. |
| Bé chỉ có 1 con gấu | Dùng gấu của bé làm con to và một thú bông nhỏ hơn làm con nhỏ (hoặc ngược lại). |
| Bé ném bóng | Chơi cùng 1 lượt ("Big ball! Wow!"), rồi bố/mẹ cất bóng lại vào túi. Không mắng. |
| Bé đòi giữ cả 2 quả bóng | Cho bé giữ, bố/mẹ chỉ vào quả Mya gọi; không giật lại. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc làm cao, làm nhỏ | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé kể đồ to, đồ nhỏ ở nhà | Theo bé 1 lượt ("Wow! Big!"), rồi quay lại bài. Không dạy thêm. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé chọn đúng to/nhỏ 4/5 lần khi nghe (đưa bóng, làm dáng, trả lời Big or small?).
2. Bé nói "big" hoặc "small" ít nhất 2 lần, và "A big ball." (hoặc "A small ball.") ít nhất 1 lần (chỉ nói một từ vẫn tính).
3. Bé nhắc hoặc sửa được Mya ở chặng 7.

**Số đo của buổi 15** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 15 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 12 |
| Lượt bé nói "small" | ≥ 1 |
| Câu ≥ 2 từ bé nói ("A big ball.", "Mya is tall.") | ≥ 2 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 23%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| big / small / tall | | | | |
| A big ball. / A small ball. | | | | |
| Mya is tall. | | | | |
| Nhắc hoặc sửa Mya | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Lúc tắm, bố/mẹ giơ 2 đồ vật (cái chậu và cái cốc, con vịt to và nhỏ), hỏi "Big or small?", bé đáp 1 từ.
- Lúc dọn đồ chơi: "Give me the big ball!", "Give me the small car!"; bé đưa đúng là đạt, không bắt nói.
- Đo bé bằng thước dây hoặc đứng cạnh bố/mẹ: "Daddy is tall! Bông is small!".
- Mở "Open Shut Them" lúc chơi, không bắt bé hát theo.
- Bố/mẹ không sửa phát âm, không sửa "big" thành "small" bằng lời, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 16 — đếm từ six tới ten) mở đầu bằng câu "Big or small?" với 2 quả bóng.

---

## 9. Cho app (thư mục `Resources/Lessons/15-big/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt bé "A big ball." / "A small ball." nhận cả khi bé chỉ nói "big"/"small" (biến thể ở `target_chunks`); lượt "Big!" ở chặng 7 nhận cả "No!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./Bye-bye! và See you next time!
- Câu lấy nguyên văn từ buổi 14 (hello-5, hello-6, recall-2 … recall-8, talk-12, các câu mẫu It's sunny./Rainy!/It's windy./Put on your HAT!) và buổi 13 (reveal-2) dùng lại file tiếng của bài cũ, không thu lại.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; `wave` là thẻ của app; `images/windy.svg` chép từ buổi 14; `images/ball-big.svg`, `ball-small.svg`, `teddy-big.svg`, `teddy-small.svg` vẽ riêng), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 17.
