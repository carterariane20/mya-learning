# Buổi 10 — Show time!

Buổi cuối của khoá 10 buổi: bé ôn nhanh 4 trạm (màu, con vật, bộ phận, số), tập 5 câu giới thiệu rồi biểu diễn cho bố/mẹ xem: "Hello!", "I'm ___.", "I'm ___ (tuổi).", "I like bananas.", "Bye-bye!"; nhận huy chương thì nói "Thank you!".
File này gom mọi thứ của buổi 10 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/10-showtime/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 10) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–9, bố hoặc mẹ ở nhà cùng bé |
| Tiếng Việt | khoảng 20% lượt của Mya |
| Từ mới | không có; chỉ nghe thêm "Show time!", "You did it!", "I'm proud of you!" |
| Sản phẩm cuối buổi | Bé tự nói 5 câu trên sân khấu, bố/mẹ quay video |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Tự nói 5 câu: Hello! / I'm ___. / I'm ___ (tuổi). / I like bananas. / Bye-bye!
- Nói "Thank you!" khi nhận huy chương.
- Không cần gợi ý quá 2 lần trong lúc biểu diễn.
- Biểu diễn một lần cho bố/mẹ xem, có quay video.

Không kỳ vọng: bé nói tròn câu, phát âm chuẩn, nói đúng thứ tự mà không nhìn thẻ. Bé nhìn Mya hoặc nhìn thẻ 1–2 lần là bình thường. Bé ngại đứng lên sân khấu thì cho bé ngồi trong lòng bố/mẹ mà diễn.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Hello! | Xin chào! | nói | hello, hi, hé lô, he lô, lô |
| I'm Bông. | Con là Bông. | nói | i'm Bông, i am Bông, am Bông, Bông |
| I'm four. | Con bốn tuổi. | nói (theo tuổi bé) | i'm four, i am four, am four, four |
| I like bananas. | Con thích chuối. | nói | i like bananas, i like banana, like bananas, ai lai ba na na, ai lai chuối |
| Bye-bye! | Tạm biệt! | nói | bye-bye, bye bye, bye, bai bai, bai |
| Thank you! | Cảm ơn! | nói | thank you, thanks, thanh kiu, tank kiu, then kiu |
| You did it! | Con làm được rồi! | nghe | you did it |
| I'm proud of you! | Mya tự hào về con! | nghe | i'm proud of you, proud of you |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** show, time, did, proud, of, you're, mmm, many, old (và các từ của buổi 1–9: what's your name, how are you, happy, what color is it, it's blue, what's this, it's a cat, meow, where's your nose, this is my nose, how many, one, two, three, four, yummy, jump, run, dance, you said, see you next time…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

**Câu "I like ___":** app chấm theo "I like bananas.", nên bố/mẹ giơ quả chuối **trước** câu hỏi. Bé nói món khác ("I like milk") thì bố/mẹ vẫn vỗ tay khen; app có thể đọc mẫu «I like bananas.», cứ đi tiếp.

---

## 3. Chuẩn bị

**Đồ vật:** 1 "sân khấu" (vài cái gối, một tấm khăn trải sàn, một tấm khăn làm rèm), huy chương giấy, 5 sticker cho chặng 4 và 1 sticker cuối buổi, điện thoại để quay video, bóng bay, 1 quả chuối. Cho chặng 2 (4 trạm ở 4 góc phòng): 1 khối xanh dương, 1 thú bông con mèo (hoặc tranh mèo), 1 cái gương, 3 khối xếp hàng.
**Bài hát:** "Hello Song" trước khi bấm học; "Bye-bye Song" ở chặng 8. Bố/mẹ mở trên loa; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (emoji và tranh SVG phẳng trong `images/`, chép từ bài 3):

| Thẻ | Hình | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|---|
| `wave` | bàn tay vẫy (thẻ có sẵn của app) | Hello!, Bye-bye! | 1, 3, 4, 5, 6, 7, 8 |
| 🎤 | micro (buổi biểu diễn) | Show time! | 1, 3, 6 |
| 🟦 | ô vuông xanh dương | It's blue. | 2 |
| 🐱 | con mèo | It's a cat. | 2 |
| 👃 | cái mũi | This is my nose. | 2 |
| `blocks-3.svg` | 3 khối | Three! | 2 |
| 🦒 | hươu (Mya) | I'm Mya. | 3 |
| `fingers-4.svg` | bàn tay giơ 4 ngón (tuổi của Mya) | I'm four., Four! | 3, 7 |
| 🍌 | quả chuối | Bananas! (lượt bé: I like bananas.) | 3, 4, 5, 6 |
| 👏 | hai tay vỗ | Thank you!, You did it! | 3, 6 |
| 🧒 | em bé (chính bé) | I'm Bông. | 4, 5, 6 |
| `fingers-{age}.svg` | bàn tay giơ số ngón bằng tuổi bé (đủ hình 3–7 tuổi) | I'm four. (theo tuổi bé) | 4, 5, 6 |
| 🏅 | huy chương | Thank you!, You did it! | 8 |

Chữ dưới thẻ ở lượt Mya được rút gọn ("Bananas!") cho vừa màn hình hẹp; ở lượt bé, chữ dưới thẻ là nguyên câu app chấm.
Thẻ chỉ có tranh vẽ, không có ảnh thật. Bài này không mang tên hay ảnh thật của bé; video bố/mẹ quay giữ trong máy nhà mình.
**Bố/mẹ trước buổi:** bày sẵn 4 trạm và đồ làm sân khấu, sạc điện thoại. Cho bé đi vệ sinh, uống nước. Không học khi bé buồn ngủ, vừa ăn no hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app không bật mic, chờ 3 giây rồi đi tiếp (câu khen sau đó vẫn phát).

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` rồi 🎤

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên và How are you?, Mya khen bé đã học 10 buổi |
| Mya | Chào, hỏi tên, hỏi How are you?, báo hôm nay là buổi biểu diễn |
| Bố/mẹ | Mở Hello Song cho cả nhà hát trước khi bấm học; vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* *(trước khi bấm học, bố/mẹ mở Hello Song cho cả nhà hát; ngồi cạnh bé, vẫy tay cùng bé)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(vẫy, `wave`)* [vi] Con học với Mya mười buổi rồi đó, giỏi quá! [pause] Hôm nay con biểu diễn nhé. [pause] [excited] Show time!

### Chặng 2 · Ôn nhanh (`recall`) · phút 4–9 · thẻ 🟦 🐱 👃 `blocks-3.svg`

| | |
|---|---|
| Mục đích | Ôn nhanh 4 trạm: màu (buổi 4), con vật (buổi 5), bộ phận (buổi 6), số (buổi 3). Bé chạy, nhảy, nhảy múa, dừng giữa các trạm để ôn hành động của buổi 9 |
| Mya | Hô Run!/Jump!/Dance!/Stop! cho bé tới từng trạm, hỏi một câu ở mỗi trạm |
| Bố/mẹ | Bày 4 trạm trước buổi; giơ đồ của trạm lên **trước** câu hỏi |
| Ra khi | Đủ 4 trạm (mỗi trạm khoảng 90 giây) hoặc hết 5 phút |

> **Mya:** *(trước buổi bố/mẹ bày 4 trạm ở 4 góc phòng: khối xanh dương, thú bông con mèo (hoặc tranh mèo), gương, 3 khối xếp hàng)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình chạy qua bốn trạm ôn bài nhé: màu, con vật, cái mũi, đếm số.
> **Mya:** *(nghiêng đầu, `listen`)* *(bé chạy tới trạm 1; bố/mẹ giơ khối xanh dương lên)* [excited] Run, run! [pause] Look! [pause] [ask] What color is it? [WAIT]
> *(bé: "Ít bờ lu." · sai/im: Mya đọc mẫu «It's blue.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said blue! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bé nhảy tới trạm 2; bố/mẹ giơ thú bông con mèo lên)* [cheerful] Jump, jump! [pause] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Ít sờ a két." · sai/im: Mya đọc mẫu «It's a cat.»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Meow! [pause] It's a cat! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bé vừa nhảy múa vừa tới trạm 3 (gương); bố/mẹ chạm mũi mình làm mẫu)* [sing-song] Dance, dance! [pause] [ask] Where's your nose? [WAIT]
> *(bé: "Đít ít mai nâu."; bé chạm mũi · sai/im: Mya đọc mẫu «This is my nose.»)*
> **Mya:** *(vẫy, `wave`)* [excited] Yes! Your NOSE! [pause] Nice! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bé chạy tới trạm 4, nghe Stop thì đứng lại; bố/mẹ chỉ vào 3 khối)* [cheerful] Run, run! [pause] Stop! [pause] [ask] How many? [WAIT]
> *(bé: "Thờ ri!" · sai/im: Mya đọc mẫu «Three!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Three! [pause] One, two, THREE! [pause] Wo-ow! *(chỉ khi bé đúng)*

### Chặng 3 · Dựng show (`reveal`) · phút 9–14 · thẻ 🎤 `wave` 🦒 `fingers-4.svg` 🍌 `wave` 👏

| | |
|---|---|
| Mục đích | Gây hứng: cùng dựng sân khấu, xem Mya diễn mẫu 5 câu |
| Mya | Hô Show time!, diễn 5 câu của mình: Hello! / I'm Mya. / I'm four! / I like bananas! / Bye-bye! |
| Bố/mẹ | Cùng bé xếp gối, trải khăn, buộc bóng bay; giơ quả chuối khi Mya nói I like bananas |
| Ra khi | Mya diễn xong, bé vỗ tay |

> **Mya:** *(bố/mẹ cùng bé xếp gối, trải khăn làm sân khấu, buộc bóng bay hai bên)* [vi] Bốn trạm xong rồi, con nhớ hết luôn! [pause 1s] Giờ mình dựng sân khấu để biểu diễn nhé.
> **Mya:** *(bé ngồi trước sân khấu xem Mya diễn)* [excited] Wo-ow! [pause] Show time! [pause] Look!
> **Mya:** *(vẫy, `wave`)* [cheerful] Hello!
> **Mya:** [cheerful] I'm MYA.
> **Mya:** *(Mya giơ 4 ngón; bố/mẹ chỉ vào thẻ)* [cheerful] I'm FOUR!
> **Mya:** *(bố/mẹ giơ quả chuối lên)* [giggle] I like bananas! [pause] Yummy!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye!
> **Mya:** *(bé và bố/mẹ vỗ tay)* [vi] Đó, năm câu thôi! [pause] Con vỗ tay cho Mya đi!
> **Mya:** *(vẫy, `wave`)* [praise] Thank you!

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `wave` 🧒 `fingers-{age}` 🍌 `wave`

| | |
|---|---|
| Mục đích | Hiểu 5 câu bằng động tác, chưa cần nói: Hello → vẫy tay, I'm… → đặt tay lên ngực, How old are you? → giơ ngón tay, I like bananas → xoa bụng, Bye-bye! → cúi chào rồi vẫy tay |
| Mya | Nói từng câu, chờ bé làm động tác rồi khen |
| Bố/mẹ | Làm động tác mẫu **trước**; bé làm đúng thì dán một sticker (đủ 5 sticker cho 5 câu) |
| Ra khi | Bé làm đủ 5 động tác |

> **Mya:** *(bố/mẹ cầm sẵn 5 sticker; mỗi câu bố/mẹ làm động tác mẫu trước, bé làm đúng thì dán một sticker lên áo bé)* [vi] Mya diễn xong rồi! [pause 1s] Giờ con tập động tác cho từng câu. Làm đúng là được một sticker nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ vẫy tay làm mẫu)* [cheerful] Hello! [pause] Hello! [WAIT]
> *(bé: "👉"; bé vẫy tay · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker thứ nhất)* [praise] Hello! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ đặt tay lên ngực mình làm mẫu)* [slow] I'm… [WAIT]
> *(bé: "👉"; bé đặt tay lên ngực mình · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker thứ hai)* [giggle] Yes! [pause] Nice! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ giúp bé giơ số ngón tay bằng tuổi bé)* [ask] How old are you? [WAIT]
> *(bé: "👉"; bé giơ ngón tay bằng tuổi mình · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker thứ ba)* [excited] Wo-ow! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ quả chuối, xoa bụng làm mẫu)* [cheerful] I like bananas! [WAIT]
> *(bé: "👉"; bé xoa bụng · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker thứ tư)* [giggle] Mmm! Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ cúi chào rồi vẫy tay làm mẫu)* [sing-song] Bye-bye!
> *(bé: "👉"; bé cúi chào rồi vẫy tay · app chờ 3 giây rồi đi tiếp)*
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker thứ năm)* [praise] Nice! [pause] Well do-one! *(chỉ khi bé đúng)*

Lượt 👉 app không chấm: bố/mẹ là người xem bé làm đúng hay chưa. Bé làm sai vẫn dán sticker, rồi làm lại cùng bé một lần.

### Chặng 5 · Tổng duyệt (`talk`) · phút 20–31 · thẻ `wave` 🧒 `fingers-{age}` 🍌 `wave`

| | |
|---|---|
| Mục đích | Bé nói 5 câu với Mya, Mya sửa nhẹ |
| Mya | Vòng 1: Hello! và I'm ___. Vòng 2: I'm ___ (tuổi) và I like bananas. Vòng 3: Bye-bye! |
| Bố/mẹ | Ngồi cạnh sân khấu, chỉ vào thẻ khi bé bí; giơ quả chuối **trước** câu I like… |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

> **Mya:** *(bé đứng trên sân khấu; bố/mẹ ngồi cạnh, chỉ vào thẻ khi bé bí)* [vi] Con làm đúng hết động tác rồi! [pause 1s] Giờ mình tập thử: con lên sân khấu, nói từng câu với Mya nhé.
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Ready? [pause] Your turn! [WAIT]
> *(bé: "Hé lô!"; bé vẫy tay · sai/im: Mya đọc mẫu «Hello!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said hello! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] What's your name? [WAIT]
> *(bé: "Am Bông." · sai/im: Mya đọc mẫu «I'm… Bông.»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào thẻ ngón tay)* [ask] How old are you? [WAIT]
> *(bé: "Am four." · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** *(vẫy, `wave`)* [gasp] [praise] Wo-ow! You're FOUR! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ giơ quả chuối lên)* [vi] Con thích món gì? Nói cả câu nhé: [pause] [slow] I like… [WAIT]
> *(bé: "Ai lai na-na." · sai/im: Mya đọc mẫu «I like bananas.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said I like bananas! [pause] Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ cúi chào, vẫy tay làm mẫu)* [cheerful] One more! [pause] [vi] Con chào mọi người nhé! [WAIT]
> *(bé: "Bai bai!"; bé cúi chào, vẫy tay · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! [pause] [praise] Well do-one! *(chỉ khi bé đúng)*

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Hello!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào thẻ khi Mya đọc mẫu. Bé chỉ làm động tác mà không nói là đã hiểu: bố/mẹ nói cùng bé một lần, đi tiếp. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt còn vòng 1 và vòng 3, chỉ tay nhiều hơn.

### Chặng 6 · Biểu diễn (`move`) · phút 31–38 · thẻ 🎤 `wave` 🧒 `fingers-{age}` 🍌 `wave` 👏

| | |
|---|---|
| Mục đích | Buổi diễn thật: bé bước lên sân khấu, nói 5 câu, cúi chào, cả nhà vỗ tay |
| Mya | Giới thiệu bé, thì thầm mở đầu từng câu (Your turn… / I'm… / How old are you? / I like… / One more…), khen khi xong |
| Bố/mẹ | Ngồi trước sân khấu, quay video; không nhắc, bé bí thì chỉ vào thẻ; vỗ tay thật to ở cuối |
| Ra khi | Bé nói xong 5 câu, cúi chào |

> **Mya:** *(bố/mẹ ngồi trước sân khấu, bật quay video bằng điện thoại; bé đứng sau tấm khăn chờ)* [vi] Tập xong rồi, con nói hay lắm! [pause 1s] Giờ là buổi diễn thật. Bố mẹ ngồi xem và quay video nhé!
> **Mya:** *(vẫy, `wave`)* *(bé bước lên sân khấu; bố/mẹ vỗ tay)* [excited] Show time! [pause] It's… BÔNG!
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ không nhắc; bé bí thì chỉ vào thẻ)* [whisper] Your turn… [WAIT]
> *(bé: "Hé lô!"; bé vẫy tay · sai/im: Mya đọc mẫu «Hello!»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] I'm… [WAIT]
> *(bé: "Am Bông." · sai/im: Mya đọc mẫu «I'm… Bông.»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] How old are you? [WAIT]
> *(bé: "Am four."; bé giơ ngón tay · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] I like… [WAIT]
> *(bé: "Ai lai na-na."; bé xoa bụng · sai/im: Mya đọc mẫu «I like bananas.»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] One more… [WAIT]
> *(bé: "Bai bai!"; bé cúi chào, vẫy tay · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! You did it! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ vỗ tay thật to rồi dừng quay video; bé cúi chào rồi nhảy)* [vi] Cả nhà vỗ tay nào! [pause] Con cúi chào rồi nhảy thật cao! [pause] [excited] Jump! Jump!

Bé ngại thì cho bé ngồi trong lòng bố/mẹ mà diễn, vẫn tính là biểu diễn.

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `wave` rồi `fingers-4.svg`

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya diễn sai thứ tự và nói sai tuổi của mình |
| Mya | Vừa lên sân khấu đã nói "Bye-bye!"; nói "I'm five!" trong khi thẻ giơ 4 ngón |
| Bố/mẹ | Chỉ vào thẻ; nhắc nhỏ: "Mya nói sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya nói sai thì con nhắc Mya nhé)* [vi] Con diễn hay quá! [pause 1s] Giờ tới lượt Mya diễn. Mya nói sai thì con sửa giúp Mya nhé.
> **Mya:** *(vẫy, `wave`)* *(Mya vừa lên sân khấu đã chào tạm biệt; bố/mẹ lắc đầu, vẫy tay chào)* [cheerful] Show time! [pause] Bye-bye! [WAIT]
> *(bé: "No! Hé lô!" · sai/im: Mya đọc mẫu «Hello!»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh no! [pause] HELLO! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(Mya cố tình nói sai tuổi; bố/mẹ chỉ vào 4 ngón tay trên thẻ)* [cheerful] I'm MYA. [pause] I'm FIVE! [WAIT]
> *(bé: "No! Pho!" · sai/im: Mya đọc mẫu «Four…»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Four! I'm FOUR! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Trao thưởng và tạm biệt (`bye`) · phút 43–45 · thẻ 🏅 rồi `wave`

| | |
|---|---|
| Mục đích | Trao huy chương, "You did it!", "I'm proud of you!", bé nói "Thank you", chào và hẹn 10 buổi tiếp |
| Mya | Khen cụ thể, chờ bé cảm ơn, chào bé |
| Bố/mẹ | Đeo huy chương giấy, tặng bóng bay, ôm bé; mở Bye-bye Song, dán sticker |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ đeo huy chương giấy cho bé, tặng bóng bay)* [vi] Sắp hết giờ rồi! [pause 1s] Con học xong mười buổi, Mya có huy chương cho con nè.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ ôm bé, thì thầm: con cảm ơn Mya đi)* [excited] You did it! [pause] I'm proud of you! [WAIT]
> *(bé: "Thanh kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] You said thank you! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [vi] Hôm nay con tự nói năm câu và biểu diễn cho cả nhà xem. [pause] Giỏi quá! [pause] Mười buổi sau mình gặp lại nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở Bye-bye Song, dán sticker, cả nhà vẫy tay)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🏅, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé ngại lên sân khấu | Bình thường. Bé ngồi trong lòng bố/mẹ mà diễn, hoặc bố/mẹ đứng cạnh nắm tay bé. |
| Bé chỉ làm động tác, chưa nói | Tính là hiểu. Bố/mẹ nói cùng bé một lần rồi đi tiếp, không ép. |
| Bé nói bằng tiếng Việt ("con tên Bông") | Công nhận rồi bắc cầu: "Yes! I'm Bông!" Không bắt nói lại ngay. |
| Bé quên câu giữa buổi diễn | Bố/mẹ chỉ vào thẻ, không nói hộ. Bé vẫn bí thì app đọc mẫu, bé nói theo là được. |
| Bé nói món khác ở câu I like ___ | Vỗ tay khen như thường. App có thể đọc mẫu «I like bananas.», cứ đi tiếp. |
| Bé đòi xem video ngay | Cho xem sau buổi; trong buổi hứa "xem cùng nhau sau khi chào Mya". |
| Bé chạy lung tung, hò hét | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé khóc hoặc sợ | Dừng hẳn, bố/mẹ ôm bé. "[soft] [vi] Mya ở đây. [pause] Con uống nước nhé." |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé nói "Stop", "thôi", "dừng lại" | App hiểu là bé muốn nghỉ: dừng ngay, hiện màn "Mình nghỉ nhé". Bố/mẹ hỏi bé muốn chơi tiếp không, rồi bấm học tiếp. |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, đóng ở phút 38. Giữ chặng 6 (biểu diễn). |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5 và 6. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé nói được 5 câu ở chặng 6, dù phát âm chưa chuẩn.
2. Bé không cần gợi ý quá 2 lần trong lúc biểu diễn.
3. Bé nói "Thank you" khi nhận huy chương.

**Số đo của buổi 10** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 10 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 12 |
| Câu bé tự nói ở chặng 6 | ≥ 4 trong 5 câu |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 60% |
| Lượt Mya nói tiếng Việt | khoảng 20%, vượt 30% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Hello! / I'm ___. | | | | |
| I'm ___ (tuổi). | | | | |
| I like bananas. | | | | |
| Bye-bye! | | | | |
| Thank you! (nhận huy chương) | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Xem lại video cùng bé 1 lần, khen cụ thể ("Con nói 'I like bananas' rõ lắm").
- Gửi video cho ông bà hoặc người thân (chỉ trong gia đình), để bé được khen thêm.
- Mỗi tối chọn 1 trò bé thích nhất trong 10 buổi chơi lại 2 phút.
- Bố/mẹ không ép bé lặp, không sửa phát âm, không nói "con nói đi" quá 2 lần.

Sau buổi 10: xem [mục 8 của giáo trình](../GIAO-TRINH-10-BUOI.md#8-sau-10-buổi).

---

## 9. Cho app (thư mục `Resources/Lessons/10-showtime/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên hoặc tuổi bé (`{name}`, `{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên hoặc tuổi bé). Câu mẫu «Hello!» dùng lại tiếng của `reveal-3`; «Three!», «Four…», «Thank you!», «Bye-bye!», «I'm happy.» lấy từ thư viện chung.
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác (chặng 4): app không bật mic, chờ 3 giây rồi đi tiếp.
- Câu khen ngay sau lượt bé có `"on": "right"`. `teach_mya-4` có `"mistake": true` (Mya cố tình nói "five" khi thẻ giơ 4 ngón).
- Câu có trong thư viện chung dùng `lib` (chào, How are you?, Happy!, High five!, Wow!, Thank you!, Bye-bye, Well done!, See you next time!).
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, key `wave` có sẵn của app, và 6 file SVG trong `images/` chép từ `03-numbers`: `blocks-3`, `fingers-3` … `fingers-7`), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 12.
