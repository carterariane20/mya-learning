# Buổi 8 — Food. I like bananas.

Buổi thứ tám: bé gọi được apple, banana, milk, egg, nói "I like bananas." với một món, và nói "Yummy!", "I'm hungry.".
File này gom mọi thứ của buổi 8 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/08-food/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 8) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–7, bố hoặc mẹ ở nhà cùng bé |
| Tiếng Việt | khoảng 25% lượt của Mya |
| Từ mới | apple, banana, milk, egg, rice, I like bananas., Do you like milk?, Yummy!, I'm hungry. |
| Sản phẩm cuối buổi | Bé gọi đúng 3 trong 5 món và nói "I like ___" một lần |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Gọi được apple, banana, milk, egg khi thấy đồ thật hoặc thẻ; chạm đúng bát cơm khi nghe "rice".
- Nói "I like ___" với một món (I like bananas., I like milk.).
- Nói "Yummy!" khi nếm, "I'm hungry." khi xoa bụng.

Không kỳ vọng: tự hỏi được "Do you like milk?", nói đúng số nhiều "bananas", phát âm rõ "I like". Bé nói "ba-na-na" chậm là tốt; "I wike" là bình thường ở tuổi 4, không sửa.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Apple! | Táo | nói | apple, apples, ép pồ, ép bồ, áp pồ |
| Banana! | Chuối | nói | banana, bananas, ba na na, bơ na na, na na |
| Milk! | Sữa | nói | milk, miu, mil, miếc |
| Egg! | Trứng | nói | egg, eggs, ét, éc, eo |
| Rice! | Cơm | nghe | rice, rai, rái, rai xơ |
| I like bananas. | Con thích chuối. | nói | i like bananas, i like banana, like bananas, i wike bananas, ai lai ba na na, ai wai ba na na |
| Do you like milk? | Con thích sữa không? | nghe | do you like milk, you like milk, like milk, đu diu lai miu |
| Yummy! | Ngon quá! | nói | yummy, yum yum, yum, dăm mi, giăm mi |
| I'm hungry. | Con đói. | nói | i'm hungry, im hungry, hungry, am hungry, hăng gri, am hăng gri |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** the, give me, too, mmm, apples (và các từ của buổi 1–7: who's this, what's this, a, touch, jump, you said, mommy, daddy, baby…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** loa, giỏ có khăn phủ, đồ ăn thật đã rửa sạch (1 quả chuối, 1 quả táo, 1 quả trứng luộc, 1 hộp sữa), đĩa, khăn, thìa. Cơm không cần mang ra: bé chạm bát cơm trên màn hình. Cắt sẵn vài miếng chuối và táo nhỏ để bé nếm ở chặng 6 và 8; bé dị ứng món nào thì chỉ cầm, không nếm.
**Bài hát:** "Apples and Bananas" ở chặng 6; "Do You Like Broccoli Ice Cream?" nếu bé còn hứng (chỉ nghe, không dạy hết từ). Bố/mẹ mở trên loa và bấm Space tạm dừng app lúc hát; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (mỗi thẻ một vật chính, trừ tranh cả nhà hươu):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, Bye-bye! | 1, 8 |
| `giraffe-family.svg` (chép từ buổi 7, hươu bố, mẹ, em bé đứng cạnh nhau) | Look! | 2 |
| `giraffe-mommy.svg`, `giraffe-daddy.svg`, `giraffe-baby.svg` (chép từ buổi 7) | Mommy!, Daddy!, Baby! | 2 |
| 🧺 | What's this? | 3 |
| 🍌 | Banana!, Touch the banana!, Do you like bananas?, Yes!, I like bananas., Banana, please! | 3, 4, 5, 6, 7 |
| 😋 | Yummy! | 3, 6, 8 |
| 🍎 | Apple!, Give me the apple!, Yes!, I like apples., Apple, please! | 3, 4, 5, 6 |
| 🥛 | Milk!, Give me the milk!, Yes!, I like milk., Do you like milk?, Milk, please! | 3, 4, 5, 6 |
| 🥚 | Egg!, Touch the egg! | 3, 4, 7 |
| 🍚 | Rice!, Touch the rice! | 3, 4 |
| 🍽️ | Listen!, Sit down! | 4, 6 |
| `hungry.svg` (SVG phẳng, hươu con xoa bụng đang kêu) | I'm hungry. | 5 |
| 🏪 | Let's go! | 6 |

Thẻ chỉ có tranh vẽ và emoji, không có ảnh thật. Bài này không mang tên hay ảnh thật của bé.
**Bố/mẹ trước buổi:** cho bé ăn nhẹ trước 1 tiếng, đừng để bé quá no (bé còn nếm thử) hoặc quá đói (bé cáu). Đi vệ sinh, ngồi đúng chỗ quen. Rửa tay cho bé trước chặng 3. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `giraffe-family.svg` `giraffe-mommy.svg` `giraffe-daddy.svg` `giraffe-baby.svg`

| | |
|---|---|
| Mục đích | Ôn mommy, daddy, baby của buổi 7 bằng tranh nhà hươu và câu Who's this? (không dạy mới) |
| Mya | Hỏi Who's this? với từng con hươu |
| Bố/mẹ | Ngồi sát bé, chỉ vào từng con hươu trên màn hình **trước** khi Mya hỏi |
| Ra khi | Bé gọi đúng ≥ 2 con hươu hoặc hết 5 phút |

> **Mya:** *(bố/mẹ ngồi sát bé, cùng nhìn tranh nhà hươu trên màn hình)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình gặp lại cả nhà hươu nhé.
> **Mya:** *(hươu mẹ hiện trên màn hình; trước câu này bố/mẹ chỉ vào hươu mẹ)* [cheerful] Look! [pause] [ask] Who's this? [WAIT]
> *(bé: "Mami!" · sai/im: Mya đọc mẫu «Mommy!»)*
> **Mya:** [praise] MOMMY! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(hươu bố hiện trên màn hình; trước câu này bố/mẹ chỉ vào hươu bố)* [ask] Who's this? [WAIT]
> *(bé: "Đét đi!" · sai/im: Mya đọc mẫu «Daddy!»)*
> **Mya:** *(vẫy, `wave`)* [excited] DADDY! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(hươu em bé hiện trên màn hình; bố/mẹ đặt ngón tay lên môi rồi chỉ vào em bé)* [whisper] Shh… [pause] [ask] Who's this? [WAIT]
> *(bé: "Bây bi!" · sai/im: Mya đọc mẫu «Baby!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] BABY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 🧺 🍌 😋 🍎 🥛 🥚 🍚

| | |
|---|---|
| Mục đích | Gây tò mò bằng giỏ đồ ăn phủ khăn: bé sờ đoán, rồi gặp banana, apple, milk, egg, rice |
| Mya | Hỏi What's this? khi bé sờ, rồi gọi tên từng món khi bố/mẹ lấy ra, mời bé nói theo |
| Bố/mẹ | Lấy từng món ra khỏi giỏ **trước** khi Mya gọi tên; bóc chuối giả vờ ăn ở câu Yummy |
| Ra khi | Đã lấy ra đủ 4 món và xem bát cơm trên màn hình |

> **Mya:** *(bố/mẹ mang giỏ đồ ăn phủ khăn tới, ngồi cạnh bé)* [vi] Con nhớ cả nhà hươu rồi! [pause 1s] Giờ mình xem trong giỏ có gì nhé.
> **Mya:** *(bố/mẹ để bé thò tay vào dưới khăn sờ quả chuối, chưa lấy ra)* [whisper] Shh… [pause] [ask] What's this? [pause] [vi] Con sờ thử xem nào! [WAIT]
> *(bé: "👉"; bé sờ đoán dưới khăn · sai/im: Mya đọc mẫu «What's this?»)*
> **Mya:** *(bố/mẹ lấy quả chuối ra khỏi giỏ, giơ lên cho bé xem)* [gasp] Look! [pause] A BANANA!
> **Mya:** [cheerful] Banana! [pause] Your turn! [WAIT]
> *(bé: "Ba-na-na!" · sai/im: Mya đọc mẫu «Banana!»)*
> **Mya:** [praise] You said BANANA! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ bóc vỏ chuối, giả vờ cắn một miếng rồi xoa bụng)* [excited] Mmm… YUMMY!
> **Mya:** *(bố/mẹ lấy quả táo ra khỏi giỏ)* [cheerful] And… [pause] APPLE! [pause] Your turn! [WAIT]
> *(bé: "Ép pồ!" · sai/im: Mya đọc mẫu «Apple!»)*
> **Mya:** *(vẫy, `wave`)* [excited] APPLE! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ lấy hộp sữa ra khỏi giỏ)* [gasp] Wo-ow! [pause] MILK! [pause] Your turn! [WAIT]
> *(bé: "Miu!" · sai/im: Mya đọc mẫu «Milk!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Milk! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ lấy quả trứng ra thật nhẹ tay)* [whisper] Shh… [pause] EGG! [pause] Your turn! [WAIT]
> *(bé: "Ét!" · sai/im: Mya đọc mẫu «Egg!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] EGG! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(giỏ không có cơm: bố/mẹ chỉ vào bát cơm trên màn hình)* [cheerful] Look! [pause] RICE! [pause] Yummy rice!

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 🍽️ 🍌 🍎 🥚 🥛 🍚

| | |
|---|---|
| Mục đích | Hiểu tên 5 món bằng cách chạm và đưa, chưa cần nói |
| Mya | Touch the ___! và Give me the ___!, chờ bé làm rồi khen |
| Bố/mẹ | Bày đồ lên đĩa trước mặt bé; chìa tay đón món bé đưa thay Mya; bé chạm sai thì cầm tay bé chạm lại |
| Ra khi | Bé làm đúng ≥ 3 lệnh |

> **Mya:** *(bố/mẹ bày chuối, táo, trứng, sữa lên đĩa trước mặt bé)* [vi] Con gọi tên giỏi quá! [pause 1s] Giờ Mya nói món nào, con chạm vào món đó nhé.
> **Mya:** [cheerful] Touch the BANANA! [WAIT]
> *(bé: "👉"; bé chạm quả chuối · sai/im: Mya đọc mẫu «Touch the BANANA!»)*
> **Mya:** [praise] Banana! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chìa tay đón quả táo thay Mya)* [excited] Give me the APPLE! [pause] [vi] Con đưa táo cho mẹ nhé! [WAIT]
> *(bé: "👉"; bé đưa quả táo cho bố/mẹ · sai/im: Mya đọc mẫu «Give me the APPLE!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Apple! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ nhắc bé chạm thật nhẹ)* [whisper] Touch the EGG! [WAIT]
> *(bé: "👉"; bé chạm nhẹ quả trứng · sai/im: Mya đọc mẫu «Touch the EGG!»)*
> **Mya:** [praise] Egg! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chìa tay đón hộp sữa thay Mya)* [cheerful] Give me the MILK! [WAIT]
> *(bé: "👉"; bé đưa hộp sữa cho bố/mẹ · sai/im: Mya đọc mẫu «Give me the MILK!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Milk! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(giỏ không có cơm: bố/mẹ chỉ cho bé chạm vào bát cơm trên màn hình)* [slow] Touch the RICE! [WAIT]
> *(bé: "👉"; bé chạm bát cơm trên màn hình · sai/im: Mya đọc mẫu «Touch the RICE!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Rice! [pause] Wo-ow! *(chỉ khi bé đúng)*

Bé chạm sai → bố/mẹ cầm tay bé chạm lại, Mya không nói sai. Bé cầm trứng mạnh tay → bố/mẹ đỡ cùng, không mắng.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 🍌 🥛 `hungry.svg` 🍎 🥛

| | |
|---|---|
| Mục đích | Bé đáp Yes/No với Do you like ___?, nói "I like ___", nói "I'm hungry." và thử hỏi lại Mya |
| Mya | Vòng 1: chuối (Yes rồi cả câu). Vòng 2: sữa (Yes rồi cả câu). Vòng 3: I'm hungry, rồi táo. Cuối: đổi vai, bé hỏi Do you like milk? |
| Bố/mẹ | Giơ đúng món lên **trước** khi Mya hỏi; thì thầm mẫu khi bé bí 2 lần liền; xoa bụng làm mẫu ở câu I'm hungry |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

> **Mya:** *(bố/mẹ để chuối, sữa, táo trước mặt bé)* [vi] Con chạm đúng hết rồi! [pause 1s] Giờ Mya hỏi con thích món gì nhé.
> **Mya:** *(trước câu này bố/mẹ giơ quả chuối lên; bé nói No cũng được, cứ gật đầu)* [cheerful] Bananas! [pause] [ask] Do you like bananas? [WAIT]
> *(bé: "Yes!" · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [excited] Yes! [pause] Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] I like BANANAS. [WAIT]
> *(bé: "Ai lai ba-na-na."; bé chỉ vào quả chuối · sai/im: Mya đọc mẫu «I like bananas.»)*
> **Mya:** *(vẫy, `wave`)* [praise] Mmm! I like bananas too! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ hộp sữa lên; bé nói No cũng được, cứ gật đầu)* [ask] Do you like milk? [WAIT]
> *(bé: "Yes!" · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [giggle] Yes! [pause] Mmm… milk! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào hộp sữa)* [cheerful] Your turn! [pause] [slow] I like… [WAIT]
> *(bé: "Ai lai miu." · sai/im: Mya đọc mẫu «I like milk.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said I like milk! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ xoa bụng làm mẫu)* [soft] Mmm… I'm HUNGRY! [pause] [vi] Con xoa bụng nói với Mya nhé! [WAIT]
> *(bé: "Am hăng gri."; bé xoa bụng · sai/im: Mya đọc mẫu «I'm hungry.»)*
> **Mya:** *(vẫy, `wave`)* [giggle] You said I'm hungry! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa quả táo cho bé cầm; bé nói No cũng được, cứ gật đầu)* [cheerful] Apple! [pause] [ask] Do you like apples? [WAIT]
> *(bé: "Yes!" · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [excited] Yes! [pause] Apples! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào quả táo)* [vi] Con nói cả câu nhé: [pause] [slow] I like APPLES. [WAIT]
> *(bé: "Ai lai ép pồ." · sai/im: Mya đọc mẫu «I like apples.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said I like apples! [pause] Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(đổi vai: bé cầm hộp sữa, hỏi Mya; bố/mẹ thì thầm cùng bé nếu bé bí)* [cheerful] Your turn! [pause] [vi] Con hỏi Mya đi: [pause] [slow] "Do you like milk?" [WAIT]
> *(bé: "Đu diu lai miu?" · sai/im: Mya đọc mẫu «Do you like milk?»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Yes! I like milk! [pause] Good job! *(chỉ khi bé đúng)*

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «I like bananas.») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ giơ đúng món khi Mya đọc mẫu. Bé nói "No!" ở câu Do you like ___? là đúng ý bé: bố/mẹ gật đầu, đi tiếp. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🏪 🍌 😋 🥛 🍎 🍽️

| | |
|---|---|
| Mục đích | Xả năng lượng bằng Apples and Bananas và trò tiệm tạp hoá: bé mua, Mya bán, nếm thử thật |
| Mya | Stand up! Let's go!, rồi mời bé mua từng món bằng "___, please!" và trao "Here you are!" |
| Bố/mẹ | Mở Apples and Bananas và bấm Space tạm dừng app lúc hát; bày tiệm trên bàn, đứng sau tiệm trao đồ thay Mya; cho bé nếm miếng nhỏ |
| Ra khi | Hết giờ |

> **Mya:** *(bố/mẹ mở sẵn bài Apples and Bananas trên loa)* [vi] Con nói giỏi quá! [pause 1s] Giờ mình chơi bán hàng: Mya bán, con mua nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở bài Apples and Bananas, bấm Space tạm dừng app, hát và nhảy cùng bé; hát xong bày chuối, sữa, táo lên bàn làm tiệm rồi bấm Space học tiếp)* [cheerful] Stand up! [pause] Let's go!
> **Mya:** *(bé chạy tới tiệm; bố/mẹ đứng sau tiệm bán thay Mya)* [cheerful] Yummy bananas! [pause] [vi] Con mua thì nói: [pause] [slow] Banana, please! [WAIT]
> *(bé: "Ba-na-na, pli!" · sai/im: Mya đọc mẫu «Banana, please!»)*
> **Mya:** *(vẫy, `wave`)* [cheerful] Here you are! [pause] Banana! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa bé một miếng chuối nhỏ để nếm thử)* [ask] Yummy? [WAIT]
> *(bé: "Dăm mi!"; bé nếm chuối · sai/im: Mya đọc mẫu «Yummy!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Yummy! Yummy! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bé nhảy một vòng quanh phòng rồi quay lại tiệm; bé nói xong bố/mẹ đưa hộp sữa)* [excited] Jump, jump! [pause] Come here! [pause] Milk? [WAIT]
> *(bé: "Miu, pli!" · sai/im: Mya đọc mẫu «Milk, please!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Here you are! [pause] Milk! *(chỉ khi bé đúng)*
> **Mya:** *(bé nhảy một vòng nữa rồi quay lại tiệm; bé nói xong bố/mẹ đưa quả táo)* [cheerful] Jump, jump! [pause] Apple? [WAIT]
> *(bé: "Ép pồ, pli!" · sai/im: Mya đọc mẫu «Apple, please!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Here you are! [pause] Apple! Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(bố, mẹ và bé ngồi xuống, cùng nếm miếng táo)* [cheerful] Sit down! [pause] [vi] Cả nhà cùng ăn thử nào!

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 🍌 rồi 🥚

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya gọi sai tên món |
| Mya | Thẻ hiện chuối nhưng nói apple; thẻ hiện trứng nhưng hỏi milk |
| Bố/mẹ | Giơ đúng món thật; nhắc nhỏ: "Mya nói sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya nói sai thì con nhắc Mya nhé)* [vi] Mua bán vui quá! [pause 1s] Giờ con làm cô giáo, dạy Mya nhé.
> **Mya:** *(bố/mẹ giơ quả chuối; thẻ hiện chuối, Mya cố tình gọi là apple)* [cheerful] Look! [pause] APPLE! [pause] Yummy apple! [WAIT]
> *(bé: "No! Ba-na-na!" · sai/im: Mya đọc mẫu «Banana!»)*
> **Mya:** [gasp] Oh no! [pause] BANANA! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ quả trứng; thẻ hiện trứng, Mya cố tình gọi là milk)* [puzzled] And this… [pause] [ask] milk? [WAIT]
> *(bé: "No! Ét!" · sai/im: Mya đọc mẫu «Egg!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] EGG! Egg! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ 😋 rồi `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: ăn miếng chuối, nói "yummy", "bye-bye" |
| Mya | Yummy, chào chuối, khen cụ thể, chào bé |
| Bố/mẹ | Đưa bé miếng chuối, vẫy tay cùng bé, dán sticker |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ đưa bé một miếng chuối)* [vi] Sắp hết giờ rồi! [pause 1s] Mình ăn miếng chuối rồi chào nhau nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Yummy, yummy! [pause] Bye-bye, bananas!
> **Mya:** [vi] Hôm nay con nói được banana, apple, milk, egg và I like bananas. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker, cả nhà ôm bé)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🍎, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói bằng tiếng Việt ("chuối", "sữa") | Công nhận rồi bắc cầu: "Chuối! Banana!" Không bắt nói lại ngay. |
| Bé chỉ nói "banana" thay vì "I like bananas." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Bé nói "No!" ở Do you like ___? | Đúng ý bé, không sửa. "[cheerful] No! Ok!" rồi sang món khác. |
| Bé đòi ăn hết món ngay | Cho một miếng nhỏ, hẹn ăn tiếp sau giờ học. |
| Bé không chịu nếm | Cầm, ngửi là đủ. Không ép ăn. |
| Bé làm rơi hoặc vỡ trứng | "[giggle] Oh no!" rồi bố/mẹ dọn, đi tiếp. Không mắng. |
| Bé chỉ chạm hoặc đưa, chưa nói | Tính là hiểu. "[cheerful] Yes! Banana!" rồi mời bé nói "banana" một lần. |
| Bé kể món khác ("bánh", "kẹo") | Theo bé 1 lượt ("Wow! Yummy!"), rồi quay lại 5 món của buổi. Không dạy thêm. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc hát | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé không hỏi lại được "Do you like milk?" | Tính là bình thường, đây là câu ở mức nghe. Mya đọc mẫu rồi tự trả lời. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé gọi đúng 3 trong 5 món (apple, banana, milk, egg, rice).
2. Bé nói "I like ___" 1 lần.
3. Bé nói "yummy".

**Số đo của buổi 8** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 8 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 10 |
| Từ đích bé dùng | ≥ 3 trong apple, banana, milk, egg |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 25%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Gọi tên apple, banana, milk, egg | | | | |
| I like ___ | | | | |
| Yummy! / I'm hungry. | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Mỗi bữa ăn, gọi tên 1 món bằng tiếng Anh ("Rice!", "Egg!"); bé nói theo hay không đều được.
- Lúc ăn quả, hỏi "Do you like bananas?", bé gật hay nói "yes" là được.
- Xem 1 video bài hát Apples and Bananas, bé chơi bên cạnh, không bắt nghe.
- Bố/mẹ không ép bé lặp, không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 9) ôn bài này bằng trò chạm đồ ăn.

---

## 9. Cho app (thư mục `Resources/Lessons/08-food/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, cùng các file trong `images/`: `hungry.svg`, và `giraffe-family.svg`, `giraffe-mommy.svg`, `giraffe-daddy.svg`, `giraffe-baby.svg` chép từ buổi 7), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 10.
