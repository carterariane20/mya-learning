# Buổi 11 — Toys. It's a ball.

Buổi thứ mười một, mở đầu giai đoạn 2: bé gọi tên 4 đồ chơi (ball, car, doll, teddy), nói "It's a ball." bằng khung cũ với từ mới, và nghe "Where's the car?" thì tìm và chỉ đúng.
File này gom mọi thứ của buổi 11 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/11-toys/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 5, Buổi 11) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–10, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 25% lượt của Mya |
| Từ mới | ball, car, doll, teddy (khung "It's a ___." đã học, không có cấu trúc mới) |
| Sản phẩm cuối buổi | Bé gọi đúng 3/4 đồ chơi, nói "It's a car." (hoặc "car") và tìm đúng khi nghe "Where's the ___?" |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Gọi tên 4 đồ chơi: ball, car, doll, teddy.
- Nói "It's a ball." khi được hỏi "What's this?" (khung cũ, từ mới).
- Nghe "Where's the car?" thì tìm và chỉ đúng; nghe "Give me the ball!" thì đưa đúng món.

Không kỳ vọng: nói cả câu cho cả 4 đồ chơi, phát âm rõ âm cuối ("ball", "doll"), tự hỏi "Where's the car?". Bé chỉ nói "ball" hoặc "a ball" là **đạt**, không sửa. Chặng 5 có một nhịp mời bé nói cả câu, bé vẫn nói một từ thì vẫn tính đạt.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Ball! | Quả bóng | nói | ball, bon, bôn, bo, bol |
| Car! | Ô tô | nói | car, ca, cá, ka, kar |
| Doll! | Búp bê | nói | doll, đon, đol, dol, đo |
| Teddy! | Gấu bông | nói | teddy, té đi, te di, tê đi, teddy bear, bear |
| It's a ball. | Đây là quả bóng. | nói (ôn khung) | it's a ball, its a ball, is a ball, a ball, ball, ít xơ bon, xơ bon, bon |
| It's a car. | Đây là ô tô. | nói (ôn khung) | it's a car, its a car, is a car, a car, car, ít xơ ca, xơ ca, ca |
| It's a doll. | Đây là búp bê. | nói (ôn khung) | it's a doll, its a doll, is a doll, a doll, doll, ít xơ đon, xơ đon, đon |
| It's a teddy. | Đây là gấu bông. | nói (ôn khung) | it's a teddy, its a teddy, is a teddy, a teddy, teddy, teddy bear, ít xơ té đi, té đi |
| Where's the car? | Ô tô đâu? | nghe | where's the car, where the car, where car, que đơ ca |
| Give me the ball! | Đưa bóng cho Mya. | nghe | give me the ball, give ball, ghi mi đơ bon |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** the, give, me, roll, beep, box (và các từ của buổi 1–10: red, blue, color, what's this, jump, touch your nose, hello, bear…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 1 quả bóng (màu đỏ thì tốt), 1 ô tô đồ chơi (màu đỏ thì tốt), 1 búp bê, 1 gấu bông, 1 hộp giấy, 1 khăn to phủ kín hộp, tờ giấy đỏ và tờ giấy xanh dương của buổi 4 (hoặc hai đồ vật màu đỏ, xanh dương), loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Clean Up Song" (Super Simple Songs) ở chặng 6. Bố/mẹ mở trên loa và bấm Space tạm dừng app lúc hát; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (emoji, mỗi thẻ một vật chính):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, Happy!, Bye-bye! | 1, 8 |
| 🎨 | Look!, Red… or blue? (câu nối và lượt hỏi, chưa lộ màu) | 2 |
| 🟥 | Red! | 2 |
| 🟦 | Blue! | 2 |
| 🤸 | Jump! | 2 |
| 👃 | Touch your nose! | 2 |
| 📦 | Look! A box!, Stand up! | 3, 6 |
| `ball` (thẻ của app, bóng đỏ) | It's a ball!, Give me the ball!, Roll the ball!, Ball!, It's a ball. | 3, 4, 5, 6 |
| 🚗 | It's a car!, Where's the car?, It's a car., Red!, Give me the car!, Car! | 3, 4, 5, 6, 7 |
| `doll.svg` (SVG phẳng, búp bê cười) | It's a doll!, Give me the doll!, It's a doll., Doll! | 3, 4, 5, 6, 7 |
| 🧸 | It's a teddy!, Teddy!, Where's the teddy?, It's a teddy., Give me the teddy! | 3, 4, 5, 6, 7 |
| `qmark` (thẻ của app) | Where's the car? (lúc bé giấu ô tô) | 5 |

Đồ chơi thật là chính; thẻ trên màn chỉ nhắc lại món đang nói. Emoji 🪆 là búp bê Nga, không giống búp bê của bé, nên "Doll!" dùng `doll.svg`. Lúc bé giấu ô tô, thẻ là dấu hỏi để Mya "không nhìn thấy"; khi Mya đoán, thẻ trở lại ô tô.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Bỏ 4 đồ chơi vào hộp, phủ khăn, để hộp sau lưng. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm {name}!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 🎨 🟥 🎨 🟦 🤸 👃

| | |
|---|---|
| Mục đích | Ôn 2 thứ cũ: màu (red, blue) và hành động (Jump!, Touch your nose!), không dạy mới |
| Mya | Hỏi What color is it?, rồi ra lệnh nhảy và chạm mũi |
| Bố/mẹ | Giơ đúng tờ giấy màu **trước** khi Mya hỏi; đứng dậy nhảy cùng bé |
| Ra khi | Bé đã trả lời 1 màu và làm 1 động tác, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ lấy sẵn tờ giấy đỏ và tờ giấy xanh dương của buổi 4)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình ôn màu sắc và trò nhảy nhé.
> **Mya:** *(trước câu này bố/mẹ giơ tờ giấy đỏ)* [cheerful] Look! [pause] [ask] What color is it? [WAIT]
> *(bé: "Rét!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** [praise] RED! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ tờ giấy xanh dương)* [ask] Red… or blue? [WAIT]
> *(bé: "Blu!" · sai/im: Mya đọc mẫu «Blue!»)*
> **Mya:** [excited] BLUE! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đứng dậy cùng bé)* [cheerful] Stand up! [pause] JUMP! [pause] [vi] Con nhảy nào! [WAIT]
> *(bé: "👉"; bé nhảy, bố/mẹ nhảy cùng · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** [giggle] Jump, jump! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Touch your NOSE! [WAIT]
> *(bé: "👉"; bé chạm mũi · sai/im: Mya đọc mẫu «Touch your NOSE!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Nose! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 📦 `ball` 🚗 `doll.svg` 🧸

| | |
|---|---|
| Mục đích | Gây tò mò bằng hộp phủ khăn, rồi gặp lần lượt 4 đồ chơi |
| Mya | Thì thầm về cái hộp, gọi tên từng món khi nó lộ ra |
| Bố/mẹ | Đặt hộp phủ khăn trước mặt bé; lấy từng món ra **trước** khi Mya gọi tên |
| Ra khi | Đã gặp đủ 4 đồ chơi |

> **Mya:** *(bố/mẹ đặt hộp phủ khăn trước mặt bé; trong hộp có bóng, ô tô, búp bê, gấu bông)* [vi] Ôn màu xong rồi, con giỏi lắm! [pause 1s] Giờ xem trong hộp có gì nè.
> **Mya:** *(bé kéo khăn ra; bố/mẹ lấy từng món ra khi Mya gọi tên)* [whisper] Shh… [pause] Look! A BOX! [pause] [vi] Con kéo khăn ra nào.
> **Mya:** *(trước câu này bố/mẹ lấy quả bóng ra, giơ lên)* [gasp] Oh! [pause] It's a BALL! [pause] Red ball!
> **Mya:** *(trước câu này bố/mẹ lấy ô tô ra)* [excited] It's a CAR! [pause] Beep, beep!
> **Mya:** *(trước câu này bố/mẹ lấy búp bê ra)* [cheerful] It's a DOLL! [pause] Hello, doll!
> **Mya:** *(trước câu này bố/mẹ lấy gấu bông ra)* [giggle] It's a TEDDY! [pause] Hello, teddy!
> **Mya:** *(bố/mẹ đưa gấu cho bé ôm)* [cheerful] TEDDY! [pause] Your turn! [WAIT]
> *(bé: "Té-đi!" · sai/im: Mya đọc mẫu «Teddy!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said TEDDY! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `ball` 🚗 `doll.svg` 🧸

| | |
|---|---|
| Mục đích | Hiểu Give me the ___!, Roll the ball!, Where's the ___? bằng hành động, chưa cần nói |
| Mya | Nhờ bé đưa, lăn, tìm từng món, chờ rồi khen |
| Bố/mẹ | Bày 4 món trước mặt bé; bé đưa nhầm thì chỉ vào món đúng, không chê; giấu gấu sau gối trước lượt cuối |
| Ra khi | Bé làm đúng ≥ 3 lệnh |

> **Mya:** *(bố/mẹ bày bóng, ô tô, búp bê, gấu trước mặt bé; bé đưa nhầm thì bố/mẹ chỉ vào món đúng, không chê)* [vi] Bốn bạn đồ chơi ra hết rồi! [pause 1s] Giờ Mya nhờ, con làm theo nhé.
> **Mya:** [cheerful] Give me the BALL! [pause] [vi] Con đưa bóng cho Mya nào! [WAIT]
> *(bé: "👉"; bé giơ bóng về phía màn hình (đưa cho Mya) · sai/im: Mya đọc mẫu «Give me the BALL!»)*
> **Mya:** [praise] Ball! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** [excited] Roll the BALL! [pause] [vi] Con lăn bóng sang mẹ nào! [WAIT]
> *(bé: "👉"; bé lăn bóng sang bố/mẹ · sai/im: Mya đọc mẫu «Roll the BALL!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! [pause] Roll, roll! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đặt ô tô xa một chút, lẫn giữa các món khác)* [ask] Where's the CAR? [WAIT]
> *(bé: "👉"; bé chỉ hoặc cầm ô tô · sai/im: Mya đọc mẫu «Where's the CAR?»)*
> **Mya:** [excited] CAR! [pause] Beep, beep! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Give me the DOLL! [WAIT]
> *(bé: "👉"; bé giơ búp bê về phía màn hình · sai/im: Mya đọc mẫu «Give me the DOLL!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Doll! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giấu gấu sau gối, chừa một chân ló ra)* [whisper] Shh… [pause] [ask] Where's the TEDDY? [pause] [vi] Con tìm bạn gấu nào! [WAIT]
> *(bé: "👉"; bé tìm ra gấu · sai/im: Mya đọc mẫu «Where's the TEDDY?»)*
> **Mya:** *(vẫy, `wave`)* [excited] TEDDY! [pause] Wo-ow! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé đưa nhầm → bố/mẹ chỉ vào món đúng rồi cùng đưa, Mya không nói sai. Bé gọi mọi thứ tròn là "ball" → không sửa, chơi tiếp và nói đúng tên món bé đang cầm.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `ball` 🚗 `doll.svg` 🧸 `qmark` 🚗

| | |
|---|---|
| Mục đích | Bé gọi tên 4 đồ chơi, có một nhịp nói cả câu "It's a ball.", rồi chơi giấu đồ cho Mya đoán |
| Mya | Vòng 1: bóng (một từ, rồi mời nói cả câu). Vòng 2: ô tô và màu của nó. Vòng 3: búp bê, gấu. Cuối: bé giấu ô tô, Mya đoán sai |
| Bố/mẹ | Giơ từng món **trước** khi Mya hỏi; thì thầm mẫu khi bé bí 2 lần liền; giúp bé giấu ô tô sau lưng |
| Ra khi | Đủ 4 đồ chơi hoặc hết 11 phút |

> **Mya:** *(bố/mẹ để bốn món trong hộp, giơ từng món trước khi Mya hỏi)* [vi] Con làm theo giỏi quá! [pause 1s] Giờ Mya hỏi, con nói tên đồ chơi nhé.
> **Mya:** *(trước câu này bố/mẹ giơ quả bóng)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Bon!" · sai/im: Mya đọc mẫu «Ball!»)*
> **Mya:** [praise] BALL! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] It's a BALL. [WAIT]
> *(bé: "Ít xơ bon." · sai/im: Mya đọc mẫu «It's a ball.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's a ball! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ ô tô)* [ask] What's this? [WAIT]
> *(bé: "Ca!" · sai/im: Mya đọc mẫu «It's a car.»)*
> **Mya:** [praise] You said CAR! [pause] Beep, beep! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ vào chỗ màu đỏ của ô tô; ô tô không đỏ thì chỉ vào thẻ ô tô đỏ trên màn hình)* [ask] What color is it? [WAIT]
> *(bé: "Rét!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** [praise] RED! [pause] Red car! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ búp bê)* [ask] And this? [WAIT]
> *(bé: "Ít xơ đon." · sai/im: Mya đọc mẫu «It's a doll.»)*
> **Mya:** [excited] DOLL! [pause] It's a doll! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ gấu bông)* [whisper] Shh… [pause] [ask] What's this? [WAIT]
> *(bé: "Té-đi!" · sai/im: Mya đọc mẫu «It's a teddy.»)*
> **Mya:** *(vẫy, `wave`)* [giggle] TEDDY! [pause] Hello, teddy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ đưa ô tô cho bé, giúp bé giấu sau lưng)* [vi] Giờ con giấu ô tô sau lưng nhé! [pause] [ask] Where's the CAR? [WAIT]
> *(bé giấu ô tô sau lưng, cười, không cần nói · Mya chỉ chờ, không đọc mẫu)*
> **Mya:** *(Mya cố tình đoán sai; bố/mẹ nhắc nhỏ bé đưa ô tô ra và nói)* [puzzled] Hmm… [pause] [vi] Mya đoán nhé… [pause] [ask] Is it a DOLL? [WAIT]
> *(bé: "No! Car!" · sai/im: Mya đọc mẫu «It's a car.»)*
> **Mya:** *(vẫy, `wave`)* [giggle] No! It's a CAR! [pause] Beep, beep! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** lượt đầu bé nói "Ball!" là đúng; Mya khen rồi nói mẫu "It's a ball." và mời bé nói cả câu một lần. Từ lượt ô tô trở đi, bé nói "car" hay "It's a car." đều tính đúng.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Ball!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ giơ món đồ đó khi Mya đọc mẫu. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, chơi giấu đồ thêm 1 vòng với búp bê, và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 📦 `ball` 🚗 `doll.svg` 🧸

| | |
|---|---|
| Mục đích | Xả năng lượng bằng bài hát dọn đồ, rồi dọn từng món vào hộp theo lệnh |
| Mya | Ra lệnh Stand up!, rồi Give me the ___! (hộp là "hộp của Mya") |
| Bố/mẹ | Mở Clean Up Song và bấm Space tạm dừng app lúc hát; cầm hộp làm "hộp của Mya"; rải 4 món quanh phòng |
| Ra khi | Hết giờ hoặc 4 món đã vào hộp |

> **Mya:** *(bố/mẹ để hộp giấy rỗng giữa phòng, rải bốn món đồ chơi quanh đó)* [vi] Con nói giỏi quá! [pause 1s] Giờ mình đứng dậy hát và dọn đồ chơi nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở bài Clean Up Song, bấm Space tạm dừng app, hát và nhún cùng bé; hát xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ cầm hộp làm "hộp của Mya")* [excited] Jump, jump! [pause] Give me the BALL! [pause] [vi] Con bỏ bóng vào hộp nhé! [WAIT]
> *(bé: "👉"; bé nhảy tới, nhặt bóng bỏ vào hộp · sai/im: Mya đọc mẫu «Give me the BALL!»)*
> **Mya:** [giggle] Ball! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Beep, beep! [pause] Give me the CAR! [WAIT]
> *(bé: "👉"; bé "lái" ô tô tới hộp, bỏ vào · sai/im: Mya đọc mẫu «Give me the CAR!»)*
> **Mya:** [praise] Car! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [whisper] Shh… [pause] Give me the DOLL! [WAIT]
> *(bé: "👉"; bé bỏ búp bê vào hộp thật nhẹ · sai/im: Mya đọc mẫu «Give me the DOLL!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Doll! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [slow] Give me the TEDDY! [WAIT]
> *(bé: "👉"; bé ôm gấu bỏ vào hộp · sai/im: Mya đọc mẫu «Give me the TEDDY!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! [pause] Teddy! [pause] Thank you! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 🧸 `doll.svg` 🚗

| | |
|---|---|
| Mục đích | Bé nhắc từ cho Mya: Mya "quên" tên đồ chơi (buổi 11–15 dùng quên, chưa dùng gọi sai) |
| Mya | Cầm từng món, bắt đầu "It's a… a…" rồi ngập ngừng chờ bé nhắc |
| Bố/mẹ | Lấy từng món ra khỏi hộp; nhắc nhỏ: "Mya quên rồi, con nhắc Mya đi" |
| Ra khi | Bé nhắc đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ lấy gấu bông ra khỏi hộp; nhắc nhỏ: Mya quên thì con nhắc Mya nhé)* [vi] Dọn xong rồi, gọn quá! [pause 1s] Giờ Mya hay quên lắm, con nhắc Mya nhé.
> **Mya:** *(Mya cố tình quên tên gấu)* [puzzled] It's a… [pause] a… [pause] [vi] Mya quên mất rồi, con nhắc Mya đi! [WAIT]
> *(bé: "Teddy!" · sai/im: Mya đọc mẫu «Teddy!»)*
> **Mya:** [gasp] Oh! [pause] TEDDY! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ lấy búp bê ra)* [puzzled] And this… [pause] It's a… [pause] [ask] a…? [WAIT]
> *(bé: "Đon!" · sai/im: Mya đọc mẫu «Doll!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] DOLL! It's a doll! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ lấy ô tô ra)* [puzzled] Beep, beep… [pause] It's a… [pause] [ask] a…? [WAIT]
> *(bé: "Ca!" · sai/im: Mya đọc mẫu «Car!»)*
> **Mya:** *(vẫy, `wave`)* [excited] CAR! [pause] High five! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, chào từng đồ chơi, nói "bye-bye" |
| Mya | Chào từng món, khen cụ thể, chào bé |
| Bố/mẹ | Giơ từng món khi Mya chào, dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ giơ từng món khi Mya chào)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào các bạn đồ chơi nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, ball! [pause] Bye-bye, car!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, doll! [pause] Bye-bye, teddy!
> **Mya:** [vi] Hôm nay con nói được bóng, ô tô, búp bê, gấu bông. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🚗, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói tên đồ chơi bằng tiếng Việt ("quả bóng") | Công nhận rồi bắc cầu: "Quả bóng! Ball!" Không bắt nói lại ngay. |
| Bé chỉ nói "ball" hoặc "a ball" thay vì "It's a ball." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Bé gọi mọi thứ tròn là "ball" | Không sửa. Chơi tiếp và nói đúng tên món bé đang cầm. |
| Bé đưa nhầm món khi nghe "Give me the ___!" | Bố/mẹ chỉ vào món đúng rồi cùng đưa. Không nói sai. |
| Nhà không có búp bê hoặc ô tô | Dùng món gần giống (thú bông khác, xe bất kỳ), Mya vẫn gọi đúng tên của bài. |
| Ô tô không màu đỏ | Bố/mẹ chỉ vào thẻ ô tô đỏ trên màn hình khi Mya hỏi màu. |
| Bé không muốn giấu ô tô | Bố/mẹ giấu giúp, bé chỉ cười cũng được. Mya vẫn đoán sai rồi đi tiếp. |
| Bé không chịu cất đồ chơi vào hộp | Bố/mẹ cất cùng bé, hoặc để bé "lái" ô tô chở từng món vào hộp. Không ép. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc hát | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé mang đồ chơi khác ra khoe | Theo bé 1 lượt ("Wow!"), rồi quay lại 4 món của bài. Không dạy thêm. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé gọi đúng 3/4 đồ chơi.
2. Bé nói "It's a car." (hoặc "car").
3. Bé tìm đúng khi nghe "Where's the ___?".

**Số đo của buổi 11** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 11 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 10 |
| Từ đích bé dùng | ≥ 3 đồ chơi |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 25%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Gọi tên đồ chơi | | | | |
| It's a ___. | | | | |
| Where's the ___? | | | | |
| Give me the ___! | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Dọn đồ chơi mỗi tối: bố/mẹ nói "Give me the ball!", bé đưa là được, không nói cũng không sao.
- Giấu một món dưới khăn, hỏi "Where's the car?", bé tìm.
- Xem 1 video Clean Up Song, bé chơi bên cạnh, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 12 — Clothes. Put on your hat.) ôn bài này bằng màu của đồ chơi.

---

## 9. Cho app (thư mục `Resources/Lessons/11-toys/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời. Lượt bé để trống (`""`) là lúc bé giấu ô tô: Mya chỉ chờ, không có thang gợi ý.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt bé có `word` là "It's a ___." nhận cả khi bé chỉ nói tên đồ chơi (biến thể ở `target_chunks`).
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, bóng là thẻ `ball` của app, búp bê là `images/doll.svg`, lúc bé giấu ô tô là thẻ `qmark` của app), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 13.
