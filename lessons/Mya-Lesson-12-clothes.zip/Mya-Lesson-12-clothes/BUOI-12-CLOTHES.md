# Buổi 12 — Clothes. Put on your hat.

Buổi thứ mười hai: bé gọi tên 3 món đồ mặc (hat, shoes, shirt), nghe "Put on your hat!" thì làm đúng, mặc đồ cho gấu bông, và tự ra lệnh "Put on your hat!" cho Mya.
File này gom mọi thứ của buổi 12 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/12-clothes/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 5, Buổi 12) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–11, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 22% lượt của Mya |
| Từ mới | hat, shoes, shirt; cụm cố định "Put on your ___!" (khung giống "Touch your ___!") |
| Sản phẩm cuối buổi | Bé làm đúng 3 lệnh "Put on", gọi tên 2/3 món, sửa được lỗi của Mya |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Gọi tên 3 món đồ mặc: hat, shoes, shirt.
- Nghe "Put on your hat!" (shoes, shirt) thì tự mặc vào; nghe "Put the hat on teddy!" thì mặc cho gấu.
- Nói "It's a hat." khi được hỏi "What's this?", và nói "Put on your hat!" để ra lệnh cho Mya.
- Sửa Mya khi Mya đội mũ vào chân: "No! Head!"

Không kỳ vọng: nói cả câu cho cả 3 món, phát âm rõ âm cuối ("shoes", "shirt"), phân biệt "put on" với cởi ra. Bé chỉ nói "hat" hoặc "a hat" là **đạt**, không sửa. Bé hiểu "put on" thành cởi ra thì bố/mẹ làm mẫu 2 lần, không giải thích bằng lời.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Hat! | Mũ | nói | hat, hát, hắt, het, hét, a hat |
| Shoes! | Giày | nói | shoes, shoe, su, sú, shu, sus, suýt |
| Shirt! | Áo | nói | shirt, sớt, sơt, sot, sớ, a shirt |
| It's a hat. | Đây là cái mũ. | nói | it's a hat, its a hat, is a hat, a hat, hat, ít xơ hát, xơ hát, hát |
| It's a shirt. | Đây là cái áo. | nói | it's a shirt, its a shirt, is a shirt, a shirt, shirt, ít xơ sớt, xơ sớt, sớt |
| Put on your hat! | Đội mũ vào. | nghe + làm, chặng 5 bé nói | put on your hat, put on hat, put your hat, put on, hat on, pút on dò hát, pút on hát, hat |
| Put on your shoes! | Xỏ giày vào. | nghe + làm | put on your shoes, put on shoes |
| Put on your shirt! | Mặc áo vào. | nghe + làm | put on your shirt, put on shirt |
| On your head! | Trên đầu. | nghe | on your head, on head |
| Head! | Đầu (bé sửa Mya ở chặng 7) | nói | head, no head, no! head, on your head, on my head, hét, hed, no |
| It's a teddy. | Đây là gấu bông. (ôn buổi 11) | nói | it's a teddy, its a teddy, is a teddy, a teddy, teddy, teddy bear, ít xơ té đi, té đi |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** put, on, my, head, feet, teddy's, now, clap, the (và các từ của buổi 1–11: ball, teddy, red, blue, color, what's this, where's, look, and, hello…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** mũ, đôi giày, áo của bé (áo rộng để mặc ra ngoài áo đang mặc); gấu bông và quả bóng của buổi 11; một cái mũ nhỏ và một cái áo nhỏ cho gấu (không có thì dùng mũ của bé và khăn tay); 1 hộp giấy; loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Put On Your Shoes" (Super Simple Songs) ở chặng 6. Bố/mẹ mở trên loa và bấm Space tạm dừng app lúc hát; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (emoji và 2 hình SVG, mỗi thẻ một vật chính):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| `ball` (thẻ của app, bóng đỏ) | Where's the ball?, Red! | 2 |
| 🧸 | It's a teddy., Put the hat on teddy! | 2, 4 |
| 📦 | Look! | 3 |
| 👒 | It's a hat!, Hat!, Put on your hat!, It's a hat., Put the hat on teddy! | 3, 4, 5, 6, 7 |
| 🤠 | On your head!, On my head! | 3, 4, 7 |
| 👟 | Shoes!, Put on your shoes! | 3, 4, 5, 6, 7 |
| 👕 (áo xanh dương) | It's a shirt!, Put on your shirt!, It's a shirt., Blue!, Put the shirt on teddy!, Shirt! | 3, 4, 5, 6, 7 |
| `teddy-hat.svg` (gấu đội mũ) | On teddy's head!, Hat on teddy! | 4, 6 |
| 🎵 | Stand up! (lúc hát) | 6 |
| `hat-feet.svg` (mũ đặt trên hai bàn chân) | Head! (Mya đội mũ vào chân) | 7 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại món đang nói. Lúc Mya hỏi màu, bố/mẹ chỉ vào cái áo xanh dương trên thẻ, nên áo thật của bé màu gì cũng được. Không có emoji gấu đội mũ hay mũ trên chân, nên hai thẻ đó là hình SVG của bài.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Bỏ mũ, giày, áo của bé vào hộp, để gấu bông và quả bóng gần đó. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `ball` 🧸

| | |
|---|---|
| Mục đích | Ôn 2 thứ cũ: đồ chơi của buổi 11 (Where's the ball?, It's a teddy.) và màu (red), không dạy mới |
| Mya | Hỏi Where's the ball?, hỏi màu của bóng, rồi hỏi What's this? với gấu bông |
| Bố/mẹ | Đặt bóng lẫn giữa vài món; giơ bóng **trước** khi Mya hỏi màu, giơ gấu **trước** khi Mya hỏi What's this? |
| Ra khi | Bé đã tìm bóng và trả lời 1 câu, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ lấy sẵn quả bóng và gấu bông của buổi 11; đặt bóng lẫn giữa vài món khác trong phòng)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình tìm lại đồ chơi hôm trước nhé.
> **Mya:** [ask] Where's the BALL? [WAIT]
> *(bé: "👉"; bé chỉ hoặc cầm quả bóng · sai/im: Mya đọc mẫu «Where's the BALL?»)*
> **Mya:** [excited] BALL! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ quả bóng lên; bóng không đỏ thì chỉ vào thẻ bóng đỏ trên màn hình)* [ask] What color is it? [WAIT]
> *(bé: "Rét!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** [praise] RED! [pause] Red ball! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ gấu bông)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Té-đi!" · sai/im: Mya đọc mẫu «It's a teddy.»)*
> **Mya:** *(vẫy, `wave`)* [giggle] TEDDY! [pause] Hello, teddy! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 📦 👒 🤠 👟 👕 👒

| | |
|---|---|
| Mục đích | Gây tò mò bằng cái hộp, rồi gặp lần lượt mũ, giày, áo |
| Mya | Thì thầm về cái hộp, gọi tên từng món khi nó lộ ra, mời bé nói "Hat!" |
| Bố/mẹ | Đặt hộp trước mặt bé; lấy từng món ra **trước** khi Mya gọi tên; đội mũ lên đầu bé |
| Ra khi | Đã gặp đủ 3 món |

> **Mya:** *(bố/mẹ để sẵn mũ, giày, áo của bé trong hộp, đậy lại, đặt trước mặt bé; gấu bông để cạnh)* [vi] Tìm đồ chơi xong rồi, con giỏi lắm! [pause 1s] Giờ xem mẹ cất gì trong hộp nè.
> **Mya:** *(bé mở hộp; bố/mẹ lấy từng món ra khi Mya gọi tên)* [whisper] Shh… [pause] Look! [pause] [vi] Con mở hộp ra nào.
> **Mya:** *(trước câu này bố/mẹ lấy mũ ra, giơ lên)* [gasp] Oh! [pause] It's a HAT!
> **Mya:** *(bố/mẹ đội mũ lên đầu bé)* [cheerful] Hat, hat! [pause] On your HEAD!
> **Mya:** *(trước câu này bố/mẹ lấy đôi giày ra)* [excited] Look! [pause] SHOES! [pause] Wo-ow!
> **Mya:** *(trước câu này bố/mẹ lấy áo ra)* [cheerful] And… [pause] It's a SHIRT!
> **Mya:** *(bố/mẹ chỉ vào mũ trên đầu bé)* [cheerful] HAT! [pause] Your turn! [WAIT]
> *(bé: "Hát!" · sai/im: Mya đọc mẫu «Hat!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said HAT! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 👒 🤠 👟 👕 🧸 `teddy-hat.svg`

| | |
|---|---|
| Mục đích | Hiểu Put on your ___! và Put the hat on teddy! bằng hành động, chưa cần nói |
| Mya | Ra từng lệnh mặc đồ, chờ rồi khen; cuối cùng nhờ bé đội mũ cho gấu |
| Bố/mẹ | Bày 3 món trước mặt bé; giúp bé xỏ giày, mặc áo; bé làm nhầm thì làm mẫu 2 lần, không chê |
| Ra khi | Bé làm đúng ≥ 3 lệnh |

> **Mya:** *(bố/mẹ cất mũ xuống, bày mũ, giày, áo trước mặt bé; bé làm nhầm hay cởi ra thì bố/mẹ làm mẫu 2 lần, không giải thích)* [vi] Mũ, giày, áo ra hết rồi! [pause 1s] Giờ Mya nói, con mặc vào nhé.
> **Mya:** [cheerful] Put on your HAT! [pause] [vi] Con đội mũ vào nào! [WAIT]
> *(bé: "👉"; bé đội mũ · sai/im: Mya đọc mẫu «Put on your HAT!»)*
> **Mya:** [excited] Wo-ow! [pause] A hat on your head! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Put on your SHOES! [WAIT]
> *(bé: "👉"; bé xỏ giày, bố/mẹ giúp nếu khó · sai/im: Mya đọc mẫu «Put on your SHOES!»)*
> **Mya:** [praise] Shoes! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Put on your SHIRT! [WAIT]
> *(bé: "👉"; bé mặc áo ra ngoài áo đang mặc, bố/mẹ giúp · sai/im: Mya đọc mẫu «Put on your SHIRT!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Shirt! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa bé gấu bông; bé cởi mũ của mình ra)* [giggle] Now teddy! [pause] Put the hat on TEDDY! [WAIT]
> *(bé: "👉"; bé đội mũ cho gấu · sai/im: Mya đọc mẫu «Put the hat on TEDDY!»)*
> **Mya:** *(vẫy, `wave`)* [praise] On teddy's HEAD! [pause] Yes! *(chỉ khi bé đúng)*

Bé cởi ra thay vì mặc vào → bố/mẹ làm mẫu 2 lần, Mya không nói sai. Bé không chịu xỏ giày → bỏ qua, sang lệnh tiếp.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 👒 👟 👕 👒

| | |
|---|---|
| Mục đích | Bé gọi tên 3 món, có một nhịp nói cả câu "It's a hat.", nói màu của áo, rồi tự ra lệnh "Put on your hat!" cho Mya |
| Mya | Vòng 1: mũ (một từ, rồi mời nói cả câu). Vòng 2: giày. Vòng 3: áo và màu của áo. Cuối: bé ra lệnh, Mya làm theo |
| Bố/mẹ | Giơ từng món **trước** khi Mya hỏi; thì thầm mẫu khi bé bí 2 lần liền; thì thầm "Put on your hat!" cho bé nói to |
| Ra khi | Đủ 3 món và 1 lần bé ra lệnh, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ cởi mũ, giày, áo của bé để cạnh; giơ từng món trước khi Mya hỏi)* [vi] Con mặc đồ nhanh quá! [pause 1s] Giờ Mya hỏi, con nói tên nhé.
> **Mya:** *(trước câu này bố/mẹ giơ mũ)* [ask] What's this? [WAIT]
> *(bé: "Hát!" · sai/im: Mya đọc mẫu «Hat!»)*
> **Mya:** [praise] HAT! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] It's a HAT. [WAIT]
> *(bé: "Ít xơ hát." · sai/im: Mya đọc mẫu «It's a hat.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's a hat! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ đôi giày)* [ask] And this? [WAIT]
> *(bé: "Su!" · sai/im: Mya đọc mẫu «Shoes!»)*
> **Mya:** [praise] You said SHOES! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ áo)* [whisper] Shh… [pause] [ask] What's this? [WAIT]
> *(bé: "Ít xơ sớt." · sai/im: Mya đọc mẫu «It's a shirt.»)*
> **Mya:** [excited] SHIRT! [pause] It's a shirt! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ vào cái áo xanh dương trên màn hình; áo thật của bé khác màu cũng không sao)* [cheerful] Look! [pause] [ask] What color is it? [WAIT]
> *(bé: "Blu!" · sai/im: Mya đọc mẫu «Blue!»)*
> **Mya:** [praise] BLUE! [pause] Blue shirt! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ thì thầm mẫu cho bé nói to: Put on your hat!)* [vi] Giờ con ra lệnh cho Mya nhé! [pause] [slow] Put on your HAT! [WAIT]
> *(bé: "Pút on dò hát!" · sai/im: Mya đọc mẫu «Put on your HAT!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] OK! [pause] Hat on! [pause] Thank you! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** lượt đầu bé nói "Hat!" là đúng; Mya khen rồi nói mẫu "It's a hat." và mời bé nói cả câu một lần. Ở lượt áo, bé nói "shirt" hay "It's a shirt." đều tính đúng. Lượt ra lệnh, bé chỉ nói "hat" hay "put on" cũng tính đúng.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Hat!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ giơ món đồ đó khi Mya đọc mẫu. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé ra lệnh cho Mya thêm 1 lần với giày ("Put on your shoes!"), và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 👟 👕 👒 `teddy-hat.svg`

| | |
|---|---|
| Mục đích | Xả năng lượng bằng bài hát, thi xỏ giày, rồi mặc đồ cho gấu |
| Mya | Ra lệnh Stand up!, Put on your shoes!, rồi Put the shirt/hat on teddy! |
| Bố/mẹ | Mở Put On Your Shoes và bấm Space tạm dừng app lúc hát; thi xỏ giày với bé và để bé thắng; giúp bé mặc áo cho gấu |
| Ra khi | Hết giờ hoặc gấu đã có áo và mũ |

> **Mya:** *(bố/mẹ để mũ, giày, áo của bé và gấu bông giữa phòng; thêm một cái áo nhỏ hoặc khăn tay cho gấu)* [vi] Con ra lệnh giỏi quá! [pause 1s] Giờ mình đứng dậy hát và mặc đồ cho gấu nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở bài Put On Your Shoes, bấm Space tạm dừng app, hát và làm động tác cùng bé; hát xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ cũng xỏ giày của mình, thi với bé; để bé thắng)* [excited] Ready? [pause] Put on your SHOES! [pause] [vi] Thi xem ai nhanh hơn nào! [WAIT]
> *(bé: "👉"; bé xỏ giày thật nhanh · sai/im: Mya đọc mẫu «Put on your SHOES!»)*
> **Mya:** [excited] Shoes! [pause] Wo-ow! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa bé cái áo nhỏ của gấu, không có thì dùng khăn tay)* [cheerful] Now teddy! [pause] Put the shirt on TEDDY! [WAIT]
> *(bé: "👉"; bé mặc áo hoặc quàng khăn cho gấu, bố/mẹ giúp · sai/im: Mya đọc mẫu «Put the shirt on TEDDY!»)*
> **Mya:** [giggle] Shirt! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [whisper] Shh… [pause] Put the hat on TEDDY! [WAIT]
> *(bé: "👉"; bé đội mũ cho gấu · sai/im: Mya đọc mẫu «Put the hat on TEDDY!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Hat on teddy! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 👒 `hat-feet.svg` 🤠 👟 👕

| | |
|---|---|
| Mục đích | Bé sửa Mya một lần (Mya đội mũ vào chân) và nhắc từ hai lần (Mya quên tên giày, áo); buổi 11–15 chủ yếu dùng quên |
| Mya | Đội mũ vào chân rồi chờ bé sửa; sau đó bắt đầu "Put on my…", "It's a… a…" rồi ngập ngừng chờ bé nhắc |
| Bố/mẹ | Lắc đầu, chỉ lên đầu khi Mya đội mũ vào chân; giơ giày, áo; nhắc nhỏ: "Mya quên rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa hoặc nhắc đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya làm sai hay quên thì con nhắc Mya nhé)* [vi] Gấu mặc đẹp quá! [pause 1s] Giờ Mya tự mặc, con xem Mya làm đúng không nhé.
> **Mya:** *(Mya cố tình đội mũ vào chân; bố/mẹ lắc đầu, chỉ lên đầu, nhắc nhỏ bé nói: No! Head!)* [cheerful] Put on my hat… [pause] [giggle] On my FEET! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! Head!" · sai/im: Mya đọc mẫu «Head!»)*
> **Mya:** [gasp] Oh! [pause] On my HEAD! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ đôi giày; Mya cố tình quên tên)* [puzzled] Hmm… [pause] Put on my… [pause] [ask] my…? [WAIT]
> *(bé: "Su!" · sai/im: Mya đọc mẫu «Shoes!»)*
> **Mya:** [excited] SHOES! [pause] Put on my shoes! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ áo)* [puzzled] And this… [pause] It's a… [pause] [ask] a…? [WAIT]
> *(bé: "Sớt!" · sai/im: Mya đọc mẫu «Shirt!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] SHIRT! It's a shirt! [pause] High five! *(chỉ khi bé đúng)*

Bé chỉ nói "No!" ở lượt mũ trên chân cũng tính là đã sửa. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, chào từng món đồ, nói "bye-bye" |
| Mya | Chào từng món, khen cụ thể, chào bé |
| Bố/mẹ | Giơ từng món khi Mya chào, dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ giơ từng món khi Mya chào)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào mũ, giày, áo nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, hat! [pause] Bye-bye, shoes!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, shirt! [pause] Bye-bye, teddy!
> **Mya:** [vi] Hôm nay con nói được mũ, giày, áo và tự mặc đồ. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 👕, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói tên đồ bằng tiếng Việt ("cái mũ") | Công nhận rồi bắc cầu: "Cái mũ! Hat!" Không bắt nói lại ngay. |
| Bé chỉ nói "hat" hoặc "a hat" thay vì "It's a hat." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Bé hiểu "put on" là cởi ra | Không sao. Bố/mẹ làm mẫu 2 lần, không giải thích bằng lời. |
| Bé không chịu mặc hoặc xỏ giày | Không ép. Bé chỉ chạm vào món đồ, hoặc mặc cho gấu thay. |
| Nhà không có mũ hoặc áo rộng | Dùng mũ, áo của bố/mẹ; Mya vẫn gọi đúng tên của bài. |
| Không có đồ nhỏ cho gấu | Dùng mũ của bé và khăn tay làm áo cho gấu. |
| Áo thật của bé không màu xanh dương | Bố/mẹ chỉ vào cái áo xanh dương trên màn hình khi Mya hỏi màu. |
| Bé cười mà không sửa khi Mya đội mũ vào chân | Bố/mẹ chỉ lên đầu và nói nhỏ "Head!"; bé chỉ lên đầu cũng được. Mya vẫn khen rồi đi tiếp. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc hát | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé mang đồ khác ra khoe (tất, khăn) | Theo bé 1 lượt ("Wow!"), rồi quay lại 3 món của bài. Không dạy thêm. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé làm đúng 3 lệnh "Put on".
2. Bé gọi đúng 2/3 món (hat, shoes, shirt).
3. Bé sửa được lỗi của Mya ("No! Head!" hoặc nhắc tên món Mya quên).

**Số đo của buổi 12** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 12 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 10 |
| Từ đích bé dùng | ≥ 2 món đồ |
| Câu ≥ 3 từ bé nói ("It's a hat.", "Put on your hat!") | ≥ 1 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 22%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Gọi tên hat, shoes, shirt | | | | |
| Put on your ___! (làm theo) | | | | |
| It's a ___. | | | | |
| Sửa lỗi của Mya | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Mỗi sáng mặc quần áo: bố/mẹ nói "Put on your shirt!", "Put on your shoes!", bé tự làm. Không nói cũng không sao.
- Trước khi ra ngoài, bố/mẹ giơ mũ hỏi "What's this?", bé nói "Hat!" là được.
- Mặc đồ cho gấu bông bằng lệnh "Put the hat on teddy!".
- Nghe bài Put On Your Shoes, bé chơi bên cạnh, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 13 — I have a ball.) ôn bài này bằng đồ mặc và đồ chơi của bé.

---

## 9. Cho app (thư mục `Resources/Lessons/12-clothes/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt bé có `word` là "It's a ___." hay "Put on your hat!" nhận cả khi bé chỉ nói tên món đồ (biến thể ở `target_chunks`); lượt "Head!" nhận cả "No!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, câu ghép "Hello, Bông!", "Bye-bye, Bông!", "Giỏi quá!" và See you next time!
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, bóng là thẻ `ball` của app, gấu đội mũ là `images/teddy-hat.svg`, mũ trên chân là `images/hat-feet.svg`), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 14.
