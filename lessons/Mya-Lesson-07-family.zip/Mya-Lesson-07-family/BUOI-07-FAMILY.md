# Buổi 7 — Family. This is my mommy.

Buổi thứ bảy: bé gọi được mommy, daddy, baby, nói "This is my mommy." khi chỉ vào tranh, và nói "I love you" với bố mẹ.
File này gom mọi thứ của buổi 7 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/07-family/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 7) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–6, bố và mẹ ở nhà cùng bé |
| Tiếng Việt | khoảng 25% lượt của Mya |
| Từ mới | mommy, daddy, baby, This is my mommy., Who's this?, I love you. |
| Sản phẩm cuối buổi | Bé chỉ đúng mommy, daddy, baby khi nghe và nói được "mommy" hoặc "daddy" |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Chỉ đúng mommy, daddy, baby trong tranh khi nghe.
- Nói "mommy", "daddy" (mức 1) hoặc "This is my mommy." (mức 2) khi được hỏi "Who's this?".
- Nói "I love you" khi ôm bố hoặc mẹ, líu cũng được.

Không kỳ vọng: nói trọn câu cho cả bố và mẹ, phát âm rõ "daddy", tự hỏi được "Who's this?". Bé chỉ nói "mommy" hoặc "my mommy" là **đạt**, không sửa.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Mommy! | Mẹ | nói | mommy, mom, mami, ma mi, mom mi |
| Daddy! | Bố | nói | daddy, dad, đét đi, đa đi, đe đi |
| Baby! | Em bé | nói | baby, bây bi, bê bi, bay bi |
| This is my mommy. | Đây là mẹ con. | nói theo mẫu | this is my mommy, this my mommy, my mommy, mommy, đít ít mai mami, mai mami |
| Who's this? | Đây là ai? | nghe | who's this, who this, hu dít, hu dis |
| I love you. | Con yêu mẹ/bố. | nói | i love you, love you, ai lớp diu, lớp diu, ai lâu du |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** or (và các từ của buổi 1–6: touch your, nose, eyes, mouth, ears, hands, where's, jump, you said…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** loa, chỗ trống đủ rộng để bé chạy lại ôm bố mẹ. Không cần ảnh thật: nhà hươu và tranh cả nhà đều là tranh vẽ hiện trên màn hình. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Finger Family" ở chặng 6; "Baby Shark" (bản family) nếu bé còn hứng. Bố/mẹ mở trên loa và bấm Space tạm dừng app lúc hát; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (mỗi thẻ một vật chính, trừ tranh cả nhà):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, Bye-bye! | 1, 8 |
| 👃 👀 `mouth.svg` `ears.svg` 👐 (chép từ buổi 6) | Touch your nose!… Touch your hands!, Nose! | 2 |
| 📖 | Look! | 3 |
| `giraffe-mommy.svg` (SVG phẳng, hươu mẹ có nơ hoa) | Mommy! | 3 |
| `giraffe-daddy.svg` (SVG phẳng, hươu bố đeo nơ cổ) | Daddy!, Who's this?, This is my daddy. | 3, 5, 7 |
| `giraffe-baby.svg` (SVG phẳng, hươu em bé) | Baby! | 3, 7 |
| `giraffe-family.svg` (SVG phẳng, hươu bố, mẹ, em bé đứng cạnh nhau) | Look!, Where's Mommy?, Where's Daddy?, Where's Baby?, Bye-bye! | 4, 8 |
| `family-drawing.svg` (tranh bút sáp con vẽ cả nhà: bố, mẹ, bé) | Look!, Who's this?, Mommy!, This is my mommy., Daddy!, This is my daddy. | 5 |
| ❤️ | I love you! | 5 |
| 🤸 | Stand up! | 6 |
| 🤗 | I love you! | 6 |

Thẻ chỉ có tranh vẽ, không có ảnh thật. Trong tranh nhà hươu và tranh con vẽ, bố đứng bên trái, mẹ ở giữa, bé hoặc em bé bên phải.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Chặng 5 và 6 cần cả bố lẫn mẹ: hẹn trước để cả hai có mặt từ phút 20. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 👃 👀 `mouth.svg` `ears.svg` 👐 👃

| | |
|---|---|
| Mục đích | Ôn 5 bộ phận của buổi 6 bằng trò chạm nhanh (không dạy mới) |
| Mya | Ra lệnh Touch your ___!, cuối cùng hỏi Where's your nose? |
| Bố/mẹ | Đứng cùng bé, chạm cùng bé nếu bé quên; bé chạm sai thì cùng chạm lại, không chê |
| Ra khi | Bé chạm đúng ≥ 3 bộ phận hoặc hết 5 phút |

> **Mya:** *(bố/mẹ đứng dậy cùng bé, chạm cùng bé nếu bé quên)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình chơi lại trò chạm nhanh nhé.
> **Mya:** [cheerful] Touch your NOSE! [WAIT]
> *(bé: "👉"; bé chạm mũi · sai/im: Mya đọc mẫu «Touch your NOSE!»)*
> **Mya:** [praise] Nose! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Touch your EYES! [WAIT]
> *(bé: "👉"; bé chạm mắt · sai/im: Mya đọc mẫu «Touch your EYES!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Eyes! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Touch your MOUTH! [WAIT]
> *(bé: "👉"; bé chạm miệng · sai/im: Mya đọc mẫu «Touch your MOUTH!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Mouth! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [slow] Touch your EARS! [WAIT]
> *(bé: "👉"; bé chạm tai · sai/im: Mya đọc mẫu «Touch your EARS!»)*
> **Mya:** [praise] Ears! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Touch your HANDS! [WAIT]
> *(bé: "👉"; bé chạm hai tay vào nhau · sai/im: Mya đọc mẫu «Touch your HANDS!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Hands! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** [ask] Where's your NOSE? [WAIT]
> *(bé: "Nâu!"; bé chỉ vào mũi · sai/im: Mya đọc mẫu «Nose!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said NOSE! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 📖 `giraffe-mommy.svg` `giraffe-daddy.svg` `giraffe-baby.svg`

| | |
|---|---|
| Mục đích | Gây tò mò bằng "album nhà hươu", gặp mommy, daddy, baby |
| Mya | Giới thiệu mẹ, hỏi Who's this? với bố, thì thầm giới thiệu em bé |
| Bố/mẹ | Ngồi sát bé, chỉ vào từng con hươu trên màn hình **trước** khi Mya hỏi |
| Ra khi | Đã gặp đủ 3 con hươu |

> **Mya:** *(bố/mẹ ngồi sát bé, cùng nhìn màn hình)* [vi] Con nhớ hết rồi, giỏi lắm! [pause 1s] Giờ Mya mở album ảnh nhà hươu cho con xem nhé.
> **Mya:** *(bố/mẹ chỉ vào hươu mẹ trên màn hình)* [gasp] Look! [pause] My MOMMY! [pause] This is my mommy.
> **Mya:** [cheerful] Mommy! [pause] Your turn! [WAIT]
> *(bé: "Mami!" · sai/im: Mya đọc mẫu «Mommy!»)*
> **Mya:** [praise] You said MOMMY! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(hươu bố hiện trên màn hình; bố/mẹ chỉ vào hươu bố)* [ask] Who's this? [pause] Mommy… or daddy… [WAIT]
> *(bé: "Đét đi!" · sai/im: Mya đọc mẫu «Daddy!»)*
> **Mya:** *(vẫy, `wave`)* [excited] DADDY! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] This is my daddy. [pause] My DADDY!
> **Mya:** *(bố/mẹ đặt ngón tay lên môi: suỵt, em bé đang ngủ)* [whisper] Shh… [pause] Look! [pause] BABY!
> **Mya:** [whisper] Baby… [pause] Your turn! [WAIT]
> *(bé: "Bây bi!" · sai/im: Mya đọc mẫu «Baby!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] BABY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `giraffe-family.svg`

| | |
|---|---|
| Mục đích | Hiểu mommy, daddy, baby bằng cách chỉ, chưa cần nói |
| Mya | Hỏi Where's ___? với tranh cả nhà hươu, chờ bé chỉ rồi khen |
| Bố/mẹ | Chỉ mẫu một lần, rồi để bé tự chỉ vào màn hình; bé chỉ sai thì cầm tay bé chỉ lại |
| Ra khi | Bé chỉ đúng ≥ 2 con hươu |

> **Mya:** *(bố/mẹ chỉ mẫu một lần, rồi để bé tự chỉ vào màn hình)* [vi] Con gặp cả nhà hươu rồi! [pause 1s] Giờ Mya gọi ai, con chỉ vào người đó nhé.
> **Mya:** [cheerful] Where's MOMMY? [pause] [vi] Con chỉ hươu mẹ nào! [WAIT]
> *(bé: "👉"; bé chỉ vào hươu mẹ trên màn hình · sai/im: Mya đọc mẫu «Where's MOMMY?»)*
> **Mya:** [praise] Ye-es! Mommy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Where's DADDY? [WAIT]
> *(bé: "👉"; bé chỉ vào hươu bố · sai/im: Mya đọc mẫu «Where's DADDY?»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Daddy! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [whisper] Where's BABY? [WAIT]
> *(bé: "👉"; bé chỉ vào hươu em bé · sai/im: Mya đọc mẫu «Where's BABY?»)*
> **Mya:** *(vẫy, `wave`)* [praise] Baby! [pause] High five! *(chỉ khi bé đúng)*

Bé chỉ sai → bố/mẹ cầm tay bé chỉ lại, Mya không nói sai. Bé lẫn mommy với daddy → đọc chậm hơn, không to hơn.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `family-drawing.svg` ❤️ `giraffe-daddy.svg`

| | |
|---|---|
| Mục đích | Bé trả lời Who's this? với tranh con vẽ cả nhà, nói "This is my mommy.", nói "I love you" và thử hỏi lại Mya |
| Mya | Vòng 1: mẹ (có cả câu). Vòng 2: bố (có cả câu). Vòng 3: I love you. Cuối: đổi vai, bé hỏi Who's this? |
| Bố/mẹ | Chỉ vào từng người trong tranh **trước** khi Mya hỏi; thì thầm mẫu khi bé bí 2 lần liền; mẹ dang tay cho bé ôm ở vòng 3 |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

> **Mya:** *(màn hình hiện tranh bút sáp vẽ cả nhà: mẹ, bố và bé)* [vi] Con chỉ đúng hết rồi! [pause 1s] Giờ mình xem tranh con vẽ cả nhà nhé.
> **Mya:** *(trước câu này bố/mẹ chỉ vào mẹ trong tranh trên màn hình)* [cheerful] Look! [pause] [ask] Who's this? [WAIT]
> *(bé: "Mami!" · sai/im: Mya đọc mẫu «Mommy!»)*
> **Mya:** [praise] MOMMY! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] This is my MOMMY. [WAIT]
> *(bé: "Đít ít mai mami."; bé chỉ vào mẹ trong tranh · sai/im: Mya đọc mẫu «This is my mommy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said this is my mommy! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ chỉ vào bố trong tranh)* [ask] Who's this? [WAIT]
> *(bé: "Đét đi!" · sai/im: Mya đọc mẫu «Daddy!»)*
> **Mya:** [praise] DADDY! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] This is my… [WAIT]
> *(bé: "Đít ít mai đét đi."; bé chỉ vào bố trong tranh · sai/im: Mya đọc mẫu «This is my daddy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said this is my daddy! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(mẹ dang tay cho bé ôm)* [cheerful] I love you, MOMMY! [pause] [vi] Con ôm mẹ và nói với mẹ nhé! [WAIT]
> *(bé: "Ai lớp diu!"; bé ôm mẹ · sai/im: Mya đọc mẫu «I love you!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said I love you! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(đổi vai: bé chỉ vào hươu bố trên màn hình; bố/mẹ thì thầm cùng bé nếu bé bí)* [cheerful] Your turn! [pause] [vi] Con hỏi Mya đi: [pause] [slow] "Who's this?" [WAIT]
> *(bé: "Hu dít?" · sai/im: Mya đọc mẫu «Who's this?»)*
> **Mya:** *(vẫy, `wave`)* [giggle] This is my DADDY! [pause] Good job! *(chỉ khi bé đúng)*

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Mommy!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào người trong tranh khi Mya đọc mẫu. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🤸 🤗

| | |
|---|---|
| Mục đích | Xả năng lượng bằng Finger Family và trò nhảy lại ôm bố mẹ, nói "I love you" |
| Mya | Stand up!, rồi Jump, jump! và rủ bé chạy lại ôm mẹ, ôm bố |
| Bố/mẹ | Mở Finger Family và bấm Space tạm dừng app lúc hát; bố và mẹ đứng hai đầu phòng, dang tay đón bé |
| Ra khi | Hết giờ |

> **Mya:** *(bố và mẹ cùng vào chơi; mở sẵn bài Finger Family trên loa)* [vi] Con giới thiệu giỏi quá! [pause 1s] Giờ mình đứng dậy hát và ôm nhau nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở bài Finger Family, bấm Space tạm dừng app, hát và giơ từng ngón cùng bé; hát xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(mẹ dang tay đón bé)* [excited] Jump, jump! [pause] [vi] Chạy lại ôm mẹ, nói với mẹ nhé! [WAIT]
> *(bé: "Ai lớp diu!"; bé nhảy tới ôm mẹ · sai/im: Mya đọc mẫu «I love you!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! [pause] I love you! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố dang tay đón bé)* [excited] Jump, jump! [pause] [vi] Giờ chạy lại ôm bố nào! [WAIT]
> *(bé: "Ai lớp diu, đét đi!"; bé nhảy tới ôm bố · sai/im: Mya đọc mẫu «I love you!»)*
> **Mya:** *(vẫy, `wave`)* [praise] I love you, DADDY! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố, mẹ và bé ngồi xuống ôm nhau)* [cheerful] Sit down! [pause] [vi] Cả nhà ôm nhau thật chặt nào!

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `giraffe-daddy.svg` rồi `giraffe-baby.svg`

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya gọi sai người trong nhà hươu |
| Mya | Thẻ hiện hươu bố nhưng nói mommy; thẻ hiện em bé nhưng hỏi daddy |
| Bố/mẹ | Nhắc nhỏ: "Mya nói sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya nói sai thì con nhắc Mya nhé)* [vi] Ôm nhau vui quá! [pause 1s] Giờ con làm cô giáo, dạy Mya nhé.
> **Mya:** *(thẻ hiện hươu bố, Mya cố tình gọi là mommy)* [cheerful] Look! [pause] This is my MOMMY! [WAIT]
> *(bé: "No! Đét đi!" · sai/im: Mya đọc mẫu «Daddy!»)*
> **Mya:** [gasp] Oh no! [pause] DADDY! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(thẻ hiện hươu em bé, Mya cố tình gọi là daddy)* [puzzled] And this… [pause] [ask] daddy? [WAIT]
> *(bé: "No! Bây bi!" · sai/im: Mya đọc mẫu «Baby!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] BABY! Baby! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `giraffe-family.svg` rồi `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, chào từng người nhà hươu, nói "bye-bye", ôm |
| Mya | Chào từng con hươu, khen cụ thể, chào bé |
| Bố/mẹ | Vẫy tay cùng bé, dán sticker, cả nhà ôm bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ vẫy tay cùng bé)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào cả nhà hươu nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, Mommy! [pause] Bye-bye, Daddy!
> **Mya:** *(vẫy, `wave`)* [whisper] Bye-bye, baby…
> **Mya:** [vi] Hôm nay con nói được mommy, daddy, baby và I love you. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker, cả nhà ôm bé)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker ❤️, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói bằng tiếng Việt ("mẹ", "bố") | Công nhận rồi bắc cầu: "Mẹ! Mommy!" Không bắt nói lại ngay. |
| Bé chỉ nói "mommy" hoặc "my mommy" thay vì "This is my mommy." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Bé lẫn mommy với daddy | Nói chậm hơn, không to hơn; bố/mẹ chỉ vào đúng người. Không nói sai. |
| Bé chỉ chỉ tay, chưa nói | Tính là hiểu. "[cheerful] Yes! Mommy!" rồi mời bé nói "mommy" một lần. |
| Bé ngại nói "I love you" | Ôm là đủ. Bố/mẹ nói "I love you" trước, bé nói theo hay không đều được. |
| Bé đòi xem ảnh thật trong điện thoại | Bố/mẹ hẹn xem sau giờ học; trong giờ chỉ dùng tranh trên màn hình. |
| Bé kể người khác trong nhà ("chị", "anh") | Theo bé 1 lượt ("Wow!"), rồi quay lại mommy, daddy, baby. Không dạy thêm. |
| Bé bảo tranh không giống nhà mình | "[giggle] Wo-ow!" rồi đi tiếp; đây là tranh vẽ chơi, không cần giống. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc hát | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé không hỏi lại được "Who's this?" | Tính là bình thường, đây là câu ở mức nghe. Mya đọc mẫu rồi tự trả lời. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé chỉ đúng mommy, daddy, baby khi nghe.
2. Bé nói "mommy" hoặc "daddy" khi được hỏi.
3. Bé nói "I love you" (líu cũng được).

**Số đo của buổi 7** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 7 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 9 |
| Từ đích bé dùng | ≥ 2 trong mommy, daddy, baby |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 25%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Chỉ đúng mommy, daddy, baby | | | | |
| Gọi mommy, daddy | | | | |
| This is my ___ | | | | |
| I love you | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Mỗi tối trước khi ngủ, bé nói "I love you" với bố và mẹ; bé chỉ ôm cũng được.
- Lúc ăn cơm, chỉ vào từng người và hỏi "Who's this?", bé nói "mommy", "daddy" là được.
- Xem 1 video bài hát Finger Family, bé chơi bên cạnh, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 8) ôn bài này bằng tranh cả nhà hươu.

---

## 9. Cho app (thư mục `Resources/Lessons/07-family/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, cùng các file trong `images/`: `giraffe-mommy.svg`, `giraffe-daddy.svg`, `giraffe-baby.svg`, `giraffe-family.svg`, `family-drawing.svg`, và `mouth.svg`, `ears.svg` chép từ buổi 6), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 9.
