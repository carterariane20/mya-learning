# Buổi 18 — Zoo animals.

Buổi thứ mười tám: bé "đi sở thú" bằng ống nhòm giấy, nghe tiếng gầm rồi gặp sư tử, gọi tên lion, elephant, monkey, tiger, chạy tới đúng con thú Mya gọi, đi như voi, nhảy như khỉ, bò như hổ, nói "It's big!" và "I like monkeys.", trấn an Mya đang sợ hổ bằng "It's ok!", và sửa khi Mya gọi nhầm tên hay nói sai to/nhỏ.
File này gom mọi thứ của buổi 18 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/18-zoo/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 18) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–17, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 20% lượt của Mya |
| Từ mới | 4 từ: lion, elephant, monkey, tiger; không có cấu trúc mới ("It's big!", "I like ___" là khung đã học) |
| Sản phẩm cuối buổi | Bé gọi đúng 3/4 con thú, nói "It's big!" khi được hỏi, nói "I like monkeys." ít nhất 1 lần |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Gọi tên lion, elephant, monkey, tiger khi bố/mẹ giơ con thú (hoặc khi nhìn thẻ trên màn hình).
- Nghe "Run to the elephant!" thì chạy tới đúng con thú; làm theo "Walk like an elephant!", "Jump like a monkey!", "Crawl like a tiger!".
- Nói "It's big!" khi Mya hỏi "Big… or small?" về con voi.
- Nói "I like monkeys." một lần (nói theo mẫu cũng được) và gầm "Roar!" như sư tử.
- Trấn an Mya bằng "It's ok!".
- Vẫn trả lời "Where's the ball?" bằng "In the box." / "Under the box." và "What color is it?" bằng "Red!" (ôn buổi 17 và buổi 4).
- Sửa Mya khi Mya gọi hổ là mèo, hoặc nói voi nhỏ.

Không kỳ vọng: nói đúng số nhiều "monkeys", phát âm rõ "elephant". Bé gọi tất cả là "cat" hay "dog" là bình thường; không sửa, chỉ nói đúng tên con thú bé đang cầm. Bé chỉ nói "Big!" là **đạt**; Mya chỉ mời bé nói cả câu "I like monkeys." một lần.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Lion! | Sư tử | nói | lion, a lion, it's a lion, no lion, lai ơn, lai ần, lion roar |
| Elephant! | Con voi | nói | elephant, an elephant, it's an elephant, a elephant, ê lơ phần, ê lê phăn, elephan |
| Monkey! | Con khỉ | nói | monkey, a monkey, it's a monkey, monkeys, măng ki, mon ky |
| Tiger! | Con hổ | nói | tiger, a tiger, it's a tiger, no tiger, tai gơ, tai gờ |
| It's big! | Nó to! (ôn khung buổi 15) | nói | it's big, it is big, big, no big, big elephant, ít bích, bích |
| I like monkeys. | Con thích khỉ. (ôn khung buổi 4–5) | nói | i like monkeys, i like monkey, like monkeys, i like, ai lai măng ki, ai lai khỉ |
| Roar! | Gầm! | nói | roar, roar roar, ro, rô, grr, gừ, ro ao |
| It's ok! | Không sao đâu! (trấn an Mya) | nói | it's ok, it is ok, ok, okay, it's okay, ít ô kê, ô kê |
| Bye-bye, lion! | Tạm biệt sư tử! | nói | bye-bye lion, bye bye lion, bye-bye, bye bye, bai bai lai ơn, bai bai |
| Run to the elephant! / Run to the monkey! / Run to the tiger! | Chạy tới con voi / con khỉ / con hổ | nghe + làm | run to the elephant / run to the monkey / run to the tiger |
| Walk like an elephant! / Jump like a monkey! / Crawl like a tiger! | Đi như voi / Nhảy như khỉ / Bò như hổ | nghe + làm | walk like an elephant / jump like a monkey / crawl like a tiger |
| Do you like monkeys? → Yes! | Con thích khỉ không? → Có! | nói | yes, yes i like, i like monkeys, dét, yes yes |
| Is it a cat? → No! | Có phải mèo không? → Không! | nói | no, no no, no cat, not cat, lion, nô |
| In the box. / Under the box. | Ở trong hộp / Ở dưới hộp (ôn buổi 17) | nói | in the box, in, in box, in đờ bóc / under the box, under, under box, ăn đơ đờ bóc, ăn đơ |
| Red! | Màu đỏ (ôn buổi 4) | nói | red, it's red, red ball, rét, ret, đỏ |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** big, small, run, to, walk, crawl, jump, like, an, a, the, is, it, ok, cat, meow, ooh-ooh-ah-ah (tiếng khỉ), peekaboo, now, or, ball, box (và các từ của buổi 1–17: what's this, what color is it, red, where's, in, under, said, clap, shh, hmm, do you like…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 4 con thú đồ chơi (sư tử, voi, khỉ, hổ; không có thì in ảnh dán lên bìa cứng); 1 ống nhòm giấy (hai lõi giấy vệ sinh dán cạnh nhau); 1 tấm khăn làm "cửa sở thú"; 1 tấm thảm làm "rừng"; 1 quả bóng và 1 cái hộp có nắp (của buổi 17); loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Walking in the Jungle" (Super Simple Songs), mở ở chặng 6. Bố/mẹ bấm Space tạm dừng app, mở bài trên loa, cùng bé đi quanh thảm; app không phát bài hát. "Let's Go to the Zoo" để nghe ở nhà.
**Thẻ tranh trên màn hình** (emoji, thẻ `wave` và `ball` của app, 2 hình SVG chép từ buổi 17; bài này không vẽ hình mới):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| `ball-in-box.svg` (hộp mở, bóng nằm trong, của buổi 17) | In the box. | 1 |
| `ball-under-box.svg` (hộp úp kênh một mép, bóng lộ ra bên dưới, của buổi 17) | Under the box. | 2 |
| `ball` (quả bóng đỏ, thẻ của app) | Red! | 2 |
| 🚪 (cửa sở thú, tiếng gầm ở phía sau) | Listen!, No! | 3 |
| 🦁 | Lion!, Roar!, Bye-bye, lion! | 3, 5, 6, 8 |
| 🐘 | Elephant!, Walk, walk!, It's big! | 4, 5, 7 |
| 🐒 | Monkey!, Yes!, I like monkeys., Jump! | 4, 5, 6 |
| 🐯 | Tiger!, Crawl!, It's ok! | 4, 5, 6, 7 |
| 🎵 | Stand up! (lúc hát) | 6 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại con thú bố/mẹ đang giơ.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Để 4 con thú, ống nhòm, khăn, bóng và hộp cạnh mình, ngoài tầm tay bé. Dọn một khoảng trống, trải thảm cho bé chạy và bò. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` `ball-in-box.svg`

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you?, và ôn nhanh "In the box." của buổi 17 (30 giây) |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi hỏi Where's the ball? khi bóng nằm trong hộp |
| Bố/mẹ | Vẫy tay cùng bé; bỏ bóng vào hộp **trước** câu Where's the ball? |
| Ra khi | Bé đã chào hoặc trả lời, và nói (hoặc nói theo) "In the box." |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ bỏ quả bóng vào hộp ngay trước mắt bé, để mở nắp)* [ask] Where's the BALL? [WAIT]
> *(bé: "In đờ bóc!" · sai/im: Mya đọc mẫu «In the box.»)*
> **Mya:** [praise] IN the box! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `ball-under-box.svg` `ball`

| | |
|---|---|
| Mục đích | Ôn hai thứ cũ: giấu bóng rồi tìm, nói vị trí (buổi 17), và màu của quả bóng (buổi 4), không dạy mới |
| Mya | Hỏi Where's the ball? khi bóng ở dưới hộp, rồi What color is it? |
| Bố/mẹ | Giấu bóng lúc bé nhắm mắt; lấy bóng ra giơ lên **trước** câu What color is it? |
| Ra khi | Bé đã trả lời 2 câu, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ bảo bé nhắm mắt, lấy bóng ra, úp hộp xuống giấu bóng bên dưới, nhấc một mép cho lộ chút bóng; xong bảo bé mở mắt)* [vi] Bóng trốn trong hộp, đúng rồi! [pause 1s] Giờ mình chơi trốn tìm và đoán màu nhé.
> **Mya:** *(bố/mẹ chỉ vào cái hộp úp)* [whisper] Shh… [pause] [ask] Where's the ball? [WAIT]
> *(bé: "Ăn-đơ đờ bóc." · sai/im: Mya đọc mẫu «Under the box.»)*
> **Mya:** [praise] You said under the box! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ lấy bóng ra giơ lên; bóng nhà mình không màu đỏ thì chỉ vào quả bóng đỏ trên màn hình)* [cheerful] Look! [pause] [ask] What color is it? [WAIT]
> *(bé: "Rét!" · sai/im: Mya đọc mẫu «Red!»)*
> **Mya:** [praise] RED! [pause] Red ball! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 🚪 🦁

| | |
|---|---|
| Mục đích | Gây tò mò: "đi sở thú", nghe tiếng gầm sau cánh cửa, đoán, rồi gặp sư tử |
| Mya | Thì thầm "Listen…", gầm, hỏi "Is it a cat?", mở cửa "Peekaboo! It's a lion!", mời bé nói "Lion!" và gầm "Roar!" |
| Bố/mẹ | Giấu sư tử sau tấm khăn **trước** chặng; kéo khăn ra đúng lúc "Peekaboo!"; làm vuốt sư tử, gầm cùng bé |
| Ra khi | Bé nói (hoặc nói theo) "Lion!" và "Roar!" |

> **Mya:** *(bố/mẹ đưa bé ống nhòm giấy; giấu con sư tử đồ chơi sau một tấm khăn làm cửa sở thú)* [vi] Bóng màu đỏ, con nhớ giỏi lắm! [pause 1s] Giờ mình cầm ống nhòm đi sở thú nhé!
> **Mya:** *(bố/mẹ đưa tay lên tai, làm mặt ngạc nhiên)* [whisper] Shh… [pause] Listen… [pause 1s] [gasp] ROAR!
> **Mya:** *(bố/mẹ lắc đầu cùng bé)* [puzzled] Hmm… [pause] [ask] Is it a CAT? [WAIT]
> *(bé: "No!" · sai/im: Mya đọc mẫu «No!»)*
> **Mya:** *(bố/mẹ kéo khăn ra đúng lúc Mya nói Peekaboo!, giơ con sư tử)* [gasp] Peekaboo! [pause] It's a LION!
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] Lion! [WAIT]
> *(bé: "Lai-ơn!" · sai/im: Mya đọc mẫu «Lion!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said lion! [pause] It's BIG! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ hai tay làm vuốt sư tử, gầm cùng bé)* [excited] ROAR! [pause] [vi] Con gầm như sư tử nào! [WAIT]
> *(bé: "Ro-ao!" · sai/im: Mya đọc mẫu «ROAR!»)*
> **Mya:** [giggle] Big ROAR! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 🐘 🐒 🐯

| | |
|---|---|
| Mục đích | Hiểu tên ba con thú mới bằng tai và chân: nghe tên thì chạy tới đúng con; đi như voi; chưa cần nói |
| Mya | "Run to the elephant!", "Run to the monkey!", "Run to the tiger!", "Walk like an elephant!" |
| Bố/mẹ | Đặt 3 con thú ở 3 góc thảm **trước** chặng; chỉ con thú trên màn hình khi bé bí; làm mẫu đi như voi |
| Ra khi | Bé chạy đúng ≥ 2 trong 3 con |

> **Mya:** *(bố/mẹ đặt voi, khỉ, hổ đồ chơi ở ba góc thảm, cách chỗ bé vài bước; sư tử để cạnh mình)* [vi] Sư tử gầm to quá! [pause 1s] Giờ Mya gọi bạn thú nào, con chạy tới bạn đó nhé.
> **Mya:** *(bố/mẹ chỉ con voi trên màn hình rồi chỉ con voi đồ chơi)* [cheerful] Look! An ELEPHANT! [pause] Run to the elephant! [WAIT]
> *(bé: "👉"; bé chạy tới con voi · sai/im: Mya đọc mẫu «Elephant!»)*
> **Mya:** [excited] Yes! [pause] ELEPHANT! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bé về chỗ ngồi; bố/mẹ gãi đầu làm khỉ)* [giggle] Ooh-ooh-ah-ah! [pause] MONKEY! [pause] Run to the monkey! [WAIT]
> *(bé: "👉"; bé chạy tới con khỉ · sai/im: Mya đọc mẫu «Monkey!»)*
> **Mya:** [praise] Yes! Monkey! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bé về chỗ ngồi)* [whisper] Shh… [pause] TIGER! [pause] Run to the tiger! [WAIT]
> *(bé: "👉"; bé chạy tới con hổ · sai/im: Mya đọc mẫu «Tiger!»)*
> **Mya:** [excited] Wo-ow! [pause] TIGER! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đứng dậy, buông một tay làm vòi voi, bước nặng dậm dậm làm mẫu)* [cheerful] Now… [pause] walk like an ELEPHANT! [pause] [vi] Con bước thật nặng nhé! [WAIT]
> *(bé: "👉"; bé bước nặng như voi · sai/im: Mya đọc mẫu «Walk, walk!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! [pause] BIG elephant! [pause] High five! *(chỉ khi bé đúng)*

Bé chạy nhầm con → không sao, bố/mẹ dắt bé tới đúng con, chỉ vào thẻ trên màn hình, Mya vẫn khen. Bé thích chạy → cho chạy tới cả sư tử thêm một lần rồi mới sang "Walk like an elephant!".

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 🐘 🐒 🐯 🦁

| | |
|---|---|
| Mục đích | Bé gọi tên bốn con thú, nói "It's big!" về con voi, trả lời "Do you like monkeys?" và nói cả câu "I like monkeys." một lần |
| Mya | Vòng 1: voi (tên, rồi to hay nhỏ). Vòng 2: khỉ (tên, thích không, cả câu). Vòng 3: hổ. Vòng 4: sư tử |
| Bố/mẹ | Giơ từng con thú **trước** mỗi câu hỏi; chỉ vào con thú khi bé bí; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 4 vòng, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ gom bốn con thú để sau lưng, giơ từng con trước câu hỏi; thì thầm mẫu khi bé bí 2 lần liền)* [vi] Con chạy giỏi quá! [pause 1s] Giờ Mya giơ bạn thú, con nói tên bạn ấy nhé.
> **Mya:** *(bố/mẹ giơ con voi)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Ê-lơ-phần!" · sai/im: Mya đọc mẫu «Elephant!»)*
> **Mya:** [praise] You said elephant! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ cao con voi, dang rộng hai tay)* [puzzled] Hmm… [pause] Big… or small? [WAIT]
> *(bé: "Ít bích!" · sai/im: Mya đọc mẫu «It's big!»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's big! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ cất voi, giơ con khỉ)* [cheerful] Now… [pause] [ask] What's this? [WAIT]
> *(bé: "Măng-ki!" · sai/im: Mya đọc mẫu «Monkey!»)*
> **Mya:** [giggle] MONKEY! [pause] Ooh-ooh-ah-ah! *(chỉ khi bé đúng)*
> **Mya:** [ask] Do you like monkeys? [WAIT]
> *(bé: "Yes!" · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [giggle] Yes! [pause] I like monkeys! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] I like monkeys. [WAIT]
> *(bé: "Ai lai măng-ki." · sai/im: Mya đọc mẫu «I like monkeys.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said I like monkeys! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ cất khỉ, giơ con hổ thật chậm)* [whisper] Shh… [pause] [ask] What's this? [WAIT]
> *(bé: "Tai-gơ!" · sai/im: Mya đọc mẫu «Tiger!»)*
> **Mya:** [gasp] A TIGER! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ cất hổ, giơ con sư tử)* [ask] What's this? [WAIT]
> *(bé: "Lai-ơn!" · sai/im: Mya đọc mẫu «Lion!»)*
> **Mya:** *(vẫy, `wave`)* [excited] LION! [pause] It's BIG! [pause] Roar! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** bé nói "Big!" là đúng; bé nói "Yes!" hay "I like!" là đúng. Mya khen rồi đọc mẫu "I like monkeys." và mời bé nói cả câu một lần. Bé nói "I like monkey." cũng tính đúng. Không bắt bé nói lại cho đủ "s".

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Elephant!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào con thú khi Mya đọc mẫu. Bé gọi mọi con là "cat" hay "dog" → không sửa bằng lời; bố/mẹ chỉ vào con thú, nói nhỏ tên đúng một lần rồi đi tiếp. Bé trả lời "No!" ở câu Do you like monkeys? → cũng được, bố/mẹ gật đầu, Mya vẫn nói "I like monkeys!". Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự giơ con thú hỏi Mya "What's this?", bố/mẹ đáp thay Mya, và bỏ chặng 7. **Bé ngơ:** chỉ làm vòng 1 và vòng 2 (voi và khỉ).

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 🐒 🦁 🐯

| | |
|---|---|
| Mục đích | Xả năng lượng: đi trong "rừng" theo bài hát, gặp thú thì làm dáng: nhảy như khỉ, gầm như sư tử, bò như hổ |
| Mya | Stand up!, Jump like a monkey!, gầm cùng sư tử, Crawl like a tiger! |
| Bố/mẹ | Bấm Space tạm dừng app lúc hát; đi cùng bé, làm mẫu từng dáng **trước** khi bé làm |
| Ra khi | Hết giờ hoặc bé đã làm đủ 3 dáng |

> **Mya:** *(bố/mẹ trải thảm làm rừng, đặt khỉ, sư tử, hổ quanh thảm)* [vi] Con nói tên bạn thú giỏi quá! [pause 1s] Giờ mình đứng dậy, đi vào rừng nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, mở bài "Walking in the Jungle" (Super Simple Songs), cùng bé đi quanh thảm; hết bài bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ chỉ con khỉ, nhảy và gãi đầu làm mẫu)* [giggle] A MONKEY! [pause] Jump like a monkey! [WAIT]
> *(bé: "👉"; bé nhảy, gãi đầu như khỉ · sai/im: Mya đọc mẫu «Jump!»)*
> **Mya:** [excited] Ooh-ooh-ah-ah! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ con sư tử, giơ hai tay làm vuốt)* [excited] A LION! [pause] [vi] Con gầm thật to nào! [WAIT]
> *(bé: "Ro-ao!" · sai/im: Mya đọc mẫu «ROAR!»)*
> **Mya:** [praise] ROAR! [pause] Big lion! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ bò rón rén làm mẫu)* [whisper] Shh… [pause] A TIGER! [pause] Crawl like a tiger! [WAIT]
> *(bé: "👉"; bé bò rón rén như hổ · sai/im: Mya đọc mẫu «Crawl!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! [pause] Big tiger! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 🐯 🐘

| | |
|---|---|
| Mục đích | Bé sửa Mya hai lần (gọi hổ là mèo, nói voi nhỏ) và trấn an Mya đang sợ hổ bằng "It's ok!" |
| Mya | Nói nhầm rồi chờ bé sửa; giả vờ sợ hổ |
| Bố/mẹ | Giơ đúng con thú **trước** mỗi câu; lắc đầu, chỉ vào con thú, nhắc: "Mya nói nhầm rồi, con sửa Mya đi"; nhắc bé nói "It's ok!" nếu bé bí |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ giơ con hổ; nhắc nhỏ: Mya nói nhầm thì con sửa Mya nhé)* [vi] Đi rừng vui quá! [pause 1s] Giờ Mya nói, Mya nói nhầm thì con sửa nhé.
> **Mya:** *(Mya cố tình nói nhầm; bố/mẹ lắc đầu, chỉ vào con hổ)* [cheerful] Look! [pause] A CAT! [pause] Meow! [WAIT]
> *(bé: "No! Tai-gơ!" · sai/im: Mya đọc mẫu «Tiger!»)*
> **Mya:** [gasp] Oh! [pause] A TIGER! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đặt con hổ xuống, cùng bé vỗ về Mya)* [soft] Oh no… [pause] Tiger… [pause] [vi] Mya sợ quá! Con nói It's ok giúp Mya nhé! [WAIT]
> *(bé: "Ít ô-kê!" · sai/im: Mya đọc mẫu «It's ok!»)*
> **Mya:** [giggle] It's ok! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ cao con voi; Mya cố tình nói nhầm)* [puzzled] Hmm… [pause] The elephant is SMALL! [WAIT]
> *(bé: "No! Ít bích!" · sai/im: Mya đọc mẫu «It's big!»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh! [pause] It's BIG! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé nói "No! Tiger!" hay "No big!" là đã sửa; chỉ nói "No!" thì app đọc mẫu tên đúng («Tiger!», «It's big!»), bố/mẹ chỉ vào con thú. Bé sợ hổ theo Mya → bố/mẹ ôm bé, vuốt con hổ đồ chơi: "Hổ đồ chơi thôi, không sao!". Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ 🦁 `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: chào sư tử, gầm lần cuối, nói "bye-bye" |
| Mya | "Bye-bye, lion!", khen cụ thể, chào bé |
| Bố/mẹ | Giơ sư tử; vẫy tay cùng bé; dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ xếp bốn con thú thành hàng, giơ con sư tử)* [vi] Con dạy Mya giỏi quá! [pause 1s] Sắp hết giờ rồi, mình chào các bạn thú nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, lion! [pause] Your turn! [WAIT]
> *(bé: "Bai-bai, lai-ơn!" · sai/im: Mya đọc mẫu «Bye-bye, lion!»)*
> **Mya:** *(vẫy, `wave`)* [excited] ROAR! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [vi] Hôm nay con nói được tên bốn bạn thú. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🦁, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé gọi mọi con là "cat" hay "dog" | Bình thường. Không sửa bằng lời; bố/mẹ chỉ vào con thú, nói nhỏ tên đúng một lần rồi đi tiếp. |
| Bé chỉ nói "Big!" | Tính là đúng. Mya nói lại "It's big!" 1 lần rồi đi tiếp. |
| Bé nói bằng tiếng Việt ("con voi") | Công nhận rồi bắc cầu: "Con voi! Elephant!" Không bắt nói lại ngay. |
| Nhà không có thú đồ chơi | In 4 ảnh con thú dán lên bìa cứng, hoặc chỉ vào thẻ trên màn hình. |
| Bé sợ tiếng gầm | Bố/mẹ ôm bé, gầm thật nhỏ, cười. Bỏ "Roar!" to, chỉ làm vuốt bằng tay. |
| Bé giữ khư khư một con thú | Chơi cùng 1 lượt ("Monkey! Wow!"), rồi bố/mẹ đổi con khác cho bé. Không giằng lấy. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc chạy tới thú | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé gọi đúng 3/4 con thú (lion, elephant, monkey, tiger).
2. Bé nói "It's big!" (hoặc chỉ "Big!") khi được hỏi.
3. Bé nói "I like monkeys." (hoặc "I like…") ít nhất 1 lần.

**Số đo của buổi 18** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 18 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 13 |
| Lượt bé nói tên con thú | ≥ 4 |
| Câu ≥ 3 từ bé nói ("I like monkeys.") | ≥ 1 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 20%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| lion / elephant / monkey / tiger | | | | |
| It's big! | | | | |
| I like monkeys. | | | | |
| Sửa Mya / It's ok! | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Xem 1 video bài hát sở thú ("Let's Go to the Zoo" hoặc "Walking in the Jungle"), bố/mẹ làm tiếng kêu và dáng đi cùng bé, không bắt bé hát theo.
- Giơ một con thú: "What's this?"; bé nói tên hoặc chỉ vào là đạt.
- Lúc chơi: "Walk like an elephant!", "Jump like a monkey!"; bé làm theo là đạt, không bắt nói.
- Hỏi "Do you like monkeys?"; bé nói "Yes!" hay "I like monkeys!" đều khen.
- Bố/mẹ không sửa phát âm, không sửa khi bé gọi con thú là "cat", không nói "con nói đi" quá 2 lần.

Buổi sau là Buổi 19 — xin phép lịch sự ("Can I have the ball, please?", "Thank you!").

---

## 9. Cho app (thư mục `Resources/Lessons/18-zoo/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt Mya cố tình nói nhầm ở chặng 7 (teach_mya-2, teach_mya-6) có `"mistake": true`.
- Lượt sửa Mya ở chặng 7 nhận cả "No tiger" / "No big" (biến thể ở `target_chunks`), nhưng không nhận "No" đứng một mình; lượt "Is it a cat?" nhận cả khi bé nói luôn "Lion!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./No!/Yes!/Bye-bye! và See you next time!
- Câu lấy nguyên văn từ bài cũ dùng lại file tiếng, không thu lại: buổi 17 (hello-6 = talk-3, recall-2 = talk-8, recall-3 = talk-9; câu mẫu In the box./Under the box.), buổi 12 (hello-5 = recall-2, recall-5 = recall-5), buổi 4 (recall-4 = talk-1), buổi 5 (talk-2 = talk-2, talk-14 = talk-6; câu mẫu Red!), buổi 11 (talk-12 = talk-12).
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; `wave`, `ball` là thẻ của app; `images/ball-in-box.svg`, `ball-under-box.svg` chép từ buổi 17), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 20.
