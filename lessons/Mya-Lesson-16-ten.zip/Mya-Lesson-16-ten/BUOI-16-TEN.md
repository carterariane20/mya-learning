# Buổi 16 — Numbers 6–10.

Buổi thứ mười sáu: bé đếm tiếp từ six tới ten bằng khối, ngón tay, cái nhảy và tiếng vỗ tay, trả lời "How many?" với số khối tới 10, nói "Ten!", và sửa khi Mya đếm nhảy cóc hoặc nói nhầm số.
File này gom mọi thứ của buổi 16 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/16-ten/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 16) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–15, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 24% lượt của Mya |
| Từ mới | 5 từ: six, seven, eight, nine, ten; không có cấu trúc mới (dùng lại "How many?" của buổi 3) |
| Sản phẩm cuối buổi | Bé đếm theo được 6–10 (có thể sai 1 số), trả lời đúng "How many?" ít nhất 2 lần, tự nói "Ten!" ít nhất 1 lần |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Đếm theo Mya từ one tới ten, bằng khối, bằng ngón tay.
- Nghe "Six blocks!", "Jump seven times!", "Clap eight times!" thì làm đúng số lần (bố/mẹ đếm cùng).
- Trả lời "How many?" bằng một số từ six tới ten khi nhìn hàng khối, nói cả cụm "Seven blocks." một lần.
- Vẫn trả lời "How old are you?" bằng "I'm four." (theo tuổi thật của bé).
- Sửa Mya khi Mya đếm "six, seven, nine" (thiếu eight) hoặc gọi sai số khối.

Không kỳ vọng: đếm đúng 10 vật mà không ai giúp, nhận mặt chữ số, cộng trừ. Bé hay nhảy cóc "six, seven, nine, ten": bình thường ở tuổi này, không sửa bằng lời, chỉ đếm cùng chậm hơn. Bé chỉ nói số cuối ("Seven!") là **đạt**; Mya chỉ mời bé nói cả cụm "Seven blocks." một lần.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Six! | Sáu | nói theo | six, it's six, six blocks, no six, no! six, xích, xít, sít, sic, no |
| Seven! | Bảy | nói theo | seven, seven blocks, six seven, xe vần, xe ven, se ven, sevun |
| Eight! | Tám | nói theo | eight, seven eight, six seven eight, no eight, ết, êt, ây, eit |
| Nine! | Chín | nói theo | nine, nine blocks, eight nine, nai, nain, nai nờ |
| Ten! | Mười | nói | ten, ten blocks, nine ten, no ten, no! ten, then, teng, tèn, then nờ, no |
| Seven blocks. | Bảy khối. | nói | seven blocks, seven block, seven, xe vần bờ lóc, xe vần lóc, xe vần |
| Five! | Năm (ôn buổi 3) | nói | five, four five, phai, fai, five fingers |
| I'm four. | Con bốn tuổi (theo tuổi bé) | nói | i'm four, i am four, am four, four (theo tuổi thật của bé) |
| How many? | Có mấy cái? | nghe | how many |
| Six blocks! / Jump seven times! / Clap eight times! | Sáu khối / Nhảy bảy cái / Vỗ tay tám cái | nghe + làm | six blocks / jump seven times / clap eight times |
| Show me ten fingers! | Xòe mười ngón tay nào! | nghe + làm | show me ten fingers |
| Give me five! | Đập tay nào! | nghe + làm | give me five |
| Big! / Small! / A small ball. | To / Nhỏ / Một quả bóng nhỏ (ôn buổi 15) | nói | big, it's big, bích / small, it's small, xì mon / a small ball, small ball, small, ơ xì mon bon |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** times, blocks, fingers, show, give, me, jump, clap (và các từ của buổi 1–15: one … five, how many, how old are you, you're, said, big, small, ball, this, or, it's, look, again, happy, how are you, thank you…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** 10 khối gạch đồ chơi (khối của buổi 3, thiếu thì dùng 10 cái nắp chai hay 10 cái thìa); 1 cái hộp có nắp vừa đủ 10 khối; 2 quả bóng một to một nhỏ (buổi 15); 1 con gấu bông; loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Ten in the Bed" (nursery rhyme), mở ở chặng 6. Bố/mẹ bấm Space tạm dừng app, mở bài hát trên máy khác, cho gấu bông lăn ra theo bài hát cùng bé; app không phát bài hát. "One, Two, Three, Four, Five" để mở lúc chơi ở nhà.
**Thẻ tranh trên màn hình** (emoji, thẻ `wave` của app, 8 hình SVG chép từ buổi 3 và 15, 9 hình SVG mới; thẻ đếm tên `<loại>-N` có đúng N vật để máy so với số Mya nói):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| `fingers-5` (một bàn tay xòe, của buổi 3) | Five! | 1 |
| `ball-big.svg` (bóng đỏ to, của buổi 15) | Big! | 2 |
| `ball-small.svg` (bóng đỏ nhỏ, của buổi 15) | Small!, A small ball. | 2 |
| 📦 (hộp kín) | Look! | 3 |
| `blocks-fallen.svg` (10 khối đổ lung tung) | Oh no! | 3 |
| `blocks-5` (một chồng 5 khối, của buổi 3) | Five! | 3 |
| `blocks-6` … `blocks-10` (chồng 5 khối và chồng thứ hai 1–5 khối) | Six blocks!, Seven!, Seven blocks., Eight!, Nine!, Ten!, Six! | 3, 4, 5, 7 |
| `jump-7` (7 dấu chân) | Jump seven times! | 4 |
| `clap-8` (8 chấm vỗ tay) | Clap eight times! | 4 |
| `fingers-{age}` (số ngón tay bằng tuổi bé, 3–7, của buổi 3) | I'm four. | 5 |
| 🎵 | Stand up! (lúc mở bài hát) | 6 |
| `fingers-10` (hai bàn tay xòe) | Show me ten fingers!, Ten fingers!, Ten! | 6, 8 |
| ✋ | Give me five! | 8 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại có mấy vật. Khối trên thẻ xếp thành chồng 5 và chồng thứ hai, để bé thấy "năm, rồi thêm nữa".
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Bỏ 10 khối vào hộp, đậy nắp; để hộp, 2 quả bóng, gấu bông cạnh mình, ngoài tầm tay bé. Dọn một khoảng trống cho bé đứng dậy nhảy. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` `fingers-5`

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you?, và đếm 1–5 cùng Mya bằng ngón tay |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi đếm one … four để bé nói "Five!" |
| Bố/mẹ | Vẫy tay cùng bé; giơ một bàn tay, xòe từng ngón **đúng lúc** Mya đếm |
| Ra khi | Bé đã chào hoặc trả lời, và nói (hoặc nói theo) "Five!" |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ một bàn tay, xòe từng ngón đúng lúc Mya đếm)* [vi] Mình đếm ngón tay nhé! [pause] [slow] One, two, three, four… [WAIT]
> *(bé: "Phai!" · sai/im: Mya đọc mẫu «Five!»)*
> **Mya:** [excited] FIVE! [pause] Five fingers! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ `ball-big.svg` `ball-small.svg`

| | |
|---|---|
| Mục đích | Ôn to/nhỏ với 2 quả bóng của buổi 15, không dạy mới |
| Mya | Hỏi Big or small? với bóng to rồi bóng nhỏ, mời bé nói cả cụm "A small ball." |
| Bố/mẹ | Giơ đúng quả bóng **trước** mỗi câu hỏi |
| Ra khi | Bé đã trả lời 2 quả bóng, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ cầm sẵn quả bóng to và quả bóng nhỏ của buổi 15, để ngoài tầm tay bé)* [vi] Đếm tới năm rồi, giỏi quá! [pause 1s] Giờ mình ôn bóng to, bóng nhỏ nhé.
> **Mya:** *(trước câu này bố/mẹ giơ quả bóng to)* [cheerful] Look! [pause] [ask] Big or small? [WAIT]
> *(bé: "Bích!" · sai/im: Mya đọc mẫu «Big!»)*
> **Mya:** [excited] Wo-ow! [pause] It's BIG! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ cất quả bóng to, giơ quả bóng nhỏ)* [cheerful] And this ball… [pause] [ask] Big or small? [WAIT]
> *(bé: "Xì-mon!" · sai/im: Mya đọc mẫu «Small!»)*
> **Mya:** [praise] SMALL! [pause] It's small! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Again! [pause] [slow] A SMALL ball. [WAIT]
> *(bé: "Ơ xì-mon bon." · sai/im: Mya đọc mẫu «A small ball.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said a small ball! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 📦 `blocks-fallen.svg` `blocks-5` `blocks-10`

| | |
|---|---|
| Mục đích | Gây tò mò bằng hộp kín: 10 khối đổ ra, Mya đếm từ one tới TEN |
| Mya | Thì thầm, "Oh no!" khi khối đổ, đếm 1–5 rồi 6–10, mời bé nói "Ten!" |
| Bố/mẹ | Cho bé lắc hộp; đổ khối ra đúng lúc "Oh no!"; xếp từng khối thành 2 chồng (5 và 5) đúng lúc Mya đếm |
| Ra khi | Bé nói (hoặc nói theo) "Ten!" |

> **Mya:** *(bố/mẹ cất bóng; bỏ 10 khối vào một cái hộp có nắp, đặt trước mặt bé)* [vi] Bóng to, bóng nhỏ xong rồi! [pause 1s] Giờ xem trong hộp của Mya có gì nhé.
> **Mya:** *(bố/mẹ đưa hộp cho bé lắc nghe tiếng lạch cạch, chưa mở)* [whisper] Shh… [pause] Look! [pause] [vi] Con lắc hộp nghe thử nào.
> **Mya:** *(bố/mẹ mở hộp, đổ cả 10 khối ra đúng lúc Mya nói Oh no!)* [gasp] Oh no! [pause] Look! [pause] TEN blocks!
> **Mya:** *(bố/mẹ xếp từng khối thành một chồng đúng lúc Mya đếm; bé đếm theo được thì tốt)* [cheerful] One… [pause] two… [pause] three… [pause] four… [pause] five…
> **Mya:** *(bố/mẹ xếp 5 khối còn lại thành chồng thứ hai, khối cuối cùng giơ cao lên)* [cheerful] Six, seven, eight, nine… [pause] [excited] TEN blocks!
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Your turn! [pause] [slow] TEN! [WAIT]
> *(bé: "Ten!" · sai/im: Mya đọc mẫu «Ten!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said ten! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `blocks-6` `jump-7` `clap-8`

| | |
|---|---|
| Mục đích | Hiểu six, seven, eight bằng tay chân: bỏ 6 khối vào hộp, nhảy 7 cái, vỗ tay 8 cái; chưa cần nói |
| Mya | "Six blocks!", "Jump seven times!", "Clap eight times!", rồi đếm to cùng bé |
| Bố/mẹ | Đưa bé đúng 6 khối; nhảy, vỗ tay làm mẫu và đếm nhỏ cùng bé |
| Ra khi | Bé làm ≥ 2 trong 3 việc (không cần đúng số lần) |

> **Mya:** *(bố/mẹ đặt hộp trống trước mặt bé, đưa bé 6 khối, cất các khối còn lại)* [vi] Mình xếp khối xong rồi, giỏi quá! [pause 1s] Giờ Mya nói số, con làm theo nhé.
> **Mya:** *(bố/mẹ bỏ thử 1 khối vào hộp làm mẫu rồi lấy ra)* [cheerful] Six blocks! [pause] [vi] Con bỏ từng khối vào hộp nào! [WAIT]
> *(bé: "👉"; bé bỏ từng khối vào hộp, bố/mẹ đếm nhỏ cùng bé · sai/im: Mya đọc mẫu «Six blocks!»)*
> **Mya:** [excited] One, two, three, four, five, SIX! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ dắt bé đứng dậy, nhảy cùng bé và đếm nhỏ)* [cheerful] Jump SEVEN times! [WAIT]
> *(bé: "👉"; bé nhảy 7 cái · sai/im: Mya đọc mẫu «Jump SEVEN times!»)*
> **Mya:** [giggle] One, two, three, four, five, six, SEVEN! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ vỗ tay làm mẫu, đếm nhỏ cùng bé)* [cheerful] Clap EIGHT times! [WAIT]
> *(bé: "👉"; bé vỗ tay 8 cái · sai/im: Mya đọc mẫu «Clap EIGHT times!»)*
> **Mya:** [excited] One, two, three, four, five, six, seven, EIGHT! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé nhảy hay vỗ tay nhiều hơn hoặc ít hơn → không sao, Mya vẫn đếm đủ và khen. Bé bỏ cả 10 khối vào hộp → bố/mẹ lấy ra, đếm lại cùng bé tới six.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ `blocks-7` `blocks-9` `blocks-10` `fingers-{age}`

| | |
|---|---|
| Mục đích | Bé trả lời "How many?" với 7, 9, 10 khối, nói cả cụm "Seven blocks." một lần; vẫn nói "I'm four." |
| Mya | Vòng 1: 7 khối (một số, rồi cả cụm). Vòng 2: thêm 2 khối, 9. Vòng 3: thêm 1 khối, 10. Cuối: How old are you? |
| Bố/mẹ | Xếp khối thành hàng, thêm khối **trước** mỗi câu hỏi; chỉ vào từng khối cho bé đếm; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng và câu hỏi tuổi, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ xếp sẵn 7 khối thành một hàng trước mặt bé, để 3 khối còn lại cạnh mình; thì thầm mẫu khi bé bí 2 lần liền)* [vi] Con nhảy, vỗ tay giỏi quá! [pause 1s] Giờ Mya hỏi có mấy khối, con đếm nhé.
> **Mya:** *(bố/mẹ chỉ vào từng khối cho bé đếm)* [cheerful] Look! Blocks! [pause] [ask] How many? [WAIT]
> *(bé: "Xe-vần!" · sai/im: Mya đọc mẫu «Seven!»)*
> **Mya:** [praise] SEVEN! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] SEVEN blocks. [WAIT]
> *(bé: "Xe-vần bờ-lóc." · sai/im: Mya đọc mẫu «Seven blocks.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said seven blocks! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ thêm 2 khối vào hàng, từng khối một)* [excited] One more… [pause] and one more! [pause] [ask] How many? [WAIT]
> *(bé: "Nai!" · sai/im: Mya đọc mẫu «Nine!»)*
> **Mya:** [excited] NINE! [pause] Nine blocks! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ thêm khối cuối cùng vào hàng)* [cheerful] One more! [pause] [ask] How many? [WAIT]
> *(bé: "Ten!" · sai/im: Mya đọc mẫu «Ten!»)*
> **Mya:** [praise] TEN blocks! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ giơ số ngón tay bằng tuổi bé, chỉ vào thẻ ngón tay)* [ask] How old are you? [WAIT]
> *(bé: "Am four." · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** *(vẫy, `wave`)* [gasp] [praise] Wo-ow! You're FOUR! [pause] High five! *(chỉ khi bé đúng)*

**Nói cả cụm (chỉnh của giai đoạn 2):** bé nói "Seven!" là đúng; Mya khen rồi nói mẫu "Seven blocks." và mời bé nói cả cụm một lần. Bé đếm cả dãy "one, two … seven" cũng tính đúng. Không bắt bé đếm lại từ đầu.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Seven!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chạm từng khối khi Mya đọc mẫu. Bé đếm nhảy cóc ("six, seven, nine") → không sửa bằng lời; bố/mẹ đếm lại cùng bé chậm hơn, chạm từng khối. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự xếp khối, bố/mẹ hỏi "How many?", và bỏ chặng 7. **Bé ngơ:** chỉ làm vòng 1 và vòng 3 (7 và 10).

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 `fingers-10`

| | |
|---|---|
| Mục đích | Xả năng lượng với "Ten in the Bed", rồi xòe và đếm mười ngón tay |
| Mya | Ra lệnh Stand up!, cho bé xòe mười ngón, đếm six … nine để bé nói "Ten!" |
| Bố/mẹ | Bấm Space tạm dừng app lúc mở bài hát, cho gấu bông lăn ra cùng bé; xòe hai bàn tay làm mẫu; chạm từng ngón tay bé **đúng lúc** Mya đếm |
| Ra khi | Hết giờ hoặc bé đã xòe tay và nói (hoặc nói theo) "Ten!" |

> **Mya:** *(bố/mẹ cất khối, dọn chỗ trống cho bé đứng; để gấu bông cạnh mình)* [vi] Con đếm khối giỏi quá! [pause 1s] Giờ mình đứng dậy, hát và đếm ngón tay nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, mở bài "Ten in the Bed", cho gấu bông lăn ra theo bài hát cùng bé; xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** *(bố/mẹ xòe hai bàn tay làm mẫu)* [cheerful] Show me TEN fingers! [WAIT]
> *(bé: "👉"; bé xòe cả hai bàn tay · sai/im: Mya đọc mẫu «Show me TEN fingers!»)*
> **Mya:** [excited] Wo-ow! [pause] Ten fingers! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ cùng bé đếm một đến năm trên một bàn tay trước, rồi chạm từng ngón bàn tay kia đúng lúc Mya đếm sáu, bảy, tám, chín)* [cheerful] Six, seven, eight, nine… [WAIT]
> *(bé: "Ten!" · sai/im: Mya đọc mẫu «Ten!»)*
> **Mya:** *(vẫy, `wave`)* [excited] TEN! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `blocks-6` `blocks-8` `blocks-10`

| | |
|---|---|
| Mục đích | Bé sửa Mya ba lần: Mya gọi 6 khối là "seven", đếm "six, seven, nine" (thiếu eight), gọi 10 khối là "nine"; buổi 16–20 chủ yếu dùng gọi sai |
| Mya | Nói nhầm số rồi hỏi "Đúng không con?", hoặc đếm nhảy cóc rồi chờ bé nhắc |
| Bố/mẹ | Lấy lại 10 khối (đã cất ở chặng 6); xếp 6 khối rồi thêm 2, thêm 2 đúng lượt; lắc đầu, đếm nhỏ cùng bé, nhắc: "Mya nói nhầm rồi, con sửa Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ xếp 6 khối thành hàng, để 4 khối cạnh mình; nhắc nhỏ: Mya nói nhầm thì con sửa Mya nhé)* [vi] Con đếm tới mười rồi! [pause 1s] Giờ Mya đếm, Mya nói nhầm thì con sửa nhé.
> **Mya:** *(Mya cố tình nói nhầm; bố/mẹ lắc đầu, chỉ vào từng khối đếm nhỏ cùng bé)* [cheerful] Look! [pause] SEVEN blocks! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! Xích!" · sai/im: Mya đọc mẫu «Six!»)*
> **Mya:** [gasp] Oh! [pause] SIX blocks! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ thêm 2 khối vào hàng; Mya cố tình đếm nhảy cóc, bỏ eight)* [puzzled] Oh? Six, seven, NINE blocks! [WAIT]
> *(bé: "Ết!" · sai/im: Mya đọc mẫu «Eight!»)*
> **Mya:** [giggle] Seven, EIGHT! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ thêm 2 khối cuối vào hàng; Mya cố tình nói nhầm)* [cheerful] Look! [pause] NINE blocks! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! Ten!" · sai/im: Mya đọc mẫu «Ten!»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh! [pause] TEN blocks! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé chỉ nói "No!" cũng tính là đã sửa. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `fingers-10` ✋ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: đếm 1–10 lần cuối, đập tay, nói "bye-bye" |
| Mya | Đếm six … nine để bé nói "Ten!", "Give me five!", khen cụ thể, chào bé |
| Bố/mẹ | Gập từng ngón tay cùng bé; giơ bàn tay cho bé đập; vẫy tay cùng bé; dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ xòe hai bàn tay cùng bé)* [vi] Con sửa Mya giỏi quá! [pause 1s] Sắp hết giờ rồi, mình đếm tới mười lần cuối nhé.
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ cùng bé gập năm ngón một bàn tay trước, rồi gập từng ngón bàn tay kia đúng lúc Mya đếm sáu, bảy, tám, chín)* [cheerful] Six, seven, eight, nine… [WAIT]
> *(bé: "Ten!" · sai/im: Mya đọc mẫu «Ten!»)*
> **Mya:** [praise] You said TEN! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ bàn tay ra trước mặt bé)* [cheerful] Give me FIVE! [WAIT]
> *(bé: "👉"; bé đập tay với bố/mẹ · sai/im: Mya đọc mẫu «Give me FIVE!»)*
> **Mya:** *(vẫy, `wave`)* [excited] High five! *(chỉ khi bé đúng)*
> **Mya:** [vi] Hôm nay con đếm được tới mười. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🔟, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé đếm nhảy cóc ("six, seven, nine, ten") | Bình thường ở tuổi này. Không sửa bằng lời; bố/mẹ đếm lại cùng bé chậm hơn, chạm từng khối. |
| Bé chỉ nói số cuối ("seven") | Tính là đúng. Mya nói lại cả cụm "Seven blocks." 1 lần rồi đi tiếp. |
| Bé nói bằng tiếng Việt ("mười") | Công nhận rồi bắc cầu: "Mười! Ten!" Không bắt nói lại ngay. |
| Nhà không có đủ 10 khối | Dùng 10 vật nhỏ giống nhau (nắp chai, thìa, ô tô đồ chơi); Mya vẫn nói "blocks" như lời của bài, bố/mẹ chỉ vào thẻ khối trên màn hình. |
| Bé ném hay xô đổ khối | Chơi cùng 1 lượt ("Oh no! Blocks!"), rồi bố/mẹ xếp lại. Không mắng. |
| Bé không chịu nhảy hay vỗ tay | Bố/mẹ làm, bé xem và đếm; không ép. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc hát | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé kể đếm được đồ ở nhà | Theo bé 1 lượt ("Wow! Ten!"), rồi quay lại bài. Không dạy thêm. |
| Bé vừa sang tuổi mới | Hồ sơ trong app đổi tuổi trước buổi; Mya khen "Wo-ow! You're FIVE!" theo tuổi mới. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé đếm theo được 6–10 (có thể sai 1 số).
2. Bé trả lời đúng "How many?" ít nhất 2 lần (số khối tới 10, chỉ nói số cuối vẫn tính), và nói "Ten!".
3. Bé sửa được Mya ở chặng 7.

**Số đo của buổi 16** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 16 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 12 |
| Lượt bé nói một số từ six tới ten | ≥ 4 |
| Câu ≥ 2 từ bé nói ("Seven blocks.", "I'm four.") | ≥ 2 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 24%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| six / seven / eight / nine / ten | | | | |
| How many? → một số | | | | |
| Ten! | | | | |
| Sửa Mya | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Lúc lên cầu thang, đếm bậc cùng bé tới ten.
- Lúc dọn bàn ăn, đếm 10 cái thìa: "How many? Ten!"; bé đếm theo là đạt, không bắt đếm một mình.
- Đập tay "Give me five!" mỗi khi bé làm xong việc.
- Mở "Ten in the Bed" hoặc "One, Two, Three, Four, Five" lúc chơi, không bắt bé hát theo.
- Bố/mẹ không sửa phát âm, không sửa lúc bé đếm nhảy cóc bằng lời, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 17 — in, on, under) mở đầu bằng câu "How many?" với khối và hộp.

---

## 9. Cho app (thư mục `Resources/Lessons/16-ten/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt Mya cố tình nói nhầm số ở chặng 7 (teach_mya-2, teach_mya-4, teach_mya-6) có `"mistake": true`, để `check-counts.py` bỏ qua.
- Lượt "Seven blocks." nhận cả khi bé chỉ nói "seven" (biến thể ở `target_chunks`); lượt sửa Mya ở chặng 7 nhận cả "No!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, High five!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./Five!/Bye-bye! và See you next time!
- Câu lấy nguyên văn từ buổi 15 (recall-2 = talk-2, recall-3 = talk-3, recall-4 = talk-6, recall-5 = talk-7, recall-6 = talk-8, recall-7 = talk-9 của buổi 15; câu mẫu Big!/Small!/A small ball.) và buổi 10 (talk-10 = talk-6 "How old are you?") dùng lại file tiếng của bài cũ, không thu lại.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; `wave` là thẻ của app; `images/blocks-5`, `fingers-3` … `fingers-7` chép từ buổi 3; `images/ball-big.svg`, `ball-small.svg` chép từ buổi 15; `blocks-6` … `blocks-10`, `blocks-fallen.svg`, `fingers-10`, `jump-7`, `clap-8` vẽ riêng), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 18.
