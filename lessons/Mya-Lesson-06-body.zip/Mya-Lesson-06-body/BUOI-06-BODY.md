# Buổi 6 — Body. Touch your nose.

Buổi thứ sáu: bé chạm đúng 5 bộ phận (eyes, nose, mouth, ears, hands), hiểu "Touch your ___" mà không cần dịch, và nói "This is my nose." hoặc chỉ "nose" khi được hỏi "Where's your nose?".
File này gom mọi thứ của buổi 6 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/06-body/`.
Nguồn: [Giáo trình 10 buổi](../GIAO-TRINH-10-BUOI.md) (mục 5, Buổi 6) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–5, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 25% lượt của Mya |
| Từ mới | eyes, nose, mouth, ears, hands, Touch your nose!, This is my nose., Where's your nose? |
| Sản phẩm cuối buổi | Bé chạm đúng 4/5 bộ phận khi nghe và gọi tên được ít nhất 2 bộ phận |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Chạm đúng 5 bộ phận: eyes, nose, mouth, ears, hands.
- Hiểu "Touch your ___" mà không cần dịch.
- Nói "nose" (mức 1) hoặc "This is my nose." (mức 2) khi được hỏi "Where's your nose?".

Không kỳ vọng: nói đủ 5 bộ phận, nói trọn câu cho cả 5 bộ phận, phát âm rõ âm cuối ("eyes", "ears"), tự hỏi được "Where's your nose?". Bé chỉ nói "nose" hoặc "my nose" là **đạt**, không sửa.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Eyes! | Mắt | nói | eyes, eye, ai, ais, ai s |
| Nose! | Mũi | nói | nose, nâu, nô, nốt, nâu s |
| Mouth! | Miệng | nói | mouth, mao, mau, mâu, mao s |
| Ears! | Tai | nói | ears, ear, ia, ia s, iơ, i a |
| Hands! | Tay | nói | hands, hand, hen, hen s, hên, han |
| Touch your nose! | Chạm mũi con. | nghe | touch your nose, touch nose, tắt dô nâu |
| This is my nose. | Đây là mũi con. | nói theo mẫu | this is my nose, this my nose, my nose, nose, đít ít mai nâu, mai nâu |
| Where's your nose? | Mũi con đâu? | nghe | where's your nose, where your nose, where nose, que dô nâu, que nâu |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** draw, a, where are your (và các từ của buổi 1–5: bear, jump, one, two, cat, dog, duck, bird, meow, woof, quack, tweet…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** gương lớn, gấu bông, 1 miếng giấy và băng dính để bịt mũi gấu, 4 con vật của buổi 5 (mèo, chó, vịt, chim), 1 tờ giấy đã vẽ sẵn một hình tròn to, bút màu, loa. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** "Head, Shoulders, Knees and Toes" ở chặng 6, chỉ cần điệu, không cần thuộc hết; "One Little Finger" nếu bé còn hứng. Bố/mẹ mở trên loa và bấm Space tạm dừng app lúc hát; app không phát nhạc có bản quyền.
**Thẻ tranh trên màn hình** (emoji, mỗi thẻ một vật chính):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` | Hello!, Bye-bye! | 1, 8 |
| 🐱 🐶 🦆 `bird.svg` (SVG phẳng) | Cat!, Dog!, Duck!, Bird! | 2 |
| `bear-no-nose.svg` (SVG phẳng, gấu không có mũi) | Bear!, Nose? | 3 |
| `bear` (thẻ của app) | Nose! | 3 |
| 👃 | Nose!, Touch your nose!, This is my nose., Where's your nose | 3, 4, 5, 6 |
| 👀 | Eyes!, Touch your eyes! | 3, 4, 5, 6, 7 |
| `mouth.svg` (SVG phẳng, miệng cười) | Mouth!, Touch your mouth! | 3, 4, 5, 6 |
| `ears.svg` (SVG phẳng, hai tai) | Ears!, Touch your ears! | 3, 4, 5, 6, 7 |
| 👐 | Hands!, Touch your hands! | 3, 4, 5, 6 |
| 🪞 | Look! | 4 |
| 🤸 | Stand up! | 6 |
| 🖍️ | Draw! | 6 |

Gấu bông và cơ thể bé là chính; thẻ trên màn chỉ nhắc lại bộ phận đang nói. Emoji 👂 chỉ có một tai nên "Ears!" dùng `ears.svg` hai tai. Emoji 👄 là đôi môi son, không hợp với bé, nên "Mouth!" dùng `mouth.svg`.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Dán giấy bịt mũi gấu, để gấu sau lưng. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi, "four"); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave`

| | |
|---|---|
| Mục đích | Vào lớp, ôn nhanh tên và How are you? |
| Mya | Chào, hỏi tên, hỏi How are you? |
| Bố/mẹ | Vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm {name}!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 🐱 🐶 🦆 `bird.svg`

| | |
|---|---|
| Mục đích | Ôn 4 con vật của buổi 5 bằng tiếng kêu và tên (không dạy mới) |
| Mya | Hỏi What's this? và kêu tiếng con vật để bé đoán |
| Bố/mẹ | Giơ đúng con vật **trước** khi Mya hỏi |
| Ra khi | Bé đã trả lời 2 con hoặc hết 5 phút |

> **Mya:** *(bố/mẹ lấy sẵn 4 con vật: mèo, chó, vịt, chim)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình ôn lại bốn bạn động vật nhé.
> **Mya:** *(trước câu này bố/mẹ giơ con mèo)* [cheerful] Look! [pause] [ask] What's this? [WAIT]
> *(bé: "Cát!" · sai/im: Mya đọc mẫu «Cat!»)*
> **Mya:** [praise] CAT! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con chó)* [ask] What's this? [WAIT]
> *(bé: "Dóc!" · sai/im: Mya đọc mẫu «Dog!»)*
> **Mya:** [praise] DOG! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con vịt)* [cheerful] Quack, quack! [WAIT]
> *(bé: "Dắc!" · sai/im: Mya đọc mẫu «Duck!»)*
> **Mya:** [giggle] DUCK! [pause] Quack, quack! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ con chim)* [whisper] Shh… [pause] Tweet, tweet… [pause] [ask] What's this? [WAIT]
> *(bé: "Bớt!" · sai/im: Mya đọc mẫu «Bird!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Bird! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ `bear-no-nose.svg` `bear` 👃 👀 `mouth.svg` `ears.svg` 👐

| | |
|---|---|
| Mục đích | Gây tò mò bằng gấu bông bị "mất mũi", rồi gặp đủ 5 bộ phận |
| Mya | Hốt hoảng hỏi mũi gấu đâu, cảm ơn bé, giới thiệu từng bộ phận |
| Bố/mẹ | Dán sẵn giấy bịt mũi gấu, đưa gấu **trước** khi Mya nói; chỉ từng bộ phận trên gấu rồi trên người bé |
| Ra khi | Đã giới thiệu đủ 5 bộ phận |

> **Mya:** *(bố/mẹ đưa gấu bông cho bé xem, mũi gấu đã bị miếng giấy dán kín)* [vi] Ôn bốn bạn xong rồi, con giỏi lắm! [pause 1s] Giờ bạn gấu gặp chuyện rồi nè.
> **Mya:** *(bố/mẹ chỉ vào chỗ mũi gấu, rủ bé tìm giúp)* [gasp] Oh no! [pause] Bear! [pause] [ask] Where's your NOSE? [pause] [vi] Con tìm giúp bạn gấu nào! [WAIT]
> *(bé: "👉"; bé gỡ miếng giấy, tìm ra mũi gấu · sai/im: Mya đọc mẫu «Nose!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! [pause] NOSE! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ mũi gấu rồi chạm mũi bé)* [cheerful] Look! [pause] NOSE! [pause] Your turn! [WAIT]
> *(bé: "Nâu!" · sai/im: Mya đọc mẫu «Nose!»)*
> **Mya:** [praise] You said NOSE! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ mắt gấu rồi mắt bé)* [excited] EYES! [pause] Look! Eyes!
> **Mya:** *(bố/mẹ chỉ miệng gấu rồi miệng bé)* [cheerful] MOUTH! [pause] Mouth!
> **Mya:** *(bố/mẹ chỉ hai tai gấu rồi hai tai bé)* [cheerful] EARS! [pause] One, two!
> **Mya:** *(bố/mẹ giơ hai tay gấu rồi hai tay bé)* [excited] HANDS! [pause] One, two!
> **Mya:** *(trước câu này bố/mẹ chỉ vào mắt gấu)* [ask] Eyes… or ears? [WAIT]
> *(bé: "Ai!" · sai/im: Mya đọc mẫu «Eyes!»)*
> **Mya:** *(vẫy, `wave`)* [praise] EYES! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ 🪞 rồi bộ phận đang chạm

| | |
|---|---|
| Mục đích | Hiểu Touch your ___ bằng hành động, chưa cần nói |
| Mya | Ra lệnh chạm từng bộ phận, chờ rồi khen |
| Bố/mẹ | Đứng cùng bé trước gương, chạm cùng bé 2 lượt đầu; bé chạm sai thì cù nhẹ rồi cùng chạm lại |
| Ra khi | Bé chạm đúng ≥ 3 bộ phận |

> **Mya:** *(bố/mẹ đưa bé đứng trước gương; bé chạm sai thì bố/mẹ cù nhẹ rồi cùng chạm lại, không chê)* [vi] Bạn gấu có mũi rồi! [pause 1s] Giờ mình chơi trò chạm nhanh trước gương nhé.
> **Mya:** [cheerful] Touch your NOSE! [pause] [vi] Con chạm mũi nào! [WAIT]
> *(bé: "👉"; bé chạm mũi, bố/mẹ chạm cùng bé · sai/im: Mya đọc mẫu «Touch your NOSE!»)*
> **Mya:** [praise] Ye-es! Nose! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Touch your EYES! [WAIT]
> *(bé: "👉"; bé chạm mắt, bố/mẹ chạm cùng bé · sai/im: Mya đọc mẫu «Touch your EYES!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! Eyes! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Touch your MOUTH! [WAIT]
> *(bé: "👉"; bé chạm miệng · sai/im: Mya đọc mẫu «Touch your MOUTH!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Mouth! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [slow] Touch your EARS! [WAIT]
> *(bé: "👉"; bé chạm tai; bé hay lẫn với mắt, cứ cù nhẹ rồi chỉ vào tai · sai/im: Mya đọc mẫu «Touch your EARS!»)*
> **Mya:** [praise] Ears! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [excited] Touch your HANDS! [WAIT]
> *(bé: "👉"; bé chạm hai tay vào nhau · sai/im: Mya đọc mẫu «Touch your HANDS!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Hands! [pause] Wo-ow! *(chỉ khi bé đúng)*

Bé chạm sai → bố/mẹ cù nhẹ rồi cùng chạm lại, Mya không nói sai. Bé lẫn "eyes" với "ears" → đọc chậm hơn, không to hơn.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 👃 👀 `mouth.svg` `ears.svg` 👐 👃

| | |
|---|---|
| Mục đích | Bé trả lời Where's your ___?, nói "This is my nose." và thử hỏi lại Mya |
| Mya | Vòng 1: mũi (có cả câu). Vòng 2: mắt, miệng. Vòng 3: tai, tay. Cuối: đổi vai, bé hỏi |
| Bố/mẹ | Chỉ theo cùng bé; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 5 bộ phận hoặc hết 11 phút |

> **Mya:** [vi] Chạm giỏi quá! [pause 1s] Giờ Mya hỏi, con chỉ và nói nhé.
> **Mya:** [cheerful] Look! [pause] [ask] Where's your NOSE? [WAIT]
> *(bé: "Nâu!"; bé chỉ vào mũi · sai/im: Mya đọc mẫu «Nose!»)*
> **Mya:** [praise] NOSE! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] This is my NOSE. [WAIT]
> *(bé: "Đít ít mai nâu."; bé chỉ vào mũi · sai/im: Mya đọc mẫu «This is my nose.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said this is my nose! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [ask] Where are your EYES? [WAIT]
> *(bé: "Ai!"; bé chỉ vào mắt · sai/im: Mya đọc mẫu «Eyes!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said EYES! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** [ask] Where's your MOUTH? [WAIT]
> *(bé: "Mao!"; bé chỉ vào miệng · sai/im: Mya đọc mẫu «Mouth!»)*
> **Mya:** [giggle] MOUTH! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [whisper] Shh… [pause] [ask] Where are your EARS? [WAIT]
> *(bé: "Ia!"; bé chỉ vào tai · sai/im: Mya đọc mẫu «Ears!»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said EARS! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [ask] Where are your HANDS? [WAIT]
> *(bé: "Hen!"; bé giơ hai tay · sai/im: Mya đọc mẫu «Hands!»)*
> **Mya:** *(vẫy, `wave`)* [excited] HANDS! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(đổi vai: bố/mẹ thì thầm cùng bé nếu bé bí)* [cheerful] Your turn! [pause] [vi] Con hỏi Mya đi: [pause] [slow] "Where's your nose?" [WAIT]
> *(bé: "Que dô nâu?" · sai/im: Mya đọc mẫu «Where's your nose?»)*
> **Mya:** *(vẫy, `wave`)* [giggle] This is my NOSE! [pause] Good job! *(chỉ khi bé đúng)*

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «Nose!») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào bộ phận đó khi Mya đọc mẫu. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút và bỏ chặng 7. **Bé ngơ:** cắt lượt còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🤸 `ears.svg` 👐 🖍️ 👀 👃 `mouth.svg`

| | |
|---|---|
| Mục đích | Xả năng lượng bằng bài hát và trò nhảy-chạm, rồi vẽ khuôn mặt |
| Mya | Ra lệnh Stand up!, Jump! Touch your ___!, rồi Draw ___! |
| Bố/mẹ | Mở Head, Shoulders, Knees and Toes và bấm Space tạm dừng app lúc hát; làm cùng bé; đưa giấy đã vẽ hình tròn và bút màu |
| Ra khi | Hết giờ |

> **Mya:** *(bố/mẹ để sẵn bút màu và tờ giấy đã vẽ một hình tròn)* [vi] Con trả lời giỏi quá! [pause 1s] Giờ mình đứng dậy hát và vẽ nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở bài Head, Shoulders, Knees and Toes, bấm Space tạm dừng app, hát và chạm cùng bé; hát xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** [excited] Jump! [pause] Touch your EARS! [WAIT]
> *(bé: "👉"; bé nhảy rồi chạm tai · sai/im: Mya đọc mẫu «Touch your EARS!»)*
> **Mya:** [giggle] Ears! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [excited] Jump! [pause] Touch your HANDS! [WAIT]
> *(bé: "👉"; bé nhảy rồi chạm hai tay · sai/im: Mya đọc mẫu «Touch your HANDS!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hands! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ đưa giấy và bút màu cho bé)* [cheerful] Sit down! [pause] [vi] Giờ mình vẽ khuôn mặt nhé.
> **Mya:** [cheerful] Draw EYES! [pause] [vi] Con vẽ hai mắt nhé! [WAIT]
> *(bé: "Ai!"; bé vẽ hai mắt, vừa vẽ vừa nói; cần thêm giờ thì bố/mẹ bấm Space · sai/im: Mya đọc mẫu «Eyes!»)*
> **Mya:** [praise] EYES! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Draw a NOSE! [WAIT]
> *(bé: "Nâu!"; bé vẽ mũi · sai/im: Mya đọc mẫu «Nose!»)*
> **Mya:** [giggle] NOSE! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [excited] Draw a MOUTH! [WAIT]
> *(bé: "Mao!"; bé vẽ miệng · sai/im: Mya đọc mẫu «Mouth!»)*
> **Mya:** *(vẫy, `wave`)* [excited] MOUTH! [pause] High five! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `ears.svg` rồi 👀

| | |
|---|---|
| Mục đích | Bé sửa lỗi cho Mya: Mya gọi sai tên bộ phận |
| Mya | Thẻ hiện tai nhưng nói nose; thẻ hiện mắt nhưng hỏi mouth |
| Bố/mẹ | Nhắc nhỏ: "Mya nói sai rồi, con nhắc Mya đi" |
| Ra khi | Bé sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya nói sai thì con nhắc Mya nhé)* [vi] Vẽ đẹp quá! [pause 1s] Giờ con làm cô giáo, dạy Mya nhé.
> **Mya:** *(thẻ hiện tai, Mya cố tình gọi là nose)* [cheerful] Look! [pause] This is my NOSE! [WAIT]
> *(bé: "No! Ears!" · sai/im: Mya đọc mẫu «Ears!»)*
> **Mya:** [gasp] Oh no! [pause] EARS! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(thẻ hiện mắt, Mya cố tình gọi là mouth)* [puzzled] And this… [pause] [ask] mouth? [WAIT]
> *(bé: "No! Eyes!" · sai/im: Mya đọc mẫu «Eyes!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] EYES! Eyes! [pause] Well do-one! *(chỉ khi bé đúng)*

Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui, chào từng bộ phận, nói "bye-bye" |
| Mya | Chào từng bộ phận, khen cụ thể, chào bé |
| Bố/mẹ | Chạm cùng bé từng bộ phận, dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ chạm cùng bé từng bộ phận khi Mya chào)* [vi] Sắp hết giờ rồi! [pause 1s] Mình chào từng bộ phận nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, nose! [pause] Bye-bye, eyes!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, mouth! [pause] Bye-bye, ears! [pause] Bye-bye, hands!
> **Mya:** [vi] Hôm nay con nói được mắt, mũi, miệng, tai, tay. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 👀, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói tên bộ phận bằng tiếng Việt ("cái mũi") | Công nhận rồi bắc cầu: "Cái mũi! Nose!" Không bắt nói lại ngay. |
| Bé chỉ nói "nose" hoặc "my nose" thay vì "This is my nose." | Tính là đúng. Mya nói lại cả câu 1 lần rồi đi tiếp. |
| Bé chạm tai khi nghe "eyes" | Bé nghe chưa rõ âm cuối. Nói chậm hơn, không to hơn. Không nói sai. |
| Bé chỉ chỉ tay, chưa nói | Tính là hiểu. "[cheerful] Yes! Nose!" rồi mời bé nói "nose" một lần. |
| Bé không thích bị cù | Bỏ cù, bố/mẹ chỉ tay vào chỗ đúng rồi cùng chạm. |
| Bé buồn hoặc sợ vì gấu "mất mũi" | Bố/mẹ gỡ giấy ngay, ôm gấu cùng bé, nói gấu không đau. Đi tiếp. |
| Bé không muốn vẽ | Chỉ tay vào hình tròn rồi nói tên; bố/mẹ vẽ giúp. Không ép. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc hát | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé kể bộ phận khác ("tóc", "chân") | Theo bé 1 lượt ("Wow!"), rồi quay lại 5 bộ phận của bài. Không dạy thêm. |
| Bé không hỏi lại được "Where's your nose?" | Tính là bình thường, đây là câu ở mức nghe. Mya đọc mẫu rồi tự trả lời. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé chạm đúng 4/5 bộ phận khi nghe.
2. Bé nói "nose" hoặc "eyes" khi được hỏi.
3. Bé hiểu "Touch your ___" mà không cần dịch.

**Số đo của buổi 6** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 6 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 8 |
| Từ đích bé dùng | ≥ 2 bộ phận |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 25%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Chạm đúng bộ phận | | | | |
| Gọi tên bộ phận | | | | |
| This is my ___ | | | | |
| Where's your ___? | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Lúc tắm, hỏi "Where's your nose?", bé chỉ là được, không nói cũng không sao.
- Soi gương cùng bé, chạm từng bộ phận và nói tên tiếng Anh.
- Xem 1 video bài hát Head, Shoulders, Knees and Toes, bé chơi bên cạnh, không bắt nghe.
- Bố/mẹ không sửa phát âm, không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 7 — Family. This is my mommy.) ôn bài này bằng trò chạm nhanh trước gương.

---

## 9. Cho app (thư mục `Resources/Lessons/06-body/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji, riêng con chim là `images/bird.svg`, gấu mất mũi là `images/bear-no-nose.svg`, miệng là `images/mouth.svg`, hai tai là `images/ears.svg`), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 8.
