# Buổi 13 — I have a ball.

Buổi thứ mười ba: bé nói "I have a ball." với đồ vật quen (bóng, ô tô, chuối, gấu bông), nghe "Do you have a car?" thì trả lời Yes/No, nghe "Show me your ball!" thì giơ đúng món.
File này gom mọi thứ của buổi 13 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/13-have/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1 và mục 5, Buổi 13) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–12, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 21% lượt của Mya |
| Từ mới | 0 từ mới; một cấu trúc mới "I have a ___." (nghe thêm "Do you have a ___?", "Show me your ___!") |
| Sản phẩm cuối buổi | Bé nói "I have a ___" ít nhất 2 lần, trả lời Yes/No đúng, nhắc được tên món Mya quên |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nói "I have a ball." (car, banana, teddy) khi cầm món đồ quen trên tay.
- Nghe "Do you have a car?" thì trả lời "Yes!" hoặc "No!" (gật, lắc đầu cũng tính).
- Nghe "Show me your ball!" thì giơ đúng món.
- Nhắc Mya khi Mya quên tên món: "I have a… a…?" → "Car!".

Không kỳ vọng: dùng "have" với số nhiều, tự hỏi "Do you have…?", phát âm rõ "have". Bé nói "I have ball" (thiếu "a") là **đạt**, không sửa: "a" sẽ tự vào sau. Bé chỉ nói tên món ("car") cũng tính đúng; Mya chỉ mời bé nói cả câu một lần.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| I have a ball. | Con có quả bóng. | nói | i have a ball, i have ball, have a ball, a ball, ball, ai hép ơ bon, ai hép bon, hép ơ bon, bon |
| I have a car. | Con có ô tô. | nói | i have a car, i have car, have a car, a car, car, ai hép ơ ca, ai hép ca, hép ơ ca, ca |
| I have a banana. | Con có quả chuối. | nói | i have a banana, i have banana, have a banana, a banana, banana, ai hép ơ ba na na, ai hép ba na na, ba na na |
| I have a teddy! | Con có gấu bông! | nói | i have a teddy, i have teddy, have a teddy, a teddy, teddy, teddy bear, ai hép ơ té đi, ai hép té đi, té đi |
| Car! | Ô tô (bé nói hoặc nhắc Mya) | nói | car, a car, ca, cá, các, ka, i have a car |
| Banana! | Quả chuối (bé nhắc Mya) | nói | banana, a banana, ba na na, bà nà nà, nana, i have a banana |
| Teddy! | Gấu bông (bé sửa Mya) | nói | teddy, no teddy, no! teddy, a teddy, teddy bear, té đi, tê đi, no |
| Yes! / No! | Có / Không | nói | yes, yeah, dét, dế, yes i have / no, nô, no doll |
| Do you have a car? | Con có ô tô không? | nghe | do you have a car |
| Show me your ball! | Cho Mya xem quả bóng của con! | nghe + làm | show me your ball, show me |
| Hat! | Mũ (ôn buổi 12) | nói | hat, hát, hắt, het, hét, a hat |
| Blue! / Yellow! | Xanh dương / Vàng (ôn màu) | nói | blue, blu, bờ lu, it's blue, blue shirt / yellow, dé lô, ye lô, it's yellow, yellow banana |
| Five! | Năm (ôn số) | nói | five, phai, fai, five fingers, i have five |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** do, have, show, me, hand, fingers, run, again, ready, yummy, beep, doll (và các từ của buổi 1–12: ball, car, teddy, banana, hat, shirt, shoes, put on, blue, yellow, color, how many, five, what's this, look, and, hello…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

---

## 3. Chuẩn bị

**Đồ vật:** túi vải kín (không nhìn thấy bên trong); quả bóng, ô tô đồ chơi, gấu bông của buổi 11; một quả chuối thật; mũ, áo, giày của bé từ buổi 12; loa. Búp bê (nếu nhà có) cất đi, không bày ra. Bài này không mang tên hay ảnh thật của bé.
**Bài hát:** chant tự đọc theo nhịp "I have a ball" (ghi ở giáo trình, mục 5 Buổi 13) ở chặng 6. Bố/mẹ bấm Space tạm dừng app, đọc chant và vỗ tay cùng bé; app không phát chant.
**Thẻ tranh trên màn hình** (emoji, 2 thẻ có sẵn của app và 3 hình SVG, mỗi thẻ một vật chính):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 8 |
| 👟 | Put on your shoes! | 1 |
| 🧸 | Teddy!, Put the hat on teddy!, I have a teddy!, Show me your teddy! | 2, 3, 4, 5, 7 |
| 👒 | Hat! | 2 |
| `teddy-hat.svg` (gấu đội mũ, của buổi 12) | On teddy's head! | 2 |
| 👕 (áo xanh dương) | Blue! | 2 |
| 👝 (túi thần kỳ) | Look!, Your turn!, Bye-bye! | 3, 5, 8 |
| `ball` (thẻ của app, bóng đỏ) | I have a ball!, I have a ball., Show me your ball!, Run! | 3, 4, 6 |
| 🚗 | I have a car!, Show me your car!, Car!, I have a car., Yes!, Run! | 3, 4, 5, 6, 7 |
| 🍌 | I have a banana!, Show me your banana!, I have a banana., Yellow!, Banana! | 3, 4, 5, 7 |
| `doll.svg` (búp bê, của buổi 11) | No! (Do you have a doll?) | 5 |
| 🎵 | Stand up! (lúc đọc chant) | 6 |
| `fingers-5.svg` (bàn tay 5 ngón, của buổi 3) | Five! | 6 |

Đồ thật là chính; thẻ trên màn chỉ nhắc lại món đang nói. Thẻ búp bê chỉ để bé biết Mya hỏi về món gì: búp bê thật không có trước mặt bé nên bé trả lời "No!". Ba hình SVG chép từ buổi 3, 11, 12, không vẽ mới.
**Bố/mẹ trước buổi:** cho bé ăn no, đi vệ sinh, ngồi đúng chỗ quen. Bỏ bóng, ô tô, chuối, gấu bông vào túi, để mũ, áo, giày của bé gần đó. Không học khi bé buồn ngủ hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` 👟

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên, How are you? và một lệnh quần áo của buổi 12 |
| Mya | Chào, hỏi tên, hỏi How are you?, rồi ra lệnh Put on your shoes! |
| Bố/mẹ | Vẫy tay cùng bé; đặt giày của bé trước mặt bé **trước** lệnh xỏ giày |
| Ra khi | Bé đã chào hoặc trả lời, và xỏ giày (hoặc chạm vào giày) |

> **Mya:** *(vẫy, `wave`)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đặt đôi giày của bé trước mặt bé)* [cheerful] Put on your SHOES! [WAIT]
> *(bé: "👉"; bé xỏ giày, bố/mẹ giúp nếu khó · sai/im: Mya đọc mẫu «Put on your SHOES!»)*
> **Mya:** [praise] Shoes! [pause] Good job! *(chỉ khi bé đúng)*

### Chặng 2 · Ôn (`recall`) · phút 4–9 · thẻ 🧸 👒 🧸 `teddy-hat.svg` 👕

| | |
|---|---|
| Mục đích | Ôn 2 thứ cũ: quần áo của buổi 12 (mặc đồ cho gấu 60 giây) và màu (blue), không dạy mới |
| Mya | Hỏi What's this? với cái mũ, nhờ bé đội mũ cho gấu, hỏi màu của áo |
| Bố/mẹ | Giơ mũ **trước** khi Mya hỏi; đưa mũ và gấu cho bé; giơ áo **trước** khi Mya hỏi màu |
| Ra khi | Gấu đã đội mũ và bé trả lời 1 câu, hoặc hết 5 phút |

> **Mya:** *(bố/mẹ lấy sẵn gấu bông, cái mũ và cái áo của buổi 12, để cạnh bé)* [vi] Chào nhau xong rồi! [pause 1s] Giờ mình mặc đồ cho gấu nhé.
> **Mya:** *(trước câu này bố/mẹ giơ cái mũ)* [ask] What's this? [WAIT]
> *(bé: "Hát!" · sai/im: Mya đọc mẫu «Hat!»)*
> **Mya:** [excited] HAT! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ đưa bé cái mũ và gấu bông)* [cheerful] Put the hat on TEDDY! [WAIT]
> *(bé: "👉"; bé đội mũ cho gấu, bố/mẹ giúp nếu khó · sai/im: Mya đọc mẫu «Put the hat on TEDDY!»)*
> **Mya:** *(vẫy, `wave`)* [praise] On teddy's HEAD! [pause] Yes! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ giơ cái áo; áo thật không xanh dương thì chỉ vào cái áo xanh dương trên màn hình)* [cheerful] Look! [pause] [ask] What color is it? [WAIT]
> *(bé: "Blu!" · sai/im: Mya đọc mẫu «Blue!»)*
> **Mya:** [praise] BLUE! [pause] Blue shirt! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 3 · Hé lộ (`reveal`) · phút 9–14 · thẻ 👝 `ball` 🚗 🍌 🧸 `ball`

| | |
|---|---|
| Mục đích | Gây tò mò bằng túi thần kỳ; Mya lấy từng món ra và nói "I have a ___!" |
| Mya | Thì thầm về cái túi, mỗi món lộ ra thì nói "I have a ___!", cuối cùng mời bé nói "I have a ball." |
| Bố/mẹ | Đặt túi trước mặt bé; lấy từng món ra **trước** hoặc đúng lúc Mya gọi tên; đưa quả bóng cho bé cầm |
| Ra khi | Đã gặp đủ 4 món và bé nói (hoặc nói theo) "I have a ball." |

> **Mya:** *(bố/mẹ để sẵn quả bóng, ô tô, quả chuối, gấu bông trong túi vải kín, đặt trước mặt bé)* [vi] Gấu mặc đẹp quá! [pause 1s] Giờ xem túi thần kỳ của Mya nè.
> **Mya:** *(bố/mẹ thò tay vào túi; lấy từng món ra khi Mya gọi tên)* [whisper] Shh… [pause] Look! [pause] [vi] Mya thò tay vào túi nhé.
> **Mya:** *(bố/mẹ lấy quả bóng ra, giơ lên đúng lúc Mya nói BALL)* [puzzled] Hmm… [pause] I have… [pause] [excited] a BALL!
> **Mya:** *(trước câu này bố/mẹ lấy ô tô ra)* [cheerful] I have… [pause] a CAR! [pause] Beep beep!
> **Mya:** *(trước câu này bố/mẹ lấy quả chuối ra)* [gasp] Oh! [pause] I have a BANANA! [pause] Yummy!
> **Mya:** *(vẫy, `wave`)* *(trước câu này bố/mẹ lấy gấu bông ra)* [giggle] I have a TEDDY! [pause] Hello, teddy!
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ đưa quả bóng cho bé cầm)* [cheerful] Your turn! [pause] [slow] I have a BALL. [WAIT]
> *(bé: "Ai hép ơ bon." · sai/im: Mya đọc mẫu «I have a ball.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You have a BALL! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `ball` 🚗 🍌 🧸

| | |
|---|---|
| Mục đích | Hiểu "Show me your ___!" bằng hành động, chưa cần nói |
| Mya | Gọi từng món, chờ bé giơ lên rồi khen |
| Bố/mẹ | Bày 4 món trước mặt bé; bé giơ nhầm thì giơ đúng món làm mẫu, không chê |
| Ra khi | Bé giơ đúng ≥ 3 món |

> **Mya:** *(bố/mẹ bày quả bóng, ô tô, quả chuối, gấu bông trước mặt bé; bé giơ nhầm thì bố/mẹ giơ đúng món làm mẫu, không chê)* [vi] Túi thần kỳ hết đồ rồi! [pause 1s] Giờ Mya gọi, con giơ đồ lên nhé.
> **Mya:** [cheerful] Show me your BALL! [WAIT]
> *(bé: "👉"; bé giơ quả bóng · sai/im: Mya đọc mẫu «Show me your BALL!»)*
> **Mya:** [excited] Wo-ow! [pause] Ball! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Show me your CAR! [WAIT]
> *(bé: "👉"; bé giơ ô tô · sai/im: Mya đọc mẫu «Show me your CAR!»)*
> **Mya:** [giggle] A car! [pause] Beep beep! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [whisper] Shh… [pause] Show me your BANANA! [WAIT]
> *(bé: "👉"; bé giơ quả chuối · sai/im: Mya đọc mẫu «Show me your BANANA!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Banana! [pause] Yummy! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** [excited] Show me your TEDDY! [WAIT]
> *(bé: "👉"; bé giơ gấu bông · sai/im: Mya đọc mẫu «Show me your TEDDY!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You have a teddy! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé giơ nhầm → bố/mẹ giơ đúng món làm mẫu 2 lần, Mya không nói sai. Bé không chịu giơ → bố/mẹ đặt món đó vào tay bé, Mya vẫn khen.

### Chặng 5 · Nói với Mya (`talk`) · phút 20–31 · thẻ 👝 🚗 `doll.svg` 🚗 🍌 🧸

| | |
|---|---|
| Mục đích | Bé thò tay vào túi, nói "I have a ___"; trả lời "Do you have…?" bằng Yes/No; tự khoe một món |
| Mya | Vòng 1: ô tô (một từ, rồi mời nói cả câu), hỏi Do you have a doll? / a car?. Vòng 2: chuối và màu của chuối. Vòng 3: bé tự khoe gấu bông |
| Bố/mẹ | Mỗi lần chỉ bỏ **một** món vào túi **trước** khi Mya hỏi; búp bê không bày ra; thì thầm mẫu khi bé bí 2 lần liền |
| Ra khi | Đủ 3 vòng, hoặc hết 11 phút |

> **Mya:** *(bố/mẹ cất đồ ra chỗ khác, chỉ bỏ ô tô vào túi; búp bê (nếu nhà có) để ngoài, không bày ra)* [vi] Con giơ đồ nhanh quá! [pause 1s] Giờ đến lượt con thò tay vào túi nhé.
> **Mya:** *(trước câu này bé thò tay vào túi, lấy ô tô ra)* [gasp] Oh! [pause] [ask] What do you have? [WAIT]
> *(bé: "Ca!" · sai/im: Mya đọc mẫu «Car!»)*
> **Mya:** [excited] Wo-ow! [pause] You have a CAR! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [vi] Con nói cả câu nhé: [pause] [slow] I have a CAR. [WAIT]
> *(bé: "Ai hép ơ ca." · sai/im: Mya đọc mẫu «I have a car.»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said I have a car! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bé vẫn cầm ô tô; búp bê không có trong số đồ bày ra; bé ngơ thì bố/mẹ lắc đầu làm mẫu)* [ask] Do you have a DOLL? [WAIT]
> *(bé: "Nô!"; lắc đầu cũng tính · sai/im: Mya đọc mẫu «No!»)*
> **Mya:** [giggle] No! [pause] No doll! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ vào ô tô bé đang cầm)* [ask] Do you have a CAR? [WAIT]
> *(bé: "Yes!"; gật đầu cũng tính · sai/im: Mya đọc mẫu «Yes!»)*
> **Mya:** [excited] Yes! [pause] A car! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(trước câu này bố/mẹ bỏ quả chuối vào túi, bé thò tay lấy ra)* [cheerful] Again! [pause] [ask] What do you have? [WAIT]
> *(bé: "Ai hép ơ ba-na-na." · sai/im: Mya đọc mẫu «I have a banana.»)*
> **Mya:** [praise] You have a BANANA! [pause] Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ chỉ vào quả chuối bé đang cầm)* [ask] What color is the banana? [WAIT]
> *(bé: "Dé-lô!" · sai/im: Mya đọc mẫu «Yellow!»)*
> **Mya:** [praise] YELLOW! [pause] Yellow banana! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ đưa gấu bông cho bé; thì thầm mẫu cho bé nói to: I have a teddy!)* [vi] Giờ con tự khoe với Mya nhé! [pause] [slow] I have a TEDDY! [WAIT]
> *(bé: "Ai hép ơ té-đi!" · sai/im: Mya đọc mẫu «I have a TEDDY!»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Wo-ow! [pause] You have a teddy! [pause] Hello, teddy! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** lượt đầu bé nói "Car!" là đúng; Mya khen rồi nói mẫu "I have a car." và mời bé nói cả câu một lần. Ở lượt chuối và lượt gấu, bé nói "banana", "a banana" hay "I have banana" đều tính đúng. Bé nói "I have ball" thiếu "a" vẫn đạt, không sửa.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «I have a car.») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ giơ món đồ đó khi Mya đọc mẫu. Ở lượt Yes/No, bé gật hoặc lắc đầu thì bố/mẹ nói nhỏ "Yes!"/"No!" cho bé nói theo. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự thò tay lấy thêm một món và tự nói "I have a ___", và bỏ chặng 7. **Bé ngơ:** cắt mỗi vòng còn 1 câu, chỉ tay nhiều hơn.

### Chặng 6 · Vận động (`move`) · phút 31–38 · thẻ 🎵 `ball` 🚗 `fingers-5.svg`

| | |
|---|---|
| Mục đích | Xả năng lượng bằng chant, chạy đi lấy đồ về rồi nói "I have a ___", đếm ngón tay |
| Mya | Ra lệnh Stand up!, Run!, hỏi What do you have?, rồi hỏi How many fingers? |
| Bố/mẹ | Bấm Space tạm dừng app lúc đọc chant; đặt bóng, ô tô ở hai góc phòng **trước** lệnh Run!; giơ bàn tay 5 ngón làm mẫu |
| Ra khi | Hết giờ hoặc bé đã mang về bóng và ô tô |

> **Mya:** *(bố/mẹ đặt quả bóng ở một góc phòng, ô tô ở góc khác)* [vi] Con khoe đồ giỏi quá! [pause 1s] Giờ mình đứng dậy, chạy đi lấy đồ nhé.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ bấm Space tạm dừng app, đọc chant "I have a ball" theo nhịp và vỗ tay cùng bé; xong bấm Space học tiếp)* [cheerful] Stand up!
> **Mya:** [excited] Ready? [pause] Run! [pause] [vi] Chạy lấy quả bóng nào! [WAIT]
> *(bé: "👉"; bé chạy lấy quả bóng mang về · sai/im: Mya đọc mẫu «Run!»)*
> **Mya:** *(bé chạy về, giơ quả bóng)* [ask] What do you have? [WAIT]
> *(bé: "Ai hép ơ bon." · sai/im: Mya đọc mẫu «I have a ball.»)*
> **Mya:** [excited] BALL! [pause] You have a ball! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** [cheerful] Again! [pause] Run! [pause] [vi] Lấy ô tô về đây nào! [WAIT]
> *(bé: "👉"; bé chạy lấy ô tô mang về · sai/im: Mya đọc mẫu «Run!»)*
> **Mya:** [giggle] Beep beep! [pause] You have a car! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ một bàn tay xoè đủ 5 ngón làm mẫu)* [cheerful] Show me your HAND! [pause] [ask] How many fingers? [WAIT]
> *(bé: "Phai!" · sai/im: Mya đọc mẫu «Five!»)*
> **Mya:** [excited] FIVE! [pause] You have five fingers! [pause] Well do-one! *(chỉ khi bé đúng)*

### Chặng 7 · Bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ 🚗 🍌 🧸

| | |
|---|---|
| Mục đích | Bé nhắc từ hai lần (Mya quên "I have a… a…?") và sửa Mya một lần (Mya gọi gấu là bóng); buổi 11–15 chủ yếu dùng quên |
| Mya | Bắt đầu "I have a…" rồi ngập ngừng chờ bé nhắc; sau đó cầm gấu mà nói "ball" |
| Bố/mẹ | Giơ ô tô, chuối, gấu cạnh màn hình; nhắc nhỏ: "Mya quên rồi, con nhắc Mya đi" |
| Ra khi | Bé nhắc hoặc sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ nhắc nhỏ: Mya quên hay nói nhầm thì con nhắc Mya nhé)* [vi] Con chạy giỏi quá! [pause 1s] Giờ Mya khoe đồ, Mya quên thì con nhắc nhé.
> **Mya:** *(bố/mẹ giơ ô tô cạnh màn hình; Mya cố tình quên tên)* [puzzled] Hmm… [pause] I have a… [pause] [ask] a…? [WAIT]
> *(bé: "Ca!" · sai/im: Mya đọc mẫu «Car!»)*
> **Mya:** [excited] CAR! [pause] I have a car! [pause] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ quả chuối)* [puzzled] And… [pause] I have a… [pause] [ask] a…? [WAIT]
> *(bé: "Ba-na-na!" · sai/im: Mya đọc mẫu «Banana!»)*
> **Mya:** [giggle] BANANA! [pause] I have a banana! [pause] Yummy! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ gấu bông; Mya cố tình gọi nhầm thành bóng; bố/mẹ lắc đầu, nhắc nhỏ bé nói: No! Teddy!)* [cheerful] I have a… [pause] BALL! [pause] [vi] Đúng không con? [WAIT]
> *(bé: "No! Té-đi!" · sai/im: Mya đọc mẫu «Teddy!»)*
> **Mya:** *(vẫy, `wave`)* [gasp] Oh! [pause] I have a TEDDY! [pause] Well do-one! *(chỉ khi bé đúng)*

Bé chỉ nói "No!" ở lượt gấu bông cũng tính là đã sửa. Bỏ chặng này nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Tạm biệt (`bye`) · phút 43–45 · thẻ 👝 `wave`

| | |
|---|---|
| Mục đích | Kết thúc vui: cất đồ vào túi, chào từng món, nói "bye-bye" |
| Mya | Chào từng món khi bé cất vào túi, khen cụ thể, chào bé |
| Bố/mẹ | Mở túi cho bé cất từng món, dán sticker cho bé |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(bố/mẹ mở túi; bé cất từng món vào khi Mya chào)* [vi] Sắp hết giờ rồi! [pause 1s] Mình cất đồ vào túi nhé.
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, ball! [pause] Bye-bye, car!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye, banana! [pause] Bye-bye, teddy!
> **Mya:** [vi] Hôm nay con tự nói được con có gì. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ dán sticker)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 👝, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé nói "I have ball" (thiếu "a") | **Đạt**, không sửa. Mya khen rồi đi tiếp; "a" sẽ tự vào sau. |
| Bé chỉ nói tên món ("car") | Tính là đúng. Mya nói lại cả câu "I have a car." 1 lần rồi đi tiếp. |
| Bé nói tên đồ bằng tiếng Việt ("ô tô") | Công nhận rồi bắc cầu: "Ô tô! Car!" Không bắt nói lại ngay. |
| Bé lấy nhầm món khác trong túi | Không sao. Bố/mẹ cất món đó lại, chỉ để đúng món của lượt trong túi rồi cho bé lấy lại. |
| Bé nói "Yes" khi Mya hỏi búp bê (nhà có búp bê) | Không chê. Bố/mẹ chỉ vào đồ đang bày ra và lắc đầu làm mẫu "No!". |
| Nhà không có ô tô đồ chơi hoặc chuối | Dùng món quen khác bé gọi được tên (bóng, gấu); Mya vẫn nói đúng lời của bài, bố/mẹ chỉ vào thẻ trên màn hình. |
| Áo thật của bé không màu xanh dương | Bố/mẹ chỉ vào cái áo xanh dương trên màn hình khi Mya hỏi màu. |
| Bé đòi ăn chuối ngay | Cho bé cầm, ăn sau buổi học. Mya: "Yummy!" rồi đi tiếp. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung lúc chạy lấy đồ | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé mang đồ khác ra khoe | Theo bé 1 lượt ("Wow!"), rồi quay lại 4 món của bài. Không dạy thêm. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ chặng 7, kéo dài chặng 6, đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé nói "I have a ___" ít nhất 2 lần (thiếu "a" vẫn tính).
2. Bé trả lời Yes/No đúng (gật, lắc đầu cũng tính).
3. Bé nhắc hoặc sửa được Mya ở chặng 7.

**Số đo của buổi 13** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 13 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 10 |
| Câu "I have a ___" bé nói | ≥ 2 |
| Câu ≥ 3 từ bé nói ("I have a car.") | ≥ 1 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 21%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| I have a ___. | | | | |
| Yes / No khi nghe Do you have…? | | | | |
| Show me your ___! (làm theo) | | | | |
| Nhắc hoặc sửa Mya | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Mỗi tối bé lấy 1 món đồ, nói "I have a ___" với bố/mẹ. Bé chỉ nói tên món cũng được.
- Lúc chơi, bố/mẹ hỏi "Do you have a car?", bé gật hoặc nói "Yes!"/"No!".
- Bố/mẹ nói "Show me your teddy!", bé giơ gấu lên.
- Đọc chant "I have a ball" cùng bé lúc tắm hoặc trước khi ngủ, không bắt bé đọc theo.
- Bố/mẹ không sửa phát âm, không sửa "I have ball", không nói "con nói đi" quá 2 lần.

Buổi sau (Buổi 14 — Weather. It's sunny.) mở đầu bằng câu "I have a ___" với đồ của bé.

---

## 9. Cho app (thư mục `Resources/Lessons/13-have/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên bé (`{name}`) hoặc tuổi bé (`{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên/tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt bé có `word` là "I have a ___." nhận cả khi bé chỉ nói tên món hoặc thiếu "a" (biến thể ở `target_chunks`); lượt "Teddy!" ở chặng 7 nhận cả "No!".
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, Stand up!, câu ghép "Hello, Bông!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu Yes!/No!/Five!/Bye-bye! và See you next time!
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; bóng là thẻ `ball` của app; `images/teddy-hat.svg`, `images/doll.svg`, `images/fingers-5.svg` chép từ buổi 12, 11, 3), từ câu nào tới câu nào; xem skill make-lesson mục 1.
- `target_utterances`: 15.
