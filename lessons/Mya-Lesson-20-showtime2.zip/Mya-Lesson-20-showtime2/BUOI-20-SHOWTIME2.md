# Buổi 20 — Show time 2.

Buổi thứ hai mươi, buổi cuối giai đoạn 2: khởi động qua bốn trạm ôn (màu + số, đồ chơi + vị trí, thú, quần áo), cùng dựng sân khấu xem Mya diễn mẫu tám câu, tập động tác cho bốn câu mới, tổng duyệt rồi biểu diễn thật trước cả nhà. Sau đó xem lại video buổi 10 để bé thấy mình đã nói nhiều hơn, sửa Mya khi Mya diễn sai, và nhận huy chương.
File này gom mọi thứ của buổi 20 vào một chỗ, kèm chỉ dẫn ngắt nghỉ và giọng để Gemini nói theo kịch bản, để in ra, gửi cho người thân, hoặc chép sang thư mục bài trong app `Resources/Lessons/20-showtime2/`.
Nguồn: [Giáo trình buổi 11–20](../GIAO-TRINH-BUOI-11-20.md) (mục 1, mục 3 và mục 5, Buổi 20) và [Đặc tả AI Mya](../AI-MYA-SPEC.md). Khi hai file đó đổi, sửa lại file này.

| | |
|---|---|
| Thời lượng | 45 phút, 8 chặng |
| Bé | 3–7 tuổi (mẫu: 4 tuổi, tên Bông), đã học buổi 1–19, bố/mẹ ngồi cạnh |
| Tiếng Việt | khoảng 20–25% lượt của Mya |
| Từ mới | 0 từ, 0 cấu trúc: ôn toàn bộ đã học |
| Sản phẩm cuối buổi | Bé biểu diễn 8 câu tự giới thiệu (khoảng 2 phút), bố/mẹ quay video |

---

## 1. Mục tiêu

Cuối buổi bé làm được:
- Nói 8 câu của show liền mạch: Hello! / I'm Bông. / I'm four. / I have a teddy. / It's big! / I like monkeys. / Thank you! / Bye-bye!
- Có 2 câu tự nghĩ, không bắt chước Mya: "I have a ___" (đồ chơi của bé) và "I like ___" (con thú bé thích). Mya diễn mẫu bằng quả bóng và quả chuối, bé nói về gấu bông và con khỉ (hoặc món bé tự chọn).
- Biểu diễn một lần cho bố/mẹ xem, có quay video.
- Xem lại video buổi 10 và đếm: buổi 10 nói năm câu, hôm nay nói tám câu ("Eight!").
- Sửa Mya khi Mya nói sai ("It's big!", "It's a teddy.").
- Vẫn trả lời được bốn trạm ôn: "Three red balls." / "In the box." / "It's an elephant." / "It's a hat."

Không kỳ vọng: nói tròn cả 8 câu, phát âm chuẩn, nói đúng thứ tự mà không nhìn thẻ. Bé nhìn thẻ hay nhìn bố/mẹ 1–2 lần là bình thường. Bé ngại đứng lên sân khấu thì cho bé ngồi trong lòng bố/mẹ mà diễn.

---

## 2. Ngôn ngữ đích

| Mẫu | Nghĩa | Mức | Biến thể chấp nhận (bé nói vẫn tính đúng) |
|---|---|---|---|
| Hello! | Xin chào! | nói | hello, hi, hé lô, he lô, lô |
| I'm Bông. | Con là Bông. | nói | i'm Bông, i am Bông, am Bông, Bông |
| I'm four. | Con bốn tuổi. | nói (theo tuổi bé) | i'm four, i am four, am four, four |
| I have a teddy. | Con có gấu bông. (bé tự chọn đồ chơi) | nói | i have a teddy, i have teddy, have a teddy, a teddy, teddy, i have a ball, i have a car, i have a doll, i have a banana, ai hép a té đi, ai hép té đi |
| It's big! | Nó to lắm! | nói | it's big, it is big, big, very big, a big teddy, ít bích, bích |
| I like monkeys. | Con thích khỉ. (bé tự chọn con thú) | nói | i like monkeys, i like monkey, like monkeys, monkeys, i like elephants, i like tigers, i like lions, i like cats, i like bananas, ai lai măng ki |
| Thank you! | Cảm ơn! | nói | thank you, thanks, thank you mya, thank, thanh kiu, thanh kìu, tanh kiu, thenk kiu |
| Bye-bye! | Tạm biệt! | nói | bye-bye, bye bye, bye, bai bai, bai |
| Three red balls. | Ba quả bóng đỏ. (ôn màu + số) | nói | three red balls, three red ball, three balls, three red, three, red balls, red, thờ ri rét bon, thờ ri |
| In the box. | Ở trong hộp. (ôn buổi 17) | nói | in the box, in box, the box, it's in the box, in, in đờ bóc |
| It's an elephant. | Con voi. (ôn buổi 18) | nói | it's an elephant, it's a elephant, it's elephant, an elephant, elephant, ít ờn ê lơ phần, ê lơ phần |
| It's a hat. | Cái mũ. (ôn buổi 12) | nói | it's a hat, a hat, hat, ít sờ a hát, hát |
| Eight! | Tám! (tám câu, tám sticker) | nói | eight, eight stickers, it's eight, ết, ây |
| It's a teddy. | Là gấu bông mà! (sửa Mya) | nói | it's a teddy, a teddy, teddy, no teddy, no it's a teddy, ít sờ té đi, té đi |
| I'm happy. | Con vui. | nói | i'm happy, happy, i am happy, hép pi |
| Ladies and gentlemen… it's Bông! | Xin giới thiệu… bé Bông! | nghe | ladies and gentlemen |
| You did it! I'm proud of you! | Con làm được rồi! Mya tự hào về con! | nghe | you did it, i'm proud of you |
| Big or small? | To hay nhỏ? | nghe | big or small |

**Từ đi kèm hoạt động, chỉ để nghe, không dạy:** ladies, gentlemen (mới, chỉ để nghe lúc Mya giới thiệu bé), show, time, ready, did, proud, of, you're, or, small, car, balls, how many, how old, eight, six, seven, ooh-ooh-ah-ah (tiếng khỉ), clap, yummy, bananas, now (và các từ của buổi 1–19: what's this, where's the ball, in the box, run, jump, dance, stop, you said, see you next time…).
Ngoài các từ trên, từ các buổi trước và [bộ từ hạt giống](../GIAO-TRINH-10-BUOI.md#4-bộ-từ-hạt-giống-dùng-suốt-10-buổi), Mya không dùng từ tiếng Anh nào khác.

Ba câu cứu hộ phải xuất hiện trong buổi: **"Try again." / "Your turn." / "Well done!"**

**Hai câu tự nghĩ:** app chấm theo "I have a teddy." và "I like monkeys.", nên bố/mẹ đưa gấu bông và giơ con khỉ **trước** câu hỏi. Bé nói món khác ("I have a car", "I like tigers") vẫn tính đúng (đã có trong biến thể), bố/mẹ vỗ tay khen; thẻ trên màn vẫn hiện gấu và khỉ, không sao.

---

## 3. Chuẩn bị

**Đồ vật:** "sân khấu" (vài cái gối, một tấm khăn trải, 2 quả bóng bay buộc hai bên); một tờ giấy trắng làm "bảng show" và 8 sticker ngôi sao; huy chương giấy; điện thoại để quay; video buổi 10 (nếu nhà có quay). Bốn trạm ôn: 3 quả bóng đỏ; một quả bóng và cái hộp; con voi đồ chơi; cái mũ. Gấu bông to (hoặc món đồ chơi bé thích nhất), con khỉ đồ chơi, quả chuối, một quả bóng to. Loa. Bài này không mang tên hay ảnh thật của bé; video bố/mẹ quay giữ trong máy nhà mình.
**Bài hát:** "Hello Song" mở trước khi bấm học (cả nhà hát); "Bye-bye Song" mở ở chặng 8. App không phát bài hát.
**Thẻ tranh trên màn hình** (emoji, thẻ `wave` của app, SVG phẳng trong `images/`: `ball-big.svg`, `teddy-big.svg` chép từ buổi 15, `ball-in-box.svg` từ buổi 17, `fingers-3…7.svg` từ buổi 10; `balls-3.svg` và `stickers-8.svg` vẽ mới cho buổi này):

| Thẻ | Chữ dưới thẻ | Dùng ở chặng |
|---|---|---|
| `wave` (thẻ của app) | Hello!, Happy!, Bye-bye! | 1, 3, 5, 6, 8 |
| 🎤 | Show time! | 1, 3, 6 |
| `balls-3.svg` (3 quả bóng đỏ) | Three red balls. | 2 |
| `ball-in-box.svg` (bóng trong hộp) | In the box. | 2 |
| 🐘 | It's an elephant. | 2 |
| 👒 | It's a hat. | 2 |
| 🦒 (Mya) | I'm Mya. | 3 |
| `fingers-4.svg` (4 ngón, tuổi của Mya) | I'm four! | 3 |
| `ball-big.svg` (bóng đỏ to, bóng nhỏ viền xám) | It's big! | 3, 7 |
| 🍌 | I like bananas! | 3 |
| 👏 | Thank you!, You did it! | 3, 4, 5, 6 |
| `stickers-8.svg` (bảng show có 8 sticker ngôi sao) | Eight! | 3, 7 |
| `teddy-big.svg` (gấu to, gấu nhỏ viền xám) | I have a teddy., It's big!, It's a teddy. | 4, 5, 6, 7 |
| 🐒 | I like monkeys. | 4, 5, 6 |
| 🧒 (chính bé) | I'm Bông. | 5, 6 |
| `fingers-{age}.svg` (số ngón bằng tuổi bé, đủ hình 3–7 tuổi) | I'm four. (theo tuổi bé) | 5, 6 |
| 🏅 | Thank you!, You did it! | 8 |

Chữ dưới thẻ ở lượt Mya được rút gọn cho vừa màn hình hẹp; ở lượt bé, chữ dưới thẻ là nguyên câu app chấm. Ở chặng 7, chữ dưới thẻ là câu đúng bé cần nói, không phải câu Mya cố tình nói sai.
**Bố/mẹ trước buổi:** bày sẵn 4 trạm ở 4 góc phòng, để gối và khăn gần chỗ làm sân khấu, tìm sẵn video buổi 10 trong điện thoại, sạc điện thoại. Cho bé đi vệ sinh, uống nước. Bố/mẹ là "tay" của Mya: Mya đưa đồ thì bố/mẹ đưa cho bé. Không học khi bé buồn ngủ, vừa ăn no hoặc vừa bị mắng.

---

## 4. Cách đọc kịch bản (chỉ dẫn giọng cho Gemini)

Lời của Mya trong mục 5 có thẻ trong ngoặc vuông để Gemini biết **nói thế nào**: ngắt ở đâu, giọng gì, chờ bé ở đâu. Thẻ viết bằng tiếng Anh vì nó đi thẳng vào prompt. Mya **không bao giờ đọc thẻ thành tiếng**.

**Ngắt nghỉ và lượt**

| Thẻ | Nghĩa | Ví dụ |
|---|---|---|
| `[pause]` | Ngừng ngắn khoảng nửa giây, như lấy hơi | "Hello! [pause] Hello!" |
| `[pause 1s]` | Ngừng hẳn 1 giây, tạo hồi hộp hoặc để bé kịp nhìn | "One, two… [pause 1s] Hello, bear!" |
| `[WAIT]` | **Hết lượt.** Im lặng, không nói gì thêm cho tới khi bé nói hoặc app gửi sự kiện (4,5 giây) | "What's your name? [WAIT]" |
| `…` | Kéo dài, bỏ lửng để bé điền vào | "I'm… [WAIT]" |
| `-` trong từ | Kéo dài âm đó | "Wo-ow!", "Hel-lo!" |
| CHỮ HOA | Nhấn mạnh từ đó (từ đích) | "I'm MYA." |

**Giọng và cảm xúc** (áp cho câu đứng ngay sau thẻ, tới thẻ khác hoặc hết lượt)

| Thẻ | Nghĩa | Mặt Mya trên màn (`set_face`) |
|---|---|---|
| `[cheerful]` | Vui, sáng, hơi cao — giọng mặc định của Mya | `happy` |
| `[excited]` | Phấn khích, nhanh hơn một chút, cao hơn | `excited` |
| `[praise]` | Khen: xuống giọng ở cuối, kéo dài, ấm | `excited` |
| `[whisper]` | Thì thầm, nhỏ, gần micro, như kể bí mật | `excited` |
| `[soft]` | Nhỏ, chậm, dịu, để trấn an | `sad` |
| `[slow]` | Chậm hẳn lại, tách từng từ | giữ nguyên |
| `[ask]` | Câu hỏi: lên giọng rõ ở cuối | giữ nguyên |
| `[puzzled]` | Ngơ ngác, ngập ngừng, như đang cố nhớ | `confused` |
| `[sing-song]` | Nói như hát, lên xuống theo nhịp | `happy` |
| `[gasp]` | Hít vào ngạc nhiên ("Oh!") | `excited` |
| `[giggle]` | Cười khúc khích ngắn ("hi hi") | `happy` |
| `[vi]` | Chuyển sang tiếng Việt: giọng tự nhiên như bố mẹ nói với con, nhanh vừa, không đọc từng chữ | giữ nguyên |

**Dáng và động tác** viết nghiêng trong ngoặc tròn, ví dụ *(vẫy, `wave`)*. Đó là việc Mya làm trên màn hình (app đổi `pose`), không phải lời nói.

**Đoạn dán vào system prompt** (ghép vào mẫu ở AI-MYA-SPEC mục 9):

```text
SCRIPT DIRECTIONS
Your lines may contain directions in square brackets. Follow them, never
say them aloud.
- [pause] = a short breath (half a second). [pause 1s] = a full one-second
  silence.
- [WAIT] = your turn is over. Stop talking immediately and stay silent
  until the child speaks or the app sends an event. Never fill the silence.
- "…" = trail off and leave the gap for the child to fill.
- A hyphen inside a word stretches that sound: "Wo-ow", "Hel-lo".
- CAPITALS = stress that word; it is a target word.
- [cheerful] bright, warm, a little high (your default voice).
- [excited] faster and higher, full of energy.
- [praise] warm, drawn out, falling at the end.
- [whisper] quiet and close, like sharing a secret.
- [soft] quiet, slow, gentle; you are comforting the child.
- [slow] much slower, one word at a time.
- [ask] clearly rising at the end of the question.
- [puzzled] hesitant, as if trying hard to remember.
- [sing-song] musical, up and down like a nursery rhyme.
- [gasp] a small surprised breath in. [giggle] a short, light laugh.
- [vi] switch to Vietnamese: natural, casual, like a parent talking to
  their child.
The lines are a guide, not a text to read word for word. Keep the meaning,
the target words, the length limits and every [WAIT].
```

---

## 5. Tám chặng

Mỗi lượt Mya nói tối đa 12 từ tiếng Anh và 1 câu hỏi, rồi `[WAIT]` (app đếm 4,5 giây). Chữ nghiêng trong ngoặc tròn là việc làm, không phải lời nói. "Bông" là tên mẫu (bé 4 tuổi); app thay bằng tên và tuổi trong hồ sơ. Lượt của bé ghi câu bé có thể nói và câu mẫu Mya đọc khi bé sai hoặc im (trước đó app nói "Con nói theo Mya nhé:"). Câu ghi *(chỉ khi bé đúng)* thì app bỏ qua khi bé nói sai. Lượt đầu của mỗi chặng (trừ chặng 1) là câu tiếng Việt nối chặng, bé nào cũng nghe. Lượt bé chỉ có 👉 là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.

### Chặng 1 · Chào (`hello`) · phút 0–4 · thẻ `wave` rồi 🎤

| | |
|---|---|
| Mục đích | Vào lớp, ôn tên và How are you?, Mya khen bé đã học hai mươi buổi |
| Mya | Chào, hỏi tên, hỏi How are you?, báo hôm nay là buổi biểu diễn lần hai |
| Bố/mẹ | Mở Hello Song cho cả nhà hát trước khi bấm học; vẫy tay cùng bé |
| Ra khi | Bé đã chào hoặc trả lời |

> **Mya:** *(vẫy, `wave`)* *(trước khi bấm học, bố/mẹ mở Hello Song cho cả nhà hát; ngồi cạnh bé, vẫy tay cùng bé)* [cheerful] Hel-lo! [pause] I'm MYA. [pause] [ask] What's your name?
> *(bé: "I'm Bông!" · sai/im: Mya đọc mẫu «I'm… Bông!»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] How are you?
> *(bé: "Happy!" · sai/im: Mya đọc mẫu «I'm happy.»)*
> **Mya:** *(vẫy, `wave`)* [excited] HAPPY! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(vẫy, `wave`)* [vi] Con học với Mya hai mươi buổi rồi đó, giỏi quá! [pause] Hôm nay con biểu diễn lần hai nhé. [pause] [excited] Show time!

### Chặng 2 · Ôn nhanh (`recall`) · phút 4–9 · thẻ `balls-3.svg` `ball-in-box.svg` 🐘 👒

| | |
|---|---|
| Mục đích | Khởi động qua 4 trạm, mỗi trạm kết hợp hai thứ cũ: màu + số (buổi 3–4), đồ chơi + vị trí (buổi 11, 17), thú (buổi 18), quần áo (buổi 12); chạy, nhảy, nhảy múa, dừng giữa các trạm để ôn hành động |
| Mya | Hô Run!/Jump!/Dance!/Stop! cho bé tới từng trạm, hỏi một câu ở mỗi trạm |
| Bố/mẹ | Bày 4 trạm trước buổi; giơ đồ của trạm lên **trước** câu hỏi |
| Ra khi | Đủ 4 trạm (mỗi trạm khoảng 1 phút) hoặc hết 5 phút |

> **Mya:** *(trước buổi bố/mẹ bày 4 trạm ở 4 góc phòng: 3 quả bóng đỏ; quả bóng trong cái hộp; con voi đồ chơi; cái mũ)* [vi] Trước khi diễn, mình khởi động nhé! [pause 1s] Con chạy qua bốn trạm: màu và số, đồ chơi, bạn thú, quần áo.
> **Mya:** *(nghiêng đầu, `listen`)* *(bé chạy tới trạm 1; bố/mẹ giơ 3 quả bóng đỏ)* [excited] Run, run! [pause] Balls! [pause] [ask] How many? [pause] [vi] Nói cả màu nữa nhé! [WAIT]
> *(bé: "Thờ-ri rét bon." · sai/im: Mya đọc mẫu «Three red balls.»)*
> **Mya:** [praise] Three RED balls! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bé nhảy tới trạm 2; bố/mẹ đặt quả bóng vào hộp)* [vi] Trạm hai! [pause] [cheerful] Jump, jump! [pause] [ask] Where's the ball? [WAIT]
> *(bé: "In đờ bóc." · sai/im: Mya đọc mẫu «In the box.»)*
> **Mya:** *(vẫy, `wave`)* [excited] Yes! In the BOX! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bé nhảy múa tới trạm 3; bố/mẹ giơ con voi)* [vi] Trạm ba! [pause] [sing-song] Dance, dance! [pause] [ask] What's this? [WAIT]
> *(bé: "Ít ờn ê-lơ-phần." · sai/im: Mya đọc mẫu «It's an elephant.»)*
> **Mya:** [praise] You said it's an elephant! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bé chạy tới trạm 4, nghe Stop thì đứng lại; bố/mẹ giơ cái mũ)* [vi] Trạm bốn! [pause] [cheerful] Run, run! [pause] Stop! [pause] [ask] What's this? [WAIT]
> *(bé: "Ít sờ a hát." · sai/im: Mya đọc mẫu «It's a hat.»)*
> **Mya:** *(vẫy, `wave`)* [excited] You said it's a hat! [pause] Nice! *(chỉ khi bé đúng)*

Ở trạm 1, bé chỉ nói "Three!" hay "Red!" → tính đúng; Mya vẫn khen bằng cả cụm "Three red balls!".

### Chặng 3 · Dựng show (`reveal`) · phút 9–14 · thẻ 🎤 `wave` 🦒 `fingers-4.svg` `ball-big.svg` 🍌 👏 `wave` `stickers-8.svg`

| | |
|---|---|
| Mục đích | Gây hứng: cùng dựng sân khấu, xem Mya diễn mẫu tám câu, mỗi câu một sticker lên bảng show |
| Mya | Hô Show time!, diễn 8 câu của mình: Hello! / I'm Mya. / I'm four! / I have a ball! It's big! / I like bananas! / Thank you! / Bye-bye!, rồi đếm đủ tám sticker |
| Bố/mẹ | Cùng bé xếp gối, trải khăn, buộc bóng bay, dán bảng show; Mya nói xong mỗi câu thì dán một sticker; giơ quả bóng to và quả chuối đúng lúc |
| Ra khi | Mya diễn xong, bảng show đủ 8 sticker |

> **Mya:** *(bố/mẹ cùng bé xếp gối, trải khăn làm sân khấu, buộc bóng bay hai bên; dán một tờ giấy trắng làm bảng show, cầm sẵn 8 sticker ngôi sao)* [vi] Bốn trạm xong rồi, con nhớ giỏi lắm! [pause 1s] Giờ mình dựng sân khấu, Mya diễn mẫu tám câu nhé.
> **Mya:** *(bé ngồi trước sân khấu xem Mya diễn; Mya nói xong mỗi câu, bố/mẹ dán một sticker lên bảng show)* [excited] Wo-ow! [pause] Show time! [pause] Look!
> **Mya:** *(vẫy, `wave`)* [cheerful] Hello!
> **Mya:** [cheerful] I'm MYA.
> **Mya:** *(Mya giơ 4 ngón; bố/mẹ chỉ vào thẻ)* [cheerful] I'm FOUR!
> **Mya:** *(bố/mẹ giơ quả bóng to nhất nhà, dang tay thật rộng)* [cheerful] I have a BALL! [pause] It's BIG!
> **Mya:** *(bố/mẹ giơ quả chuối)* [giggle] I like bananas! [pause] Yummy!
> **Mya:** *(bé và bố/mẹ vỗ tay cho Mya; Mya cúi chào)* [praise] Thank you!
> **Mya:** *(vẫy, `wave`)* [sing-song] Bye-bye!
> **Mya:** *(bố/mẹ chỉ từng sticker trên bảng show, đếm cùng Mya)* [vi] Đủ tám sticker rồi, tám câu đó! [pause] [cheerful] One, two, three, four, five, six, seven, EIGHT!

### Chặng 4 · Nghe–làm theo (`listen_do`) · phút 14–20 · thẻ `teddy-big.svg` 🐒 👏

| | |
|---|---|
| Mục đích | Hiểu bốn câu mới so với show buổi 10 bằng động tác, chưa cần nói: I have a teddy → ôm gấu, It's big! → dang tay rộng, I like monkeys → gãi đầu như khỉ, Thank you! → cúi chào |
| Mya | Nói từng câu, chờ bé làm động tác rồi khen |
| Bố/mẹ | Đưa gấu bông cho bé, để con khỉ cạnh mình; làm động tác mẫu **trước** mỗi câu |
| Ra khi | Bé làm đủ 4 động tác |

> **Mya:** *(bố/mẹ đưa bé con gấu bông to (hoặc đồ chơi bé thích nhất), để con khỉ đồ chơi cạnh mình; mỗi câu bố/mẹ làm động tác mẫu trước)* [vi] Mya diễn xong rồi! [pause 1s] Show lần này có bốn câu mới, con tập động tác cho từng câu nhé.
> **Mya:** *(bố/mẹ ôm gấu làm mẫu)* [cheerful] I have a TEDDY! [WAIT]
> *(bé: "👉"; bé ôm gấu bông · sai/im: Mya đọc mẫu «I have a teddy.»)*
> **Mya:** [cheerful] Yes! [pause] [praise] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ dang tay thật rộng làm mẫu)* [excited] It's BIG! [WAIT]
> *(bé: "👉"; bé dang tay thật rộng · sai/im: Mya đọc mẫu «It's big!»)*
> **Mya:** [giggle] BIG! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ giơ con khỉ, gãi đầu làm mẫu)* [giggle] Ooh-ooh-ah-ah! [pause] I like monkeys! [WAIT]
> *(bé: "👉"; bé gãi đầu như khỉ · sai/im: Mya đọc mẫu «I like monkeys.»)*
> **Mya:** *(vẫy, `wave`)* [excited] Monkeys! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ vỗ tay, cúi chào làm mẫu)* [cheerful] Clap, clap! [pause] Thank you! [WAIT]
> *(bé: "👉"; bé cúi chào · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [praise] Well do-one! *(chỉ khi bé đúng)*

Lượt 👉 app không chấm: bố/mẹ là người xem bé làm đúng hay chưa. Bé tự nói theo câu của Mya → càng tốt, bố/mẹ vỗ tay. Bé muốn dùng đồ chơi khác thay gấu bông → được, cứ để bé ôm món đó.

### Chặng 5 · Tổng duyệt (`talk`) · phút 20–31 · thẻ `wave` 🧒 `fingers-{age}` `teddy-big.svg` 🐒 👏 `wave`

| | |
|---|---|
| Mục đích | Bé nói đủ 8 câu với Mya, Mya sửa nhẹ; hai câu "I have…" và "I like…" bé tự nghĩ |
| Mya | Vòng 1: Hello!, I'm ___., I'm ___ (tuổi). Vòng 2: I have a teddy., It's big!, I like monkeys. Vòng 3: Thank you!, Bye-bye! |
| Bố/mẹ | Ngồi cạnh sân khấu, chỉ vào thẻ khi bé bí; giơ con khỉ **trước** câu I like…; vỗ tay thật to **trước** khi bé nói Thank you! |
| Ra khi | Đủ 3 vòng hoặc hết 11 phút |

> **Mya:** *(bé đứng trên sân khấu, cầm gấu bông; bố/mẹ ngồi cạnh, để con khỉ cạnh mình, chỉ vào thẻ khi bé bí)* [vi] Con làm động tác đẹp quá! [pause 1s] Giờ mình tổng duyệt: con lên sân khấu, nói đủ tám câu với Mya nhé.
> **Mya:** *(nghiêng đầu, `listen`)* [cheerful] Ready? [pause] Your turn! [WAIT]
> *(bé: "Hé lô!"; bé vẫy tay · sai/im: Mya đọc mẫu «Hello!»)*
> **Mya:** *(vẫy, `wave`)* [praise] You said hello! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* [ask] What's your name? [WAIT]
> *(bé: "Am Bông." · sai/im: Mya đọc mẫu «I'm… Bông.»)*
> **Mya:** *(vẫy, `wave`)* [praise] Hello, Bông! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào thẻ ngón tay)* [ask] How old are you? [WAIT]
> *(bé: "Am four." · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** *(vẫy, `wave`)* [gasp] [praise] Wo-ow! You're FOUR! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào con gấu bé đang cầm)* [cheerful] Now… [pause] [vi] Con có gì? Nói cả câu nhé: [pause] [slow] I have… [WAIT]
> *(bé: "Ai hép a té-đi." · sai/im: Mya đọc mẫu «I have a teddy.»)*
> **Mya:** [praise] You said I have a teddy! [pause] Good job! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ dang tay rộng gợi ý)* [cheerful] A teddy! [pause] [ask] Big or small? [WAIT]
> *(bé: "Ít bích!" · sai/im: Mya đọc mẫu «It's big!»)*
> **Mya:** [excited] It's BIG! [pause] Wo-ow! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(trước câu này bố/mẹ giơ con khỉ)* [giggle] Ooh-ooh-ah-ah! [pause] [vi] Con thích bạn nào? Nói cả câu: [pause] [slow] I like… [WAIT]
> *(bé: "Ai lai măng-ki." · sai/im: Mya đọc mẫu «I like monkeys.»)*
> **Mya:** [praise] You said I like monkeys! [pause] Clap, clap! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ vỗ tay thật to)* [cheerful] Clap, clap, clap! [pause] [vi] Mọi người vỗ tay, con nói gì nhỉ? [WAIT]
> *(bé: "Thanh-kiu!"; bé cúi chào · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [giggle] You said thank you! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ cúi chào, vẫy tay làm mẫu)* [cheerful] One more! [pause] [vi] Con chào mọi người nhé! [WAIT]
> *(bé: "Bai bai!"; bé cúi chào, vẫy tay · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! [pause] High five! *(chỉ khi bé đúng)*

**Nói cả câu (chỉnh của giai đoạn 2):** bé nói "Teddy!" hay "Big!" vẫn tính đúng; Mya khen bằng cả câu ("You said I have a teddy!"), câu mẫu luôn là cả câu. Không bắt bé nói lại cho đủ chữ.

**Khi bé sai hoặc im — app tự chạy 3 bậc, mỗi lần một bậc, không nhảy bậc** (bài này đặt `wrong_order: try_first`):

| Bậc | Bé nói sai | Bé im |
|---|---|---|
| 1 | "[cheerful] Almost! [pause] Try again!" rồi câu mẫu | câu mẫu (ví dụ «I have a teddy.») |
| 2 | "[soft] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" rồi câu mẫu | "[cheerful] [vi] Con nói theo Mya nhé!" rồi câu mẫu |
| 3 | câu mẫu, rồi "[soft] [vi] Con sẽ luyện thêm câu này với mẹ nhé!" và đi tiếp | giống cột bên |

Bố/mẹ chỉ vào thẻ khi Mya đọc mẫu. Bé chỉ làm động tác mà không nói là đã hiểu: bố/mẹ nói cùng bé một lần, đi tiếp. Im 12 giây → đổi hoạt động.

**Bé hứng:** cho thêm 2 phút, bé tự đổi đồ chơi và con thú rồi nói lại vòng 2, và bỏ phần Mya diễn sai ở chặng 7. **Bé ngơ:** cắt còn vòng 1 và vòng 3, chỉ tay nhiều hơn.

### Chặng 6 · Biểu diễn (`move`) · phút 31–38 · thẻ 🎤 `wave` 🧒 `fingers-{age}` `teddy-big.svg` 🐒 👏 `wave` 👏

| | |
|---|---|
| Mục đích | Buổi diễn thật: bé bước lên sân khấu, nói 8 câu, cúi chào, cả nhà vỗ tay rồi nhảy |
| Mya | Giới thiệu bé ("Ladies and gentlemen…"), thì thầm mở đầu từng câu (Your turn… / I'm… / How old are you? / I have… / It's… / I like… / Clap, clap… / One more…), khen khi xong |
| Bố/mẹ | Ngồi trước sân khấu, quay video; không nhắc, bé bí thì chỉ vào thẻ; vỗ tay ở câu Clap, clap… và thật to ở cuối |
| Ra khi | Bé nói xong 8 câu, cúi chào |

> **Mya:** *(bố/mẹ ngồi trước sân khấu, bật quay video bằng điện thoại; bé cầm gấu bông, đứng sau tấm khăn chờ)* [vi] Tổng duyệt xong rồi, con nói hay lắm! [pause 1s] Giờ là buổi diễn thật. Bố mẹ ngồi xem và quay video nhé!
> **Mya:** *(vẫy, `wave`)* *(bé bước lên sân khấu; bố/mẹ vỗ tay)* [excited] Ladies and gentlemen… [pause] it's BÔNG!
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ không nhắc; bé bí thì chỉ vào thẻ)* [whisper] Your turn… [WAIT]
> *(bé: "Hé lô!"; bé vẫy tay · sai/im: Mya đọc mẫu «Hello!»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] I'm… [WAIT]
> *(bé: "Am Bông." · sai/im: Mya đọc mẫu «I'm… Bông.»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] How old are you? [WAIT]
> *(bé: "Am four."; bé giơ ngón tay · sai/im: Mya đọc mẫu «I'm four.»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] I have… [WAIT]
> *(bé: "Ai hép a té-đi."; bé giơ gấu bông lên · sai/im: Mya đọc mẫu «I have a teddy.»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] It's… [WAIT]
> *(bé: "Ít bích!"; bé dang tay thật rộng · sai/im: Mya đọc mẫu «It's big!»)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ giơ con khỉ)* [whisper] I like… [WAIT]
> *(bé: "Ai lai măng-ki." · sai/im: Mya đọc mẫu «I like monkeys.»)*
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ vỗ tay)* [whisper] Clap, clap… [WAIT]
> *(bé: "Thanh-kiu!"; bé cúi chào · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** *(nghiêng đầu, `listen`)* [whisper] One more… [WAIT]
> *(bé: "Bai bai!"; bé cúi chào, vẫy tay · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [excited] Wo-ow! You did it! [pause] High five! *(chỉ khi bé đúng)*
> **Mya:** *(bố/mẹ vỗ tay thật to rồi dừng quay video; bé cúi chào)* [vi] Cả nhà vỗ tay nào! [pause] Tám câu, con nói hết rồi!

Bé ngại thì cho bé ngồi trong lòng bố/mẹ mà diễn, vẫn tính là biểu diễn. Bé quên một câu → bố/mẹ chỉ vào thẻ, không dừng quay; sót câu cũng không sao.

### Chặng 7 · So sánh và bé dạy Mya (`teach_mya`) · phút 38–43 · thẻ `stickers-8.svg` `ball-big.svg` `teddy-big.svg`

| | |
|---|---|
| Mục đích | Xem lại video buổi 10 để bé thấy mình tiến bộ (năm câu → tám câu), rồi bé sửa Mya hai lần Mya gọi sai |
| Mya | Nhắc buổi 10 con nói năm câu, hỏi hôm nay bao nhiêu câu; diễn "I have a ball. It's SMALL!" với quả bóng to, rồi "I have a CAR!" khi cầm gấu bông |
| Bố/mẹ | Bấm Space tạm dừng app, mở video buổi 10, xem xong bấm Space học tiếp; chỉ vào 8 sticker trên bảng show; giơ quả bóng to và gấu bông **trước** mỗi câu sai của Mya, lắc đầu, nhắc nhỏ: "Mya nói sai rồi, con sửa giúp Mya đi" |
| Ra khi | Bé đếm được "Eight!" và sửa đúng ≥ 1 lần |

> **Mya:** *(bố/mẹ bấm Space tạm dừng app, mở video buổi 10 cho bé xem (không có video thì bỏ qua, chỉ đếm sticker); xem xong bấm Space học tiếp)* [vi] Con diễn hay quá! [pause 1s] Giờ mình xem lại video buổi mười nhé. Hồi đó con nói năm câu.
> **Mya:** *(nghiêng đầu, `listen`)* *(bố/mẹ chỉ vào 8 sticker trên bảng show, đếm cùng bé)* [vi] Còn hôm nay, con nói mấy câu? [pause] [ask] How many? [WAIT]
> *(bé: "Ết!" · sai/im: Mya đọc mẫu «Eight!»)*
> **Mya:** *(vẫy, `wave`)* [excited] EIGHT! [pause] Wo-ow! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** *(Mya cố tình nói sai; bố/mẹ giơ quả bóng to, lắc đầu, dang tay thật rộng)* [vi] Giờ Mya diễn, Mya nói sai thì con sửa nhé. [pause] [cheerful] I have a ball. [pause] It's SMALL! [WAIT]
> *(bé: "Nâu! Ít bích!" · sai/im: Mya đọc mẫu «It's big!»)*
> **Mya:** [gasp] Oh no! [pause] It's BIG! [pause] [praise] Thank you! *(chỉ khi bé đúng)*
> **Mya:** *(Mya cố tình gọi sai; bố/mẹ giơ con gấu bông, lắc đầu)* [vi] Mya diễn tiếp nè, con nghe kỹ nhé! [pause] [cheerful] Look! [pause] I have a CAR! [WAIT]
> *(bé: "Nâu! Ít sờ té-đi!" · sai/im: Mya đọc mẫu «It's a teddy.»)*
> **Mya:** *(vẫy, `wave`)* [giggle] Oh! A TEDDY! [pause] High five! *(chỉ khi bé đúng)*

Nhà không quay video buổi 10 → bỏ phần xem video, chỉ đếm 8 sticker trên bảng show. Bé nói "No!" mà chưa nói câu đúng → app đọc mẫu, bố/mẹ dang tay hoặc chỉ vào gấu. Bỏ phần Mya diễn sai nếu bé mệt sau phút 30 hoặc chặng 5 đã kéo dài.

### Chặng 8 · Trao thưởng và tạm biệt (`bye`) · phút 43–45 · thẻ 🏅 rồi `wave`

| | |
|---|---|
| Mục đích | "Lễ tốt nghiệp" nhỏ: trao huy chương, "You did it!", "I'm proud of you!", bé tự nói "Thank you", chào và hẹn học tiếp |
| Mya | Khen cụ thể, chờ bé cảm ơn, chào bé |
| Bố/mẹ | Đeo huy chương giấy, tặng bóng bay, ôm bé; **không nhắc** "thank you"; mở Bye-bye Song, dán sticker |
| Ra khi | Đã nói hoặc vẫy bye-bye |

> **Mya:** *(vẫy, `wave`)* *(bố/mẹ đeo huy chương giấy cho bé, tặng bóng bay)* [vi] Con sửa cho Mya giỏi quá! [pause 1s] Sắp hết giờ rồi, con học xong hai mươi buổi, Mya có huy chương cho con nè.
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ ôm bé; không nhắc, chờ bé tự cảm ơn)* [excited] You did it! [pause] I'm proud of you! [pause] [vi] Con nói gì với Mya nhỉ? [WAIT]
> *(bé: "Thanh-kiu!" · sai/im: Mya đọc mẫu «Thank you!»)*
> **Mya:** [praise] You said thank you! [pause] Well do-one! *(chỉ khi bé đúng)*
> **Mya:** [vi] Hôm nay con tự nói tám câu và biểu diễn cho cả nhà xem. [pause] Mình còn học tiếp với Mya nữa nhé. [pause] Giỏi quá!
> **Mya:** *(vẫy, `wave`)* *(bố/mẹ mở Bye-bye Song, dán sticker, cả nhà vẫy tay)* [cheerful] Bye-bye, Bông! [WAIT]
> *(bé: "Bye-bye!" · sai/im: Mya đọc mẫu «Bye-bye!»)*
> **Mya:** *(vẫy, `wave`)* [praise] See you next ti-ime! *(chỉ khi bé đúng)*

Màn cuối buổi của app: "Bye-bye, Bông!", sticker 🏆, sao theo số mục tiêu đạt.

---

## 6. Khi có chuyện

| Tình huống | Mya làm gì |
|---|---|
| Bé ngại, không chịu lên sân khấu | Cho ngồi trong lòng bố/mẹ mà diễn, vẫn tính là biểu diễn. Không ép đứng lên. |
| Bé chỉ nói một từ ("Teddy!", "Big!") | Tính là đúng. Câu mẫu vẫn là cả câu, không bắt nói lại. |
| Bé nói đồ chơi, con thú khác ("I have a car", "I like tigers") | Đúng ý buổi này (câu tự nghĩ): app chấp nhận, bố/mẹ vỗ tay khen. |
| Bé nói sai thứ tự 8 câu | Không sao. Bố/mẹ chỉ vào thẻ của câu kế, không bắt nói lại từ đầu. |
| Bé đòi xem video mãi | Xem 1 lần, rồi "[whisper] Shh… [pause] Listen!", quay lại bài. Xem tiếp sau buổi học. |
| Bé buồn vì video buổi 10 "nói ít" | Bố/mẹ khen: "Hồi đó con mới học, giờ con nói nhiều hơn rồi!" Không so với bé khác. |
| Máy nghe không rõ | "[puzzled] [vi] Mya nghe chưa rõ. [pause] Con nói lại nhé?" [WAIT] rồi sang câu có/không. Không đoán bừa rồi khen. |
| Bé chạy lung tung giữa các trạm | Chơi cùng 1 lượt, rồi "[whisper] Shh… [pause] Listen!". Không mắng. |
| Bé nói "thôi", "dừng lại", "stop" | Dừng ngay, không hỏi lại. App hiện màn "Mình nghỉ nhé". |
| Bố/mẹ dịch hộ | Mya vẫn nói tiếng Anh, quay sang: "Mommy, help?" Không trách. |
| Bé mệt sau phút 30 | Bỏ phần Mya diễn sai ở chặng 7 (giữ phần đếm "Eight!"), đóng ở phút 38. |
| Vào muộn, mất 5 phút đầu | Bỏ chặng 2, giữ nguyên chặng 5 và 6. |

---

## 7. Đạt hay chưa

**Dấu hiệu đạt** (app dùng để tính sao cuối buổi):
1. Bé nói được ít nhất 5/8 câu của show (theo mẫu cũng được).
2. Trong đó ít nhất 2 câu 3 từ trở lên ("I have a teddy.", "I like monkeys.", "It's big!").
3. Bé biểu diễn một lần cho bố/mẹ xem.

**Số đo của buổi 20** (theo đặc tả AI, mục 8):

| Chỉ số | Ngưỡng tốt ở buổi 20 |
|---|---|
| Lượt bé nói (có ≥ 1 từ tiếng Anh) | ≥ 22 |
| Câu của show bé nói ở chặng 6 | ≥ 5/8 |
| Câu ≥ 3 từ bé nói ("I have a teddy.", "I like monkeys.", "Three red balls.") | ≥ 2 |
| Tỉ lệ đáp (lượt bé đáp / lượt Mya hỏi) | ≥ 50% |
| Lượt Mya nói tiếng Việt | khoảng 20–25%, vượt 35% thì ghi log |

**Bố/mẹ chấm 0–3 sau buổi** (30 giây):

| Mục tiêu | 0 chưa phản ứng | 1 hiểu qua hành động | 2 nói theo mẫu | 3 tự nói |
|---|---|---|---|---|
| Hello! / I'm ___. / I'm ___ (tuổi). | | | | |
| I have a ___. / It's big! | | | | |
| I like ___. | | | | |
| Thank you! / Bye-bye! | | | | |

---

## 8. Về nhà

5 phút mỗi ngày, không hơn.
- Xem video buổi diễn cùng bé, khen cụ thể ("Con nói 'I have a teddy' rõ lắm"). Không chỉ chỗ sai.
- Cho bé diễn lại cho ông bà, cô chú (gọi video cũng được); bé đổi đồ chơi, con thú tuỳ thích.
- Giữ thói quen của giai đoạn 2: "please" và "thank you" khi đưa đồ, "Where's the ball?" khi tìm đồ.
- Bố/mẹ không sửa phát âm, không bắt bé nói lại cả câu, không nói "con nói đi" quá 2 lần.

Buổi 20 là buổi cuối giai đoạn 2. Xem rủi ro và cách xử lý sau buổi 20 ở [giáo trình, mục 8](../GIAO-TRINH-BUOI-11-20.md#8-rủi-ro-mới-của-giai-đoạn-2).

---

## 9. Cho app (thư mục `Resources/Lessons/20-showtime2/`)

Thư mục bài gồm `lesson.json`, `images/` và `audio/<id>.m4a` (tiếng có sẵn giọng Aoede, tạo bằng `MyaEnglish --gen-lines`), nên app không cần gọi model đọc các câu này. Câu có tên hay tuổi bé (`{name}`, `{age}`) app tạo trên máy theo hồ sơ. Sửa lời trong file này thì sửa cả `lesson.json` rồi chạy lại `--gen-lines`: chỉ câu đã đổi được tạo lại.

- Lượt bé: `word` = câu bé phải nói (app chấm theo nó), `practice` = câu mẫu khi bé sai/im (có `id` file tiếng, trừ câu có tên hay tuổi bé).
- Lượt bé chỉ có emoji (`👉`) là lượt làm động tác: app chờ 3 giây rồi khen, không chấm lời.
- Câu khen ngay sau lượt bé có `"on": "right"`.
- Lượt Mya cố tình nói sai (teach_mya-4, teach_mya-6) có `"mistake": true`.
- "I have a teddy." và "I like monkeys." nhận cả đồ chơi, con thú khác (biến thể ở `target_chunks`), để bé tự nghĩ câu.
- Câu có sẵn trong thư viện chung (`common/lines.json`) dùng `lib`: lời chào, How are you?, I'm MYA., Thank you!, Bye-bye!, Well done!, câu ghép "Hello, Bông!", "HAPPY! High five!", "Yes! Good job!", "Wo-ow! High five!", "Bye-bye, Bông!", "Giỏi quá!", các câu mẫu I'm happy./Thank you!/Bye-bye! và See you next time!
- Câu lấy nguyên văn từ bài cũ có thể dùng lại file tiếng, không thu lại: buổi 10 (reveal-2, reveal-3, reveal-7 = reveal-6, talk-2, talk-3, talk-4, talk-6, talk-16 = talk-10, talk-7a, move-3, move-4, move-5, move-8 = move-6, move-10 = move-7, move-11 = move-8, bye-2), buổi 19 (bye-3); câu mẫu It's a teddy. (buổi 11), It's a hat. (buổi 12), I have a teddy. (buổi 14), Eight! (buổi 16), In the box. (buổi 17), It's big! và I like monkeys. (buổi 18).
- Thẻ hình của bài ghi trong `cards` của lesson.json (emoji; `wave` là thẻ của app; hình trong `images/`), từ câu nào tới câu nào; xem skill make-lesson mục 1. `balls-3` và `fingers-4` ghi không đuôi để `check-counts.py` so số vật với số Mya nói.
- `target_utterances`: 22.
